import { ieVersion } from "@/util/util";

export const download = (path, name)=> {
    ajaxRequest(
      path,
      function(xhr) {
        downloadFile(xhr.response, name);
      },
      {
        responseType: "blob"
      }
    );
  }

const downloadFile = (content, filename) =>{
    console.log("ie版本：" + ieVersion());
    if (window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveBlob(content, filename);
    } else {
      let a = document.createElement("a");
      let blob = new Blob([content]);
      let url = window.URL.createObjectURL(blob);
      a.href = url;
      a.download = filename;
      a.click();
      window.URL.revokeObjectURL(url);
    }
  }
  
  const ajaxRequest = (url, callback, options) =>{
    window.URL = window.URL || window.webkitURL;
    let xhr = new XMLHttpRequest();
    if (!url && url.indexOf("?") != -1) {
      url = url + "&t=" + new Date().getTime();
    } else {
      url = url + "?t=" + new Date().getTime();
    }
    xhr.open("get", url, true);
    if (options.responseType) {
      xhr.responseType = options.responseType;
    }
    xhr.onreadystatechange = function() {
      if (xhr.readyState === 4 && xhr.status === 200) {
        callback(xhr);
      }
    };
    xhr.send();
  }