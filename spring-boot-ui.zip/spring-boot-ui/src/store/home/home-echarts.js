import * as echarts from "echarts";

// 各区统计图表
export const gqtjEchartDraw = (name, data, nodeId) => {
  let echart = echarts.init(document.getElementById(nodeId));
  let option = {
    xAxis: [
      {
        type: "category",
        data: name,
        lineStyle: {
          color: "#FFFFFF"
        },
        axisLine: {
          show: false,
          lineStyle: {
            color: "#435B76"
          }
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          show: true,
          interval: 0,
          textStyle: {
            fontSize: 12,
            lineHeight: 20
          }
        }
      }
    ],
    yAxis: [
      {
        type: "value",
        axisLine: {
          show: false,
          lineStyle: {
            color: "#435B76"
          }
        },
        axisLabel: {
          show: true
        },
        axisTick: {
          show: false
        },
        splitLine: {
          lineStyle: {
            color: "#EBEBEB"
          }
        }
      }
    ],
    grid: {
      left: 30,
      right: 0,
      top: 15,
      bottom: 25
    },
    series: [
      {
        type: "bar",
        barWidth: 48,
        barMinHeight: 30,
        zlevel: 1,
        itemStyle: {
          normal: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: "rgba(43,154,255,0.85)"
              },
              {
                offset: 1,
                color: "rgba(43,154,255,0.85)"
              }
            ]),
            label: {
              show: true,
              position: "top",
              textStyle: {
                color: "#435B76",
                fontSize: 12,
                fontWeight: "bold"
              }
            }
          }
        },
        data: data
      }
    ]
  };
  echart.setOption(option);
};

// 土地情况图表
export const tdqkEchartDraw = (name, data, nodeId) => {
  let echart = echarts.init(document.getElementById(nodeId));
  let option = {
    xAxis: [
      {
        type: "category",
        data: name,
        lineStyle: {
          color: "#FFFFFF"
        },
        axisLine: {
          show: false,
          lineStyle: {
            color: "#435B76"
          }
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          show: true,
          interval: 0,
          textStyle: {
            fontSize: 12,
            lineHeight: 20
          }
        }
      }
    ],
    yAxis: [
      {
        type: "value",
        axisLine: {
          show: false,
          lineStyle: {
            color: "#435B76"
          }
        },
        axisLabel: {
          show: true
        },
        axisTick: {
          show: false
        },
        splitLine: {
          lineStyle: {
            color: "#EBEBEB"
          }
        }
      }
    ],
    grid: {
      left: 50,
      right: 20,
      top: 30,
      bottom: 25
    },
    series: [
      {
        type: "bar",
        barWidth: 30,
        barMinHeight: 30,
        zlevel: 1,
        itemStyle: {
          normal: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: "rgba(255,193,99,0.85)"
              },
              {
                offset: 1,
                color: "rgba(255,193,99,0.85)"
              }
            ]),
            label: {
              show: true,
              position: "top",
              textStyle: {
                color: "#435B76",
                fontSize: 12,
                fontWeight: "bold"
              }
            }
          }
        },
        data: data
      }
    ]
  };
  echart.setOption(option);
};

// 物业情况图表
export const wyqkEchartDraw = (name, data, nodeId) => {
  let echart = echarts.init(document.getElementById(nodeId));
  let option = {
    xAxis: [
      {
        type: "category",
        data: name,
        lineStyle: {
          color: "#FFFFFF"
        },
        axisLine: {
          show: false,
          lineStyle: {
            color: "#435B76"
          }
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          show: true,
          interval: 0,
          textStyle: {
            fontSize: 12,
            lineHeight: 20
          }
        }
      }
    ],
    yAxis: [
      {
        type: "value",
        axisLine: {
          show: false,
          lineStyle: {
            color: "#435B76"
          }
        },
        axisLabel: {
          show: true
        },
        axisTick: {
          show: false
        },
        splitLine: {
          lineStyle: {
            color: "#EBEBEB"
          }
        }
      }
    ],
    grid: {
      left: 50,
      right: 0,
      top: 30,
      bottom: 25
    },
    series: [
      {
        type: "bar",
        barWidth: 30,
        barMinHeight: 30,
        zlevel: 1,
        itemStyle: {
          normal: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: "rgba(123,237,237,0.85)"
              },
              {
                offset: 1,
                color: "rgba(123,237,237,0.85)"
              }
            ]),
            label: {
              show: true,
              position: "top",
              textStyle: {
                color: "#435B76",
                fontSize: 12,
                fontWeight: "bold"
              }
            }
          }
        },
        data: data
      }
    ]
  };
  echart.setOption(option);
};

// 党建情况柱状图
export const djqkEchartDraw = (name, data, nodeId) => {
  var djqkDraw = echarts.init(document.getElementById(nodeId));
  var djqkOption = {
    xAxis: [
      {
        type: "category",
        data: name,
        lineStyle: {
          color: "#FFFFFF"
        },
        axisLine: {
          show: false,
          lineStyle: {
            color: "#435B76"
          }
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          show: true,
          interval: 0,
          textStyle: {
            fontSize: 12,
            lineHeight: 20
          }
        }
      }
    ],
    yAxis: [
      {
        type: "value",
        axisLine: {
          show: false,
          lineStyle: {
            color: "#435B76"
          }
        },
        axisLabel: {
          show: true
        },
        axisTick: {
          show: false
        },
        splitLine: {
          lineStyle: {
            color: "#EBEBEB"
          }
        }
      }
    ],
    grid: {
      left: 50,
      right: 0,
      top: 30,
      bottom: 25
    },
    series: [
      {
        type: "bar",
        barWidth: 40,
        barMinHeight: 30,
        zlevel: 1,
        itemStyle: {
          normal: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: "rgba(123,237,237,0.85)"
              },
              {
                offset: 1,
                color: "rgba(123,237,237,0.85)"
              }
            ]),
            label: {
              show: true,
              position: "top",
              textStyle: {
                color: "#435B76",
                fontSize: 12,
                fontWeight: "bold"
              }
            }
          }
        },
        data: data
      }
    ]
  };
  djqkDraw.setOption(djqkOption);
};

// 重大项目圆饼图
export const zdxmPieEchartDraw1 = (data, name, nodeId) => {
  let zdxmPieEchart = echarts.init(document.getElementById(nodeId));
  let zdxmPieOption = {
    color: ["#5B8FF9", "#5AD8A6", "#5D7092"],
    tooltip: {
      trigger: "item",
      formatter: "{b} : {c} ({d}%)"
    },
    legend: {
      top: 0,
      left: "center",
      textStyle: {
        color: "#ffffff",
        fontSize: 16
      },
      data: name,
      icon: "circle", //类型包括 circle，rect ，roundRect，triangle，diamond，pin，arrow，none
      itemWidth: 8, // 设置宽度
      itemHeight: 8, // 设置高度
      itemGap: 8 // 设置间距
    },
    series: [
      {
        type: "pie",
        radius: "55%",
        center: ["50%", "65%"],
        selectedMode: "single",
        data: data,
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: "rgba(0, 0, 0, 0.5)"
          }
        },
        label: {
          formatter: "{c}",
          color: "#FFFFFF",
          fontSize: 18,
          lineHeight: 24
        }
      }
    ]
  };
  zdxmPieEchart.setOption(zdxmPieOption);
};

// 重大项目圆饼图
export const zdxmPieEchartDraw = (data, nodeId) => {
  let zdxmPieEchart = echarts.init(document.getElementById(nodeId));
  let zdxmPieOption = {
    tooltip: {
      trigger: "item"
    },
    legend: {
      icon: "circle", //控制形状
      itemWidth: 9, // 设置icon宽度
      itemHeight: 9, // 设置icon高度
      bottom: "1%",
      left: "left",
      formatter: name => {
        let target;
        for (let i = 0, l = data.length; i < l; i++) {
          if (data[i].name == name) {
            target = data[i].value;
          }
        }
        let res = ["{a|" + name + "}", "{b|" + target + "}"];
        return res.join("\n");
      },
      textStyle: {
        rich: {
          a: {
            fontSize: 14,
            align: "left",
            padding: [25, 0, 0, 5]
          },
          b: {
            fontSize: 18,
            fontFamily: "MicrosoftYaHei-Bold",
            color: "#2B9AFF",
            fontWeight: 700,
            align: "right",
            padding: [5, 0, 0, 0]
          }
        }
      }
    },
    series: [
      {
        type: "pie",
        radius: ["40%", "70%"],
        center: ["48%", "40%"],
        avoidLabelOverlap: false,
        label: {
          show: false,
          position: "center"
        },
        emphasis: {
          label: {
            show: false,
            fontSize: "40",
            fontWeight: "bold"
          }
        },
        labelLine: {
          show: true
        },
        data: data
      }
    ]
  };
  zdxmPieEchart.setOption(zdxmPieOption);
};

// 重大项目图表
export const zdxmEchartDraw = (name, data, nodeId) => {
  let zdxmEchart = echarts.init(document.getElementById(nodeId));
  let zdxmEchartOption = {
    xAxis: [
      {
        type: "category",
        data: name,
        lineStyle: {
          color: "#FFFFFF"
        },
        axisLine: {
          show: false,
          lineStyle: {
            color: "#435B76"
          }
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          show: true,
          interval: 0,
          textStyle: {
            fontSize: 12,
            lineHeight: 20
          }
        }
      }
    ],
    yAxis: [
      {
        type: "value",
        axisLine: {
          show: false,
          lineStyle: {
            color: "#435B76"
          }
        },
        axisLabel: {
          show: true
        },
        axisTick: {
          show: false
        },
        splitLine: {
          lineStyle: {
            color: "#EBEBEB"
          }
        }
      }
    ],
    grid: {
      left: 50,
      right: 0,
      top: 30,
      bottom: 25
    },
    series: [
      {
        type: "bar",
        barWidth: 20,
        barMinHeight: 30,
        zlevel: 1,
        itemStyle: {
          normal: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: "rgba(255,193,99,0.85)"
              },
              {
                offset: 1,
                color: "rgba(255,193,99,0.85)"
              }
            ]),
            label: {
              show: true,
              position: "top",
              textStyle: {
                color: "#435B76",
                fontSize: 12,
                fontWeight: "bold"
              }
            }
          }
        },
        data: data
      }
    ]
  };
  zdxmEchart.setOption(zdxmEchartOption);
};
