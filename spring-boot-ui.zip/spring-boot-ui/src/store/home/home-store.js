export const gqtjData = [
  {
    name: "企业数量",
    dataList: [
      {
        district: "福田区",
        amount: 15.0,
        unit: "个"
      },
      {
        district: "罗湖区",
        amount: 31.0,
        unit: "个"
      },
      {
        district: "盐田区",
        amount: 17.0,
        unit: "个"
      },
      {
        district: "南山区",
        amount: 29.0,
        unit: "个"
      },
      {
        district: "宝安区",
        amount: 256.0,
        unit: "个"
      },
      {
        district: "龙岗区",
        amount: 152.0,
        unit: "个"
      },
      {
        district: "龙华区",
        amount: 169.0,
        unit: "个"
      },
      {
        district: "坪山区",
        amount: 186.0,
        unit: "个"
      },
      {
        district: "光明区",
        amount: 56.0,
        unit: "个"
      },
      {
        district: "大鹏新区",
        amount: 95.0,
        unit: "个"
      }
    ]
  },
  {
    name: "总资产",
    dataList: [
      {
        district: "福田区",
        amount: 92.4500000000000028421709430404007434844970703125,
        unit: "亿元"
      },
      {
        district: "罗湖区",
        amount: 87.81000000000000227373675443232059478759765625,
        unit: "亿元"
      },
      {
        district: "盐田区",
        amount: 16.96000000000000085265128291212022304534912109375,
        unit: "亿元"
      },
      {
        district: "南山区",
        amount: 274.68999999999999772626324556767940521240234375,
        unit: "亿元"
      },
      {
        district: "宝安区",
        amount: 740.970000000000027284841053187847137451171875,
        unit: "亿元"
      },
      {
        district: "龙岗区",
        amount: 476.07999999999998408384271897375583648681640625,
        unit: "亿元"
      },
      {
        district: "龙华区",
        amount: 212.969999999999998863131622783839702606201171875,
        unit: "亿元"
      },
      {
        district: "坪山区",
        amount: 105.9899999999999948840923025272786617279052734375,
        unit: "亿元"
      },
      {
        district: "光明区",
        amount: 52.67999999999999971578290569595992565155029296875,
        unit: "亿元"
      },
      {
        district: "大鹏新区",
        amount: 57.409999999999996589394868351519107818603515625,
        unit: "亿元"
      }
    ]
  },
  {
    name: "净资产",
    dataList: [
      {
        district: "福田区",
        amount: 70.599999999999994315658113919198513031005859375,
        unit: "亿元"
      },
      {
        district: "罗湖区",
        amount: 61.6099999999999994315658113919198513031005859375,
        unit: "亿元"
      },
      {
        district: "盐田区",
        amount: 9.32000000000000028421709430404007434844970703125,
        unit: "亿元"
      },
      {
        district: "南山区",
        amount: 131.06999999999999317878973670303821563720703125,
        unit: "亿元"
      },
      {
        district: "宝安区",
        amount: 345.79000000000002046363078989088535308837890625,
        unit: "亿元"
      },
      {
        district: "龙岗区",
        amount: 279.990000000000009094947017729282379150390625,
        unit: "亿元"
      },
      {
        district: "龙华区",
        amount: 125.7000000000000028421709430404007434844970703125,
        unit: "亿元"
      },
      {
        district: "坪山区",
        amount: 43.9200000000000017053025658242404460906982421875,
        unit: "亿元"
      },
      {
        district: "光明区",
        amount: 76.0499999999999971578290569595992565155029296875,
        unit: "亿元"
      },
      {
        district: "大鹏新区",
        amount: 39.38000000000000255795384873636066913604736328125,
        unit: "亿元"
      }
    ]
  },
  {
    name: "营业收入",
    dataList: [
      {
        district: "福田区",
        amount: 8.3300000000000000710542735760100185871124267578125,
        unit: "亿元"
      },
      {
        district: "罗湖区",
        amount: 7.87999999999999989341858963598497211933135986328125,
        unit: "亿元"
      },
      {
        district: "盐田区",
        amount: 0.9699999999999999733546474089962430298328399658203125,
        unit: "亿元"
      },
      {
        district: "南山区",
        amount: 22.469999999999998863131622783839702606201171875,
        unit: "亿元"
      },
      {
        district: "宝安区",
        amount: 78.2999999999999971578290569595992565155029296875,
        unit: "亿元"
      },
      {
        district: "龙岗区",
        amount: 47.1099999999999994315658113919198513031005859375,
        unit: "亿元"
      },
      {
        district: "龙华区",
        amount: 20.370000000000000994759830064140260219573974609375,
        unit: "亿元"
      },
      {
        district: "坪山区",
        amount: 6.36000000000000031974423109204508364200592041015625,
        unit: "亿元"
      },
      {
        district: "光明区",
        amount: 11.1400000000000005684341886080801486968994140625,
        unit: "亿元"
      },
      {
        district: "大鹏新区",
        amount: 2.29000000000000003552713678800500929355621337890625,
        unit: "亿元"
      }
    ]
  },
  {
    name: "利润",
    dataList: [
      {
        district: "福田区",
        amount: 70.599999999999994315658113919198513031005859375,
        unit: "亿元"
      },
      {
        district: "罗湖区",
        amount: 61.6099999999999994315658113919198513031005859375,
        unit: "亿元"
      },
      {
        district: "盐田区",
        amount: 9.32000000000000028421709430404007434844970703125,
        unit: "亿元"
      },
      {
        district: "南山区",
        amount: 131.06999999999999317878973670303821563720703125,
        unit: "亿元"
      },
      {
        district: "宝安区",
        amount: 345.79000000000002046363078989088535308837890625,
        unit: "亿元"
      },
      {
        district: "龙岗区",
        amount: 279.990000000000009094947017729282379150390625,
        unit: "亿元"
      },
      {
        district: "龙华区",
        amount: 125.7000000000000028421709430404007434844970703125,
        unit: "亿元"
      },
      {
        district: "坪山区",
        amount: 43.9200000000000017053025658242404460906982421875,
        unit: "亿元"
      },
      {
        district: "光明区",
        amount: 76.0499999999999971578290569595992565155029296875,
        unit: "亿元"
      },
      {
        district: "大鹏新区",
        amount: 39.38000000000000255795384873636066913604736328125,
        unit: "亿元"
      }
    ]
  },
  {
    name: "净利润",
    dataList: [
      {
        district: "福田区",
        amount: 2.0800000000000000710542735760100185871124267578125,
        unit: "亿元"
      },
      {
        district: "罗湖区",
        amount: 2.060000000000000053290705182007513940334320068359375,
        unit: "亿元"
      },
      {
        district: "盐田区",
        amount: 0,
        unit: "亿元"
      },
      {
        district: "南山区",
        amount: 5.5999999999999996447286321199499070644378662109375,
        unit: "亿元"
      },
      {
        district: "宝安区",
        amount: 37.0499999999999971578290569595992565155029296875,
        unit: "亿元"
      },
      {
        district: "龙岗区",
        amount: 21.019999999999999573674358543939888477325439453125,
        unit: "亿元"
      },
      {
        district: "龙华区",
        amount: 0.59999999999999997779553950749686919152736663818359375,
        unit: "亿元"
      },
      {
        district: "坪山区",
        amount: 4.2400000000000002131628207280300557613372802734375,
        unit: "亿元"
      },
      {
        district: "光明区",
        amount: -0.93000000000000004884981308350688777863979339599609375,
        unit: "亿元"
      },
      {
        district: "大鹏新区",
        amount: 1.149999999999999911182158029987476766109466552734375,
        unit: "亿元"
      }
    ]
  },
  {
    name: "税金",
    dataList: [
      {
        district: "福田区",
        amount: 1.6799999999999999378275106209912337362766265869140625,
        unit: "亿元"
      },
      {
        district: "罗湖区",
        amount: 0.91000000000000003108624468950438313186168670654296875,
        unit: "亿元"
      },
      {
        district: "盐田区",
        amount: 0.1700000000000000122124532708767219446599483489990234375,
        unit: "亿元"
      },
      {
        district: "南山区",
        amount: 8.769999999999999573674358543939888477325439453125,
        unit: "亿元"
      },
      {
        district: "宝安区",
        amount: 4.61000000000000031974423109204508364200592041015625,
        unit: "亿元"
      },
      {
        district: "龙岗区",
        amount: 0.4699999999999999733546474089962430298328399658203125,
        unit: "亿元"
      },
      {
        district: "龙华区",
        amount: 0.89000000000000001332267629550187848508358001708984375,
        unit: "亿元"
      },
      {
        district: "坪山区",
        amount: 0.419999999999999984456877655247808434069156646728515625,
        unit: "亿元"
      },
      {
        district: "光明区",
        amount: 0.450000000000000011102230246251565404236316680908203125,
        unit: "亿元"
      },
      {
        district: "大鹏新区",
        amount: 0.1600000000000000033306690738754696212708950042724609375,
        unit: "亿元"
      }
    ]
  }
];

export const qygkData = [
  {
    yearmonth: "202012",
    district: "",
    entType: "全市合计",
    typeOrder: null,
    entNum: 1006,
    entNumUnit: "家",
    empNum: 389864,
    empNumUnit: "个",
    totalAssets: 2198.05999999999994543031789362430572509765625,
    totalAssetsUnit: "亿元",
    netAssets: 1183.4600000000000363797880709171295166015625,
    netAssetsUnit: "亿元",
    takingAmount: 205.280000000000001136868377216160297393798828125,
    takingAmountUnit: "亿元",
    profitAmount: 72.900000000000005684341886080801486968994140625,
    profitAmountUnit: "亿元",
    netProfit: 68.8900000000000005684341886080801486968994140625,
    netProfitUnit: "亿元",
    tax: 18.559999999999998721023075631819665431976318359375,
    taxUnit: "亿元"
  },
  {
    yearmonth: "202012",
    district: "",
    entType: "市级集体企业",
    typeOrder: null,
    entNum: 0,
    entNumUnit: "家",
    empNum: 0,
    empNumUnit: "个",
    totalAssets: 0,
    totalAssetsUnit: "元",
    netAssets: 0,
    netAssetsUnit: "元",
    takingAmount: 0,
    takingAmountUnit: "元",
    profitAmount: 0,
    profitAmountUnit: "元",
    netProfit: 0,
    netProfitUnit: "元",
    tax: 0,
    taxUnit: "元"
  },
  {
    yearmonth: "202012",
    district: "",
    entType: "股份合作公司",
    typeOrder: null,
    entNum: 987,
    entNumUnit: "家",
    empNum: 357321,
    empNumUnit: "个",
    totalAssets: 2191.829999999999927240423858165740966796875,
    totalAssetsUnit: "亿元",
    netAssets: 1180.01999999999998181010596454143524169921875,
    netAssetsUnit: "亿元",
    takingAmount: 204.349999999999994315658113919198513031005859375,
    takingAmountUnit: "亿元",
    profitAmount: 72.6700000000000017053025658242404460906982421875,
    profitAmountUnit: "亿元",
    netProfit: 68.6200000000000045474735088646411895751953125,
    netProfitUnit: "亿元",
    tax: 18.3599999999999994315658113919198513031005859375,
    taxUnit: "亿元"
  },
  {
    yearmonth: "202012",
    district: "",
    entType: "供销企业",
    typeOrder: null,
    entNum: 19,
    entNumUnit: "家",
    empNum: 32543,
    empNumUnit: "个",
    totalAssets: 6.230000000000000426325641456060111522674560546875,
    totalAssetsUnit: "亿元",
    netAssets: 3.439999999999999946709294817992486059665679931640625,
    netAssetsUnit: "亿元",
    takingAmount: 9311.309999999999490682967007160186767578125,
    takingAmountUnit: "万元",
    profitAmount: 2715.6199999999998908606357872486114501953125,
    profitAmountUnit: "万元",
    netProfit: 2216.3000000000001818989403545856475830078125,
    netProfitUnit: "万元",
    tax: 2062.63999999999987267074175179004669189453125,
    taxUnit: "万元"
  },
  {
    yearmonth: "202012",
    district: "",
    entType: "街道集体企业",
    typeOrder: null,
    entNum: 0,
    entNumUnit: "家",
    empNum: 0,
    empNumUnit: "个",
    totalAssets: 0,
    totalAssetsUnit: "元",
    netAssets: 0,
    netAssetsUnit: "元",
    takingAmount: 0,
    takingAmountUnit: "元",
    profitAmount: 0,
    profitAmountUnit: "元",
    netProfit: 0,
    netProfitUnit: "元",
    tax: 0,
    taxUnit: "元"
  }
];

export const qygkOrderData = [
  {
    colName: "总资产",
    entDetailList: [
      {
        entName: "深圳市怀德股份合作公司",
        entLogo: null,
        label: "总资产",
        value: 76.8700000000000045474735088646411895751953125,
        unit: "亿元"
      },
      {
        entName: "深圳市塘尾股份合作公司",
        entLogo: null,
        label: "总资产",
        value: 73.7399999999999948840923025272786617279052734375,
        unit: "亿元"
      },
      {
        entName: "深圳市蛇口湾厦实业股份有限公司",
        entLogo: null,
        label: "总资产",
        value: 65.68000000000000682121026329696178436279296875,
        unit: "亿元"
      },
      {
        entName: "深圳市大冲实业股份有限公司",
        entLogo: null,
        label: "总资产",
        value: 38.82000000000000028421709430404007434844970703125,
        unit: "亿元"
      },
      {
        entName: "深圳市坂田实业集团股份有限公司",
        entLogo: null,
        label: "总资产",
        value: 37.00999999999999801048033987171947956085205078125,
        unit: "亿元"
      }
    ]
  },
  {
    colName: "营业收入",
    entDetailList: [
      {
        entName: "深圳市塘尾股份合作公司",
        entLogo: null,
        label: "营业收入",
        value: 7.38999999999999968025576890795491635799407958984375,
        unit: "亿元"
      },
      {
        entName: "深圳市怀德股份合作公司",
        entLogo: null,
        label: "营业收入",
        value: 5.42999999999999971578290569595992565155029296875,
        unit: "亿元"
      },
      {
        entName: "深圳市大冲实业股份有限公司",
        entLogo: null,
        label: "营业收入",
        value: 3.649999999999999911182158029987476766109466552734375,
        unit: "亿元"
      },
      {
        entName: "深圳市田厦实业股份有限公司",
        entLogo: null,
        label: "营业收入",
        value: 2.850000000000000088817841970012523233890533447265625,
        unit: "亿元"
      },
      {
        entName: "深圳市龙岗南联股份合作公司",
        entLogo: null,
        label: "营业收入",
        value: 2.600000000000000088817841970012523233890533447265625,
        unit: "亿元"
      }
    ]
  },
  {
    colName: "净利润",
    entDetailList: [
      {
        entName: "深圳市塘尾股份合作公司",
        entLogo: null,
        label: "净利润",
        value: 6.4000000000000003552713678800500929355621337890625,
        unit: "亿元"
      },
      {
        entName: "深圳市怀德股份合作公司",
        entLogo: null,
        label: "净利润",
        value: 5.519999999999999573674358543939888477325439453125,
        unit: "亿元"
      },
      {
        entName: "深圳市龙岗南联股份合作公司",
        entLogo: null,
        label: "净利润",
        value: 1.649999999999999911182158029987476766109466552734375,
        unit: "亿元"
      },
      {
        entName: "      深圳市大冲实业股份有限公司",
        entLogo: null,
        label: "净利润",
        value: 1.6399999999999999023003738329862244427204132080078125,
        unit: "亿元"
      },
      {
        entName: "深圳市桥头股份合作公司",
        entLogo: null,
        label: "净利润",
        value: 1.29000000000000003552713678800500929355621337890625,
        unit: "亿元"
      }
    ]
  },
  {
    colName: "土地面积",
    entDetailList: [
      {
        entName: "深圳市南澳西涌股份合作公司",
        entLogo: null,
        label: "土地面积",
        value: 1355.240000000000009094947017729282379150390625,
        unit: "万m2"
      },
      {
        entName: "深圳市楼村股份有限公司",
        entLogo: null,
        label: "土地面积",
        value: 1038.420000000000072759576141834259033203125,
        unit: "万m2"
      },
      {
        entName: "东山高岭股份合作公司",
        entLogo: null,
        label: "土地面积",
        value: 804.6200000000000045474735088646411895751953125,
        unit: "万m2"
      },
      {
        entName: "深圳市红星股份有限公司",
        entLogo: null,
        label: "土地面积",
        value: 720.6000000000000227373675443232059478759765625,
        unit: "万m2"
      },
      {
        entName: "深圳市葵涌溪新股份合作公司",
        entLogo: null,
        label: "土地面积",
        value: 716.7100000000000363797880709171295166015625,
        unit: "万m2"
      }
    ]
  },
  {
    colName: "物业面积",
    entDetailList: [
      {
        entName: "深圳市横岗四联股份合作公司",
        entLogo: null,
        label: "物业面积",
        value: 303.8500000000000227373675443232059478759765625,
        unit: "万m2"
      },
      {
        entName: "深圳市怀德股份合作公司",
        entLogo: null,
        label: "物业面积",
        value: 263.3600000000000136424205265939235687255859375,
        unit: "万m2"
      },
      {
        entName: "深圳市燕川实业股份合作公司",
        entLogo: null,
        label: "物业面积",
        value: 184.43999999999999772626324556767940521240234375,
        unit: "万m2"
      },
      {
        entName: "深圳市新和股份合作公司",
        entLogo: null,
        label: "物业面积",
        value: 151.159999999999996589394868351519107818603515625,
        unit: "万m2"
      },
      {
        entName: "深圳市六约股份合作公司",
        entLogo: null,
        label: "物业面积",
        value: 125.0799999999999982946974341757595539093017578125,
        unit: "万m2"
      }
    ]
  },
  {
    colName: "净资产",
    entDetailList: [
      {
        entName: "深圳市大冲实业股份有限公司",
        entLogo: null,
        label: "净资产",
        value: 36.56000000000000227373675443232059478759765625,
        unit: "亿元"
      },
      {
        entName: "深圳市怀德股份合作公司",
        entLogo: null,
        label: "净资产",
        value: 35.99000000000000198951966012828052043914794921875,
        unit: "亿元"
      },
      {
        entName: "深圳市爱联股份合作公司",
        entLogo: null,
        label: "净资产",
        value: 26.440000000000001278976924368180334568023681640625,
        unit: "亿元"
      },
      {
        entName: "深圳市坂田实业集团股份有限公司",
        entLogo: null,
        label: "净资产",
        value: 25.870000000000000994759830064140260219573974609375,
        unit: "亿元"
      },
      {
        entName: "深圳市南岗实业股份有限公司",
        entLogo: null,
        label: "净资产",
        value: 20.719999999999998863131622783839702606201171875,
        unit: "亿元"
      }
    ]
  },
  {
    colName: "利润",
    entDetailList: [
      {
        entName: "深圳市大冲实业股份有限公司",
        entLogo: null,
        label: "利润",
        value: 36.56000000000000227373675443232059478759765625,
        unit: "亿元"
      },
      {
        entName: "深圳市怀德股份合作公司",
        entLogo: null,
        label: "利润",
        value: 35.99000000000000198951966012828052043914794921875,
        unit: "亿元"
      },
      {
        entName: "深圳市爱联股份合作公司",
        entLogo: null,
        label: "利润",
        value: 26.440000000000001278976924368180334568023681640625,
        unit: "亿元"
      },
      {
        entName: "深圳市坂田实业集团股份有限公司",
        entLogo: null,
        label: "利润",
        value: 25.870000000000000994759830064140260219573974609375,
        unit: "亿元"
      },
      {
        entName: "深圳市南岗实业股份有限公司",
        entLogo: null,
        label: "利润",
        value: 20.719999999999998863131622783839702606201171875,
        unit: "亿元"
      }
    ]
  },
  {
    colName: "税金",
    entDetailList: [
      {
        entName: "深圳市田厦实业股份有限公司",
        entLogo: null,
        label: "税金",
        value: 1.649999999999999911182158029987476766109466552734375,
        unit: "亿元"
      },
      {
        entName: "      深圳市大冲实业股份有限公司",
        entLogo: null,
        label: "税金",
        value: 1.62000000000000010658141036401502788066864013671875,
        unit: "亿元"
      },
      {
        entName: "深圳市塘尾股份合作公司",
        entLogo: null,
        label: "税金",
        value: 1.0700000000000000621724893790087662637233734130859375,
        unit: "亿元"
      },
      {
        entName: "深圳市皇岗实业股份有限公司",
        entLogo: null,
        label: "税金",
        value: 8323,
        unit: "万元"
      },
      {
        entName: "深圳市平山实业股份有限公司",
        entLogo: null,
        label: "税金",
        value: 5477.670000000000072759576141834259033203125,
        unit: "万元"
      }
    ]
  }
];

export const tdqkData = [
  {
    district: "福田区",
    landType: null,
    area: 250.340000000000003410605131648480892181396484375,
    areaUnit: "万m²"
  },
  {
    district: "罗湖区",
    landType: null,
    area: 564.029999999999972715158946812152862548828125,
    areaUnit: "万m²"
  },
  {
    district: "盐田区",
    landType: null,
    area: 17.730000000000000426325641456060111522674560546875,
    areaUnit: "万m²"
  },
  {
    district: "南山区",
    landType: null,
    area: 1605.339999999999918145476840436458587646484375,
    areaUnit: "万m²"
  },
  {
    district: "宝安区",
    landType: null,
    area: 9823.95000000000072759576141834259033203125,
    areaUnit: "万m²"
  },
  {
    district: "龙岗区",
    landType: null,
    area: 4134.77000000000043655745685100555419921875,
    areaUnit: "万m²"
  },
  {
    district: "龙华区",
    landType: null,
    area: 1735.660000000000081854523159563541412353515625,
    areaUnit: "万m²"
  },
  {
    district: "坪山区",
    landType: null,
    area: 1090.930000000000063664629124104976654052734375,
    areaUnit: "万m²"
  },
  {
    district: "光明区",
    landType: null,
    area: 2713.88999999999987267074175179004669189453125,
    areaUnit: "万m²"
  },
  {
    district: "大鹏新区",
    landType: null,
    area: 9191.75,
    areaUnit: "万m²"
  }
];

export const wyqkData = [
  {
    district: "福田区",
    propertyType: null,
    area: 174.719999999999998863131622783839702606201171875,
    areaUnit: "万m²"
  },
  {
    district: "罗湖区",
    propertyType: null,
    area: 201.759999999999990905052982270717620849609375,
    areaUnit: "万m²"
  },
  {
    district: "盐田区",
    propertyType: null,
    area: 36.43999999999999772626324556767940521240234375,
    areaUnit: "万m²"
  },
  {
    district: "南山区",
    propertyType: null,
    area: 609.1499999999999772626324556767940521240234375,
    areaUnit: "万m²"
  },
  {
    district: "宝安区",
    propertyType: null,
    area: 4694.5600000000004001776687800884246826171875,
    areaUnit: "万m²"
  },
  {
    district: "龙岗区",
    propertyType: null,
    area: 2339.9600000000000363797880709171295166015625,
    areaUnit: "万m²"
  },
  {
    district: "龙华区",
    propertyType: null,
    area: 990.7899999999999636202119290828704833984375,
    areaUnit: "万m²"
  },
  {
    district: "坪山区",
    propertyType: null,
    area: 574.0900000000000318323145620524883270263671875,
    areaUnit: "万m²"
  },
  {
    district: "光明区",
    propertyType: null,
    area: 1141.0399999999999636202119290828704833984375,
    areaUnit: "万m²"
  },
  {
    district: "大鹏新区",
    propertyType: null,
    area: 204.009999999999990905052982270717620849609375,
    areaUnit: "万m²"
  }
];

export const zdxmData = [
  {
    district: "福田区",
    processNum: 2,
    processNumUnit: "个",
    expectNum: 1,
    expectNumUnit: "个"
  },
  {
    district: "罗湖区",
    processNum: 0,
    processNumUnit: "个",
    expectNum: 0,
    expectNumUnit: "个"
  },
  {
    district: "盐田区",
    processNum: 0,
    processNumUnit: "个",
    expectNum: 0,
    expectNumUnit: "个"
  },
  {
    district: "南山区",
    processNum: 25,
    processNumUnit: "个",
    expectNum: 4,
    expectNumUnit: "个"
  },
  {
    district: "宝安区",
    processNum: 40,
    processNumUnit: "个",
    expectNum: 24,
    expectNumUnit: "个"
  },
  {
    district: "龙岗区",
    processNum: 101,
    processNumUnit: "个",
    expectNum: 22,
    expectNumUnit: "个"
  },
  {
    district: "龙华区",
    processNum: 0,
    processNumUnit: "个",
    expectNum: 0,
    expectNumUnit: "个"
  },
  {
    district: "坪山区",
    processNum: 0,
    processNumUnit: "个",
    expectNum: 0,
    expectNumUnit: "个"
  },
  {
    district: "光明区",
    processNum: 0,
    processNumUnit: "个",
    expectNum: 0,
    expectNumUnit: "个"
  },
  {
    district: "大鹏新区",
    processNum: 4,
    processNumUnit: "个",
    expectNum: 9,
    expectNumUnit: "个"
  },
  {
    district: "深汕特别合作区",
    processNum: 0,
    processNumUnit: "个",
    expectNum: 0,
    expectNumUnit: "个"
  }
];

export const djqkData = {
  nameArray: [
    "福田区",
    "罗湖区",
    "盐田区",
    "南山区",
    "宝安区",
    "龙岗区",
    "龙华区",
    "坪山区",
    "光明区",
    "大鹏新区"
  ],
  data: [33, 187, 17, 29, 123, 15, 169, 20, 42, 52]
};
