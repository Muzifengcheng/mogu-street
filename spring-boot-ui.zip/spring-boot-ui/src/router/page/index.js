import Layout from '@/page/index/'

export default [{
  path: '/login',
  name: '登录页',
  component: () =>
    import( /* webpackChunkName: "page" */ '@/page/login/index'),
  meta: {
    keepAlive: true,
    isTab: false,
    isAuth: false
  }
},
  {
    path: '/lock',
    name: '锁屏页',
    component: () =>
      import( /* webpackChunkName: "page" */ '@/page/lock/index'),
    meta: {
      keepAlive: true,
      isTab: false,
      isAuth: false
    }
  },
  {
    path: '/404',
    component: () =>
      import( /* webpackChunkName: "page" */ '@/components/error-page/404'),
    name: '404',
    meta: {
      keepAlive: true,
      isTab: false,
      isAuth: false
    }

  },
  {
    path: '/403',
    component: () =>
      import( /* webpackChunkName: "page" */ '@/components/error-page/403'),
    name: '403',
    meta: {
      keepAlive: true,
      isTab: false,
      isAuth: false
    }
  },
  {
    path: '/500',
    component: () =>
      import( /* webpackChunkName: "page" */ '@/components/error-page/500'),
    name: '500',
    meta: {
      keepAlive: true,
      isTab: false,
      isAuth: false
    }
  },
  {
    path: '/',
    name: '主页',
    redirect: '/wel'
  },
  {
    path: '/myiframe',
    component: Layout,
    redirect: '/myiframe',
    children: [{
      path: ":routerPath",
      name: 'iframe',
      component: () =>
        import( /* webpackChunkName: "page" */ '@/components/iframe/main'),
      props: true
    }]

  },
  // {
  //   path: '/devservice/land-dev-cooperation/edit',
  //   name: '土地开发合作编辑页',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/land-dev-cooperation/edit')
  // },
  // {
  //   path: '/devservice/land-dev-cooperation/list',
  //   name: '土地开发合作列表页',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/land-dev-cooperation/list')
  // },
  // {
  //   path: '/devservice/land-dev-cooperation/add',
  //   name: 'addpage',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/land-dev-cooperation/add')
  // },
  // {
  //   path: '/devservice/land-dev-cooperation/projdetail',
  //   name: 'projdetail',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/land-dev-cooperation/proj-detail')
  // },
  // {
  //   path: '/devservice/land-dev-cooperation/blocks',
  //   name: 'blocks',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/land-dev-cooperation/blocks')
  // },
  // {
  //   path: '/devservice/land-dev-cooperation/blocksdetail',
  //   name: '土地开发合作街道详情页',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/land-dev-cooperation/blocks-detail')
  // },

  // {
  //   path: '/devservice/talents/index',
  //   name: '人才库首页',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/talents/index')
  // },
  // {
  //   path: '/devservice/talents/talentsdistrict',
  //   name: '人才区级',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/talents/talents-district')
  // },

  // {
  //   path: '/devservice/talents/detail',
  //   name: '人才详情',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/talents/detail')
  // },
  // {
  //   path: '/devservice/talents/talentsblocks',
  //   name: '人才街道',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/talents/talents-blocks')
  // },
 
  // {
  //   path: '/devservice/train/index',
  //   name: '历史培训首页',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/train/index')
  // },
  // {
  //   path: '/devservice/train/traindetail',
  //   name: '培训详情',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/train/train-detail')
  // },
  // {
  //   path:'/devservice/train/institutiondetail',
  //   name:'机构详情',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //   import( /* webpackChunkName: "views" */ '@/views/devservice/train/institution-detail')
  // },
  // {
  //   path: '/devservice/train/mutualfoster',
  //   name: '人才互培',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/train/mutual-foster')
  // },
  // {
  //   path: '/devservice/train/mutualfosterdetail',
  //   name: '人才互培详情',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/train/mutual-foster-detail')
  // },
  // {
  //   path: '/devservice/property-manage-cooperation/index',
  //   name: '物业统管合作首页',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/property-manage-cooperation/index')
  // },
  // {
  //   path: '/devservice/property-manage-cooperation/districts',
  //   name: '物业统管合作区级',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/property-manage-cooperation/districts')
  // },
  // {
  //   path: '/devservice/property-manage-cooperation/blocks',
  //   name: '物业统管合作街道',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/property-manage-cooperation/blocks')
  // },
  // {
  //   path: '/devservice/property-manage-cooperation/projdetail',
  //   name: '物业统管合作项目详情',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/property-manage-cooperation/proj-detail')
  // },
  // {
  //   path: '/devservice/industry-cooperation/index',
  //   name: '产业合作首页',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/industry-cooperation/index')
  // },
  // {
  //   path: '/devservice/industry-cooperation/districts',
  //   name: '产业合作区级',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/industry-cooperation/districts')
  // },
  // {
  //   path: '/devservice/industry-cooperation/blocks',
  //   name: '产业合作街道',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/industry-cooperation/blocks')
  // },
  // {
  //   path: '/devservice/industry-cooperation/projdetail',
  //   name: '产业合作项目详情',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/industry-cooperation/proj-detail')
  // },
  // {
  //   path: '/devservice/fund-cooperation/index',
  //   name: '资金合作首页',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/fund-cooperation/index')
  // },
  // {
  //   path: '/devservice/fund-cooperation/districts',
  //   name: '资金合作区级',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/fund-cooperation/districts')
  // },
  // {
  //   path: '/devservice/fund-cooperation/blocks',
  //   name: '资金合作街道',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/fund-cooperation/blocks')
  // },
  // {
  //   path: '/devservice/fund-cooperation/projdetail',
  //   name: '资金合作项目详情',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/fund-cooperation/proj-detail')
  // },
  // {
  //   path: '/devservice/housing-security-cooperation/index',
  //   name: '住房保障合作首页',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/housing-security-cooperation/index')
  // },
  // {
  //   path: '/devservice/housing-security-cooperation/districts',
  //   name: '住房保障合作区级',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/housing-security-cooperation/districts')
  // },
  // {
  //   path: '/devservice/housing-security-cooperation/blocks',
  //   name: '住房保障合作街道',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/housing-security-cooperation/blocks')
  // },
  // {
  //   path: '/devservice/housing-security-cooperation/projdetail',
  //   name: '住房保障合作区级项目详情',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/housing-security-cooperation/proj-detail')
  // },
  // {
  //   path: '/devservice/take-temporary-post-application/index',
  //   name: '挂职申请首页',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/take-temporary-post-application/index')
  // },
  // {
  //   path: '/devservice/take-temporary-post-application/detail',
  //   name: '挂职申请详情',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/take-temporary-post-application/detail')
  // },
  // {
  //   path: '/devservice/take-temporary-post-application/provide',
  //   name: '挂职提供',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/take-temporary-post-application/provide')
  // },
  // {
  //   path: '/devservice/take-temporary-post-application/providedetail',
  //   name: '挂职提供详情',
  //   meta: {
  //     i18n: 'work',
  //     keepAlive: true,
  //     isTab: false,
  //     isAuth: false
  //   },
  //   component: () =>
  //     import( /* webpackChunkName: "views" */ '@/views/devservice/take-temporary-post-application/provide-detail')
  // },
  {
    path: '*',
    redirect: '/404'
  }
]
