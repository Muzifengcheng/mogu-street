import Layout from '@/page/index/'

export default [{
  path: '/wel',
  component: Layout,
  redirect: '/wel/index',
  children: [{
    path: 'index',
    name: '首页',
    meta: {
      i18n: 'dashboard'
    },
    component: () =>
      import( /* webpackChunkName: "views" */ '@/views/wel/index')
  }, {
    path: 'dashboard',
    name: '控制台',
    meta: {
      i18n: 'dashboard',
      menu: false,
    },
    component: () =>
      import( /* webpackChunkName: "views" */ '@/views/wel/dashboard')
  }]
}, {
  path: '/test',
  component: Layout,
  redirect: '/test/index',
  children: [{
    path: 'index',
    name: '测试页',
    meta: {
      i18n: 'test'
    },
    component: () =>
      import( /* webpackChunkName: "views" */ '@/views/util/test')
  }]
}, {
  path: '/dict-horizontal',
  component: Layout,
  redirect: '/dict-horizontal/index',
  children: [{
    path: 'index',
    name: '字典管理',
    meta: {
      i18n: 'dict'
    },
    component: () =>
      import( /* webpackChunkName: "views" */ '@/views/util/demo/dict-horizontal')
  }]
}, {
  path: '/dict-vertical',
  component: Layout,
  redirect: '/dict-vertical/index',
  children: [{
    path: 'index',
    name: '字典管理',
    meta: {
      i18n: 'dict'
    },
    component: () =>
      import( /* webpackChunkName: "views" */ '@/views/util/demo/dict-vertical')
  }]
}, {
  path: '/info',
  component: Layout,
  redirect: '/info/index',
  children: [{
    path: 'index',
    name: '个人信息',
    meta: {
      i18n: 'info'
    },
    component: () =>
      import( /* webpackChunkName: "views" */ '@/views/system/userinfo')
  }]
}, {
  path: '/work/process/leave',
  component: Layout,
  redirect: '/work/process/leave/form',
  children: [{
    path: 'form/:processDefinitionId',
    name: '请假流程',
    meta: {
      i18n: 'work'
    },
    component: () =>
      import( /* webpackChunkName: "views" */ '@/views/work/process/leave/form')
  }, {
    path: 'handle/:taskId/:processInstanceId/:businessId',
    name: '处理请假流程',
    meta: {
      i18n: 'work'
    },
    component: () =>
      import( /* webpackChunkName: "views" */ '@/views/work/process/leave/handle')
  }, {
    path: 'detail/:processInstanceId/:businessId',
    name: '请假流程详情',
    meta: {
      i18n: 'work'
    },
    component: () =>
      import( /* webpackChunkName: "views" */ '@/views/work/process/leave/detail')
  },
  ]
},
{
  path: '/devservice/land-dev-cooperation',
  component: Layout,
  redirect: '/devservice/land-dev-cooperation/index',
  meta: {

  },
  children: [
    {
      path: 'index',
      name: '土地开发合作列表页',
      meta: {},
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/land-dev-cooperation/index')
    },
    {
      path: 'edit',
      name: '土地开发合作编辑页',
      meta: {},
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/land-dev-cooperation/edit')
    },
    {
      path: 'add',
      name: '土地开发合作新增页',
      meta: {},
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/land-dev-cooperation/add')
    },
    {
      path: 'projdetail',
      name: '土地开发合作详情页',
      meta: {},
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/land-dev-cooperation/proj-detail')
    },
    {
      path: 'blocks',
      name: '土地开发合作街道列表页',
      meta: {},
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/land-dev-cooperation/blocks')
    },
    {
      path: 'districts',
      name: '土地开发合作区级列表页',
      meta: {},
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/land-dev-cooperation/districts')
    },
  ]
},
{
  path: '/devservice/fund-cooperation',
  component: Layout,
  redirect: '/devservice/fund-cooperation/index',
  meta: {

  },
  children: [
    {
      path: 'index',
      name: '资金合作首页',
      meta: {},
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/fund-cooperation/index')
    },
    {
      path: 'districts',
      name: '资金合作区级',
      meta: {},
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/fund-cooperation/districts')
    },
    {
      path: 'blocks',
      name: '资金合作街道',
      meta: {},
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/fund-cooperation/blocks')
    },
    {
      path: 'projdetail',
      name: '资金合作项目详情',
      meta: {},
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/fund-cooperation/proj-detail')
    },
    {
      path:'addoredit',
      name:'资金合作项目新增或编辑',
      meta: {

      },
      component: () =>
      import( /* webpackChunkName: "views" */ '@/views/devservice/fund-cooperation/add-or-edit')
    }

  ]
},
{
  path: '/devservice/talents',
  component: Layout,
  redirect: '/devservice/talents/index',
  meta: {

  },
  children: [
    {
      path: 'index',
      name: '人才库首页',
      meta: {},
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/talents/index')
    },
    {
      path: 'talentsdistrict',
      name: '人才区级',
      meta: {},
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/talents/talents-district')
    },
    {
      path: 'talentsblocks',
      name: '人才街道',
      meta: {},
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/talents/talents-blocks')
    },
    {
      path: 'detail/:id',
      name: '人才详情',
      meta: {},
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/talents/detail')
    },
  ]
},
{
  path: '/devservice/train',
  component: Layout,
  redirect: '/devservice/train/index',
  meta: {

  },
  children: [
    {
      path: 'index',
      name: '历史培训首页',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/train/index')
    },
    {
      path: 'traindetail',
      name: '培训详情',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/train/train-detail')
    },
    {
      path:'institutiondetail',
      name:'机构详情',
      meta: {

      },
      component: () =>
      import( /* webpackChunkName: "views" */ '@/views/devservice/train/institution-detail')
    },
    {
      path: 'mutualfoster',
      name: '人才互培',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/train/mutual-foster')
    },
    {
      path: 'mutualfosterdetail',
      name: '人才互培详情',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/train/mutual-foster-detail')
    },
  ]
},
{
  path: '/devservice/property-manage-cooperation',
  component: Layout,
  redirect: '/devservice/property-manage-cooperation/index',
  meta: {

  },
  children: [
    {
      path: 'index',
      name: '物业统管合作首页',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/property-manage-cooperation/index')
    },
    {
      path: 'districts',
      name: '物业统管合作区级',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/property-manage-cooperation/districts')
    },
    {
      path: 'blocks',
      name: '物业统管合作街道',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/property-manage-cooperation/blocks')
    },
    {
      path: 'projdetail',
      name: '物业统管合作项目详情',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/property-manage-cooperation/proj-detail')
    },
    {
      path:'addoredit',
      name:'物业统管合作新增或编辑',
      meta: {

      },
      component: () =>
      import( /* webpackChunkName: "views" */ '@/views/devservice/property-manage-cooperation/add-or-edit')
    }
  ]
},
{
  path: '/devservice/industry-cooperation',
  component: Layout,
  redirect: '/devservice/industry-cooperation/index',
  meta: {

  },
  children: [
    {
      path: 'index',
      name: '产业合作首页',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/industry-cooperation/index')
    },
    {
      path: 'districts',
      name: '产业合作区级',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/industry-cooperation/districts')
    },
    {
      path: 'blocks',
      name: '产业合作街道',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/industry-cooperation/blocks')
    },
    {
      path: 'projdetail',
      name: '产业合作项目详情',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/industry-cooperation/proj-detail')
    },
    {
      path:'addoredit',
      name:'产业合作项目新增或编辑',
      meta: {

      },
      component: () =>
      import( /* webpackChunkName: "views" */ '@/views/devservice/industry-cooperation/add-or-edit')
    }
  ]
},
{
  path: '/devservice/success-case',
  component: Layout,
  redirect: '/devservice/success-case/index',
  meta: {

  },
  children: [
    {
      path: 'index',
      name: '成功案例首页',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/success-case/index')
    },
    {
      path: 'projdetail',
      name: '成功案例项目详情',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/success-case/proj-detail')
    },
    {
      path:'addoredit',
      name:'成功案例新增或编辑',
      meta: {

      },
      component: () =>
      import( /* webpackChunkName: "views" */ '@/views/devservice/success-case/add-or-edit')
    }
  ]
},
{
  path: '/devservice/housing-security-cooperation',
  component: Layout,
  redirect: '/devservice/housing-security-cooperation/index',
  meta: {

  },
  children: [
    {
      path: 'index',
      name: '住房保障合作首页',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/housing-security-cooperation/index')
    },
    {
      path: 'districts',
      name: '住房保障合作区级',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/housing-security-cooperation/districts')
    },
    {
      path: 'blocks',
      name: '住房保障合作街道',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/housing-security-cooperation/blocks')
    },
    {
      path: 'projdetail',
      name: '住房保障合作区级项目详情',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/housing-security-cooperation/proj-detail')
    },
    {
      path:'addoredit',
      name:'住房保障合作项目新增或编辑',
      meta: {

      },
      component: () =>
      import( /* webpackChunkName: "views" */ '@/views/devservice/housing-security-cooperation/add-or-edit')
    }
  ]
},
{
  path: '/devservice/take-temporary-post-application',
  component: Layout,
  redirect: '/devservice/take-temporary-post-application/index',
  meta: {

  },
  children: [
    {
      path: 'index',
      name: '挂职申请首页',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/take-temporary-post-application/index')
    },
    {
      path: 'detail/:id',
      name: '挂职申请详情',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/take-temporary-post-application/detail')
    },
    {
      path: 'provide',
      name: '挂职提供',
      meta: {
        // i18n: 'work',
        // keepAlive: true,
        // isTab: false,
        // isAuth: false
      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/take-temporary-post-application/provide')
    },
    {
      path: 'providedetail',
      name: '挂职提供详情',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/devservice/take-temporary-post-application/provide-detail')
    },
  ]
},
{
  path: '/statistics-report/finance-rank-statis-report',
  component: Layout,
  redirect: '/statistics-report/finance-rank-statis-report/index',
  meta: {

  },
  children: [
    {
      path: 'index',
      name: '财务指标统计表',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/statistics-report/finance-rank-statis-report/index')
    },
  ]
},
{
  path: '/statistics-report/dept-rank-detail-report',
  component: Layout,
  redirect: '/statistics-report/dept-rank-detail-report/index',
  meta: {

  },
  children: [
    {
      path: 'index',
      name: '资债指标明细表',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/statistics-report/dept-rank-detail-report/index')
    },
  ]
},
{
  path: '/statistics-report/benefit-rank-detail-report',
  component: Layout,
  redirect: '/statistics-report/benefit-rank-detail-report/index',
  meta: {

  },
  children: [
    {
      path: 'index',
      name: '效益指标明细表',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/statistics-report/benefit-rank-detail-report/index')
    },
  ]
},
{
  path: '/statistics-report/break-rent-statis-report',
  component: Layout,
  redirect: '/statistics-report/break-rent-statis-report/index',
  meta: {

  },
  children: [
    {
      path: 'index',
      name: '减免租金统计表',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/statistics-report/break-rent-statis-report/index')
    },
  ]
},
{
  path: '/statistics-report/zbpmbb',
  component: Layout,
  redirect: '/statistics-report/zbpmbb/index',
  meta: {

  },
  children: [
    {
      path: 'index',
      name: '指标排名报表',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/statistics-report/zbpmbb/index')
    },
  ]
},
{
  path: '/business-letters/cwzbkb',
  component: Layout,
  redirect: '/business-letters/cwzbkb/index',
  meta: {

  },
  children: [
    {
      path: 'index',
      name: '财务指标排名快报',
      meta: {

      },
      component: () =>
        import( /* webpackChunkName: "views" */ '@/views/business-letters/cwzbkb/index')
    },
  ]
},

]
