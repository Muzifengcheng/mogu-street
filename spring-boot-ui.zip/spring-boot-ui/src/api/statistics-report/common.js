import request from '@/router/axios';

// 财务指标表
export const getFinanceList = (param) => {
    return request({
      url: '/api/reformDev/reportStatis/financeList',
      method: 'get',
      params:param
    })
  }
// 资债指标表
export const getDeptList = (param) => {
    return request({
      url: '/api/reformDev/reportStatis/deptList',
      method: 'get',
      params:param
    })
  }
// 效益指标表
export const getBenefitList = (param) => {
    return request({
      url: '/api/reformDev/reportStatis/benefitList',
      method: 'get',
      params:param
    })
  }

//指标排名报表  （土地、物业、资产总额排名前十名）
export const getTopTenList = (param) => {
  return request({
    url: '/api/reformDev/reportStatis/entRankTopTenResult',
    method: 'get',
    params:param
  })
}
