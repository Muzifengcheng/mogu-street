import request from '@/router/axios';

  //街道list
  export const getCompanyCoopSuccessCaseList = (param) => {
    return request({
      url: '/api/reformDev/companyCoopSuccessCase/list',
      method: 'get',
      params:param
    })
  }
  // 新增和修改
  export const addCompanyCoopSuccessCase = (param)=>{
    return request({
      url: '/api/reformDev/companyCoopSuccessCase/submit',
      method: 'post',
      data:param
    })
  }
  
  //项目详情
export const getCompanyCoopSuccessCaseDetail = (param) =>{
  return request({
    url: '/api/reformDev/companyCoopSuccessCase/detail',
    method: 'get',
    params:param
  })
}

//街道表格批量删除
export const removeCompanyCoopSuccessCase = (ids)=>{
  return request({
    url: '/api/reformDev/companyCoopSuccessCase/remove',
    method: 'post',
    params: {
      ids,
    }
  })
}