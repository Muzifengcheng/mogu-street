import request from '@/router/axios';

// export const getPrimaryDataArea = (code) => {
//     return request({
//       url: '/api/primaryDataArea/primarydataarea/tree',
//       method: 'get',
//       params: {
//         code
//       }
//     })
//   }
export const getTalentPool = (param) => {
    return request({
      url: '/api/talent/talentPool/groupby',
      method: 'get',
      params:param
    })
  }

