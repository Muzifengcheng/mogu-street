import request from '@/router/axios';

  //街道list
  export const getCompanyCoopBasicBlockList = (param) => {
    return request({
      url: '/api/develop/companyCoopBasicInfo/list',
      method: 'get',
      params:param
    })
  }
  // 新增和修改
  export const addCompanyCoopBasic = (param)=>{
    return request({
      url: '/api/develop/companyCoopBasicInfo/submit',
      method: 'post',
      data:param
    })
  }
  
  //项目详情
export const getCompanyCoopBasicInfoDetail = (param) =>{
  return request({
    url: '/api/develop/companyCoopBasicInfo/detail',
    method: 'get',
    params:param
  })
}

//街道表格批量删除
export const removeCompanyCoopBasic = (ids)=>{
  return request({
    url: '/api/develop/companyCoopBasicInfo/remove',
    method: 'post',
    params: {
      ids,
    }
  })
}