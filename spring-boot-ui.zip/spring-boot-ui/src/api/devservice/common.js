import request from '@/router/axios';

export const getPrimaryDataArea = (code) => {
    return request({
      url: '/api/primaryDataArea/primarydataarea/tree',
      method: 'get',
      params: {
        code
      }
    })
  }
//所有首页的各区的table
  export const getCompanyCoopBasic = (param) => {
    return request({
      url: '/api/develop/companyCoopBasicInfo/groupBy',
      method: 'get',
      params:param
    })
  }