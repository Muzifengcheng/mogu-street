import request from '@/router/axios';

// 财务指标排名快报（有导出、打印）
export const getExportReport = (param) => {
    return request({
      url: '/api/reformDev/reportStatis/exportReport',
      method: 'get',
      params:param
    })
  }