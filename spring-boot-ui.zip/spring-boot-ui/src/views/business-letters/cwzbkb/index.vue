<template>
  <div id="cwzbkb">
    <el-row>
      <el-col>
        <el-scrollbar>
          <basic-container class="right-content">
            <div class="limit-chose mt20">
              <span>
                时间：
                <el-date-picker
                  v-model="value1"
                  type="month"
                  placeholder="选择月"
                  value-format="yyyyMM"
                >
                </el-date-picker>
              </span>
              <span class="search_reset ml20">
                <el-button type="primary" icon="el-icon-search" @click="search"
                  >查询</el-button
                >
              </span>
            </div>

            <el-table
              :data="tableData"
              class="mt20"
              :header-cell-style="{
                background: '#F4F7FA',
                fontWeight: '700',
                color: '#435B76',
              }"
            >
              <el-table-column
                align="center"
                label="快报名称"
                prop="reportName"
              >
              </el-table-column>
              <el-table-column align="center" prop="monthDate" label="月份">
              </el-table-column>
              <el-table-column label="操作" align="center">
                <template v-slot="scope">
                   <el-button type="primary" @click="outputBtn()"
                    >导出</el-button
                  >
                  <!-- <a id="linkUrl" :href="downloadUrl" target="_blank"> 导出 </a> -->

                  <el-button type="primary" @click="printingBtn(scope.row)">
                    打印</el-button
                  >
                </template>
              </el-table-column>
            </el-table>
          </basic-container></el-scrollbar
        >
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { getExportReport } from "@/api/business-letters/cwzbkb";
import { download } from "@/util/download";
export default {
  data() {
    return {
      value1: "202009",
      tableData: [
        {
          reportName: "深圳市股份合作公司主要财务指标快报",
          monthDate: "2020年9月",
        },
      ],
      paginations: {
        page_index: 1, //当前位于那页
        total: 0, //总数
        page_size: 10, //一页显示多少个
        layout: "prev,pager,next,jumper", //翻页属性
      },
      downloadUrl: `http://14.18.187.88:2001/bladex-2.7.0/%E6%B7%B1%E5%9C%B3%E5%B8%82%E8%82%A1%E4%BB%BD%E5%90%88%E4%BD%9C%E5%85%AC%E5%8F%B8%E4%B8%BB%E8%A6%81%E8%B4%A2%E5%8A%A1%E6%8C%87%E6%A0%87%E5%BF%AB%E6%8A%A5%EF%BC%882020%E5%B9%B49%E6%9C%88%EF%BC%89.doc?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=D99KGE6ZTQXSATTJWU24%2F20210129%2F%2Fs3%2Faws4_request&X-Amz-Date=20210129T010126Z&X-Amz-Expires=432000&X-Amz-SignedHeaders=host&X-Amz-Signature=fcdf81158d6a94f8532cac25b666ea320636d3e34068a6dcf454d176d4454eca`,
      // titleArr:["序号","项目","单位","本年累计（期末数）","上年同期","增减额",]
    };
  },
  created() {
  },
  methods: {
    outputBtn() {
      /*       download(`http://14.18.187.88:2001/bladex-2.7.0/%E6%B7%B1%E5%9C%B
      3%E5%B8%82%E8%82%A1%E4%BB%BD%E5%90%88%E4%BD%9C%E5%85%AC%E5%8F%B8%E4%B8%BB%E8%A6%8
      1%E8%B4%A2%E5%8A%A1%E6%8C%87%E6%A0%87%E5%BF%AB%E6%8A%A5%EF%BC%882020%E5%B9%B49%E6%9C%88%EF%BC%89.doc?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-A
      mz-Credential=D99KGE6ZTQXSATTJWU24%2F20210129%2F%2Fs3%2Faws4_request&X-Amz-Date=20210129T010126Z&X-Amz-Expires=432000&X-Amz-SignedHeaders=
      host&X-Amz-Signature=fcdf81158d6a94f8532cac25b666ea320636d3e34068a6dcf454d176d4454eca`,row.reportName+"-"+row.monthDate) */
      this.getExportReportFun()
    },
    printingBtn() {
      //打印浏览器当前页面
/*       window.location.href = this.downloadUrl;
      window.print(); */
    },
    getExportReportFun() {
      let params = {};
      params.yearmonth = this.value1;
      this.loading=true
      getExportReport(params)
        .then(res => {
          var contentDisposition = res.headers["content-disposition"];
          let filenameEncode = contentDisposition.slice(
            contentDisposition.indexOf("=") + 1,
            contentDisposition.length
          );
          let filename = decodeURI(filenameEncode);
          if (window.navigator.msSaveOrOpenBlob) {
            window.navigator.msSaveBlob(res.data, filename);
          } else {
            var blob = new Blob([res.data]); //创建一个blob对象
            var a = document.createElement("a"); //创建一个<a></ a>标签
            a.href = URL.createObjectURL(blob); // response is a blob
            a.download = filename; //文件名称
            a.style.display = "none";
            document.body.appendChild(a);
            a.click();
            a.remove();
          }
          this.loading = false;
        })
        .catch(() => {
          this.loading = false;
        });
    },
/*     getExportReportFun() {
      let params = {};
      params.yearmonth = this.value1;
      this.loading=true
      getExportReport(params).then((res) => {
        if (res.data.success) {
          console.log(res.data);

        } else {
          this.$message({
            type: "error",
            message: res.data.msg,
          });
        }
      });
    }, */
  },
};
</script>

<style lang="scss">
#cwzbkb {
  background-color: #f5f5f6;
  height: 100%;
  overflow: scroll;

  .box {
    height: 800px;
  }

  .el-scrollbar {
    height: 100%;
  }

  .box .el-scrollbar__wrap {
    overflow: scroll;
  }
  .right-content {
    h3 {
      text-align: center;
    }
    .el-button {
      padding: 8px 14px;
    }
    #linkUrl {
      display: inline-block;
      width: 58px;
      height: 32px;
      background-color: #409eff;
      color: #ffffff;
      border-radius: 4px;
      margin-right: 10px;
      line-height: 32px;
    }
    .footerpage {
      display: flex;
      justify-content: flex-end;
      align-items: center;
    }
  }
}
</style>