<template>
  <div id="block-table">
    <el-row>
      <el-col :span="4">
        <div class="box">
          <el-scrollbar>
            <basic-container>
              <avue-tree
                :option="treeOption"
                :data="treeData"
                @node-click="nodeClick"
              />
            </basic-container>
          </el-scrollbar>
        </div>
      </el-col>
      <el-col :span="20">
        <el-scrollbar>
          <basic-container class="right-content">
            <div class="top-information ytct-flex-jcsb pt20">
              <div class="limit-chose ytct-flex-jcfs-aic">
                <span class="limit-title"> 时间： </span>
                <el-date-picker
                  style="height: 32px"
                  v-model="value1"
                  type="monthrange"
                  range-separator="至"
                  start-placeholder="开始月份"
                  end-placeholder="结束月份"
                  value-format="yyyyMM"
                >
                </el-date-picker>

                <span class="limit-title ml20"> 开发方式： </span>
                <el-select v-model="initDevMode">
                  <el-option
                    v-for="item in developmentMode"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>

                <span class="limit-title ml20"> 合作模式：</span>
                <el-select v-model="initCoopMode">
                  <el-option
                    v-for="item in cooperateMode"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </div>
              <div class="search_reset mr20">
                <el-button type="primary" icon="el-icon-search" @click="search"
                  >查询</el-button
                >
                <el-button @click="reset" plain>重置</el-button>
              </div>
            </div>
            <div class="btns mt20">
              <el-button
                type="primary"
                icon="el-icon-document-add"
                @click="addBtn"
                >新增</el-button
              >
              <el-button
                type="primary"
                icon="el-icon-delete"
                @click="mulDelete"
                :disabled="!multipleSelectionFlag"
                >批量删除</el-button
              >
              <el-button type="primary" icon="el-icon-download"
                >批量导入</el-button
              >
              <el-button type="primary" icon="el-icon-upload2"
                >批量导出</el-button
              >
            </div>
            <el-table
              :data="tableData"
              class="mt20"
              @selection-change="handleSelectionChange"
              :header-cell-style="{
                background: '#F4F7FA',
                fontWeight: '700',
                color: '#435B76',
              }"
            >
              <el-table-column type="selection" width="55"> </el-table-column>
              <el-table-column type="index" label="序号" width="50">
              </el-table-column>
              <el-table-column align="left" label="项目名称">
                <template v-slot="scope1">
                  <router-link
                    class="c-39baf4"
                    :to="{
                      path: 'projdetail',
                      query: {
                        id: scope1.row.id,
                        districtName: districtName,
                        townName: townName,
                      },
                    }"
                  >
                    {{ scope1.row.projectName }}
                  </router-link>
                </template>
              </el-table-column>
              <el-table-column
                align="left"
                prop="projectLandArea"
                label="用地面积m²"
              >
              </el-table-column>
              <el-table-column
                align="left"
                prop="expectedPropertyDistribution"
                label="预期获得物业分配m²"
                width="180"
              >
              </el-table-column>
              <el-table-column
                align="left"
                prop="developmentModeDesc"
                label="开发方式"
              >
              </el-table-column>
              <el-table-column
                align="left"
                prop="cooperationModeDesc"
                label="合作模式"
              >
              </el-table-column>
              <el-table-column align="left" prop="publishTime" label="发布时间">
              </el-table-column>
              <el-table-column align="left" label="合作状态">
                <template v-slot="scope1">
                  <el-tag
                    :type="getColor(scope1.row.cooperationStatusDesc)"
                    effect="dark"
                    >{{ scope1.row.cooperationStatusDesc }}</el-tag
                  >
                </template>
              </el-table-column>
              <el-table-column align="left" prop="reviewState" label="审核状态">
                <template v-slot="scope2">
                  <el-tag type="success" effect="dark">{{
                    scope2.row.reviewState
                  }}</el-tag>
                </template>
              </el-table-column>
              <el-table-column align="left" label="操作">
                <template v-slot="scope3">
                  <router-link
                    class="c-39baf4"
                    :to="{
                      path: 'edit',
                      query: {
                        id: scope3.row.id,
                        districtName: districtName,
                        townName: townName,
                      },
                    }"
                  >
                    编辑
                  </router-link>
                </template>
              </el-table-column>
            </el-table>

            <div class="footerpage mt20 mr20">
              <span
                >共<span>{{ paginations.total }}</span
                >条记录
              </span>
              <el-pagination
                :total="paginations.total"
                :current-page.sync="paginations.page_index"
                :page-size="paginations.page_size"
                @current-change="handleCurrentChange"
                :layout="paginations.layout"
              ></el-pagination>
            </div> </basic-container
        ></el-scrollbar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { getPrimaryDataArea } from "@/api/devservice/common";
import {
  getCompanyCoopBasicBlockList,
  removeCompanyCoopBasic,
} from "@/api/devservice/land-dev-cooperation";
import bus from "@/util/event-bus";
export default {
  data() {
    return {
      destroyType: "",
      districtCode: this.$route.query.districtCode,
      townCode: this.$route.query.townCode,
      townName: this.$route.query.townName,
      districtName: this.$route.query.districtName,
      value1: "",
      developmentMode: [
        {
          value: "0",
          label: "城市更新",
        },
        {
          value: "1",
          label: "棚改",
        },
        {
          value: null,
          label: "全部",
        },
      ],
      initDevMode: "全部",
      cooperateMode: [
        {
          value: "0",
          label: "协议合作",
        },
        {
          value: null,
          label: "全部",
        },
      ],
      initCoopMode: "全部",
      tableData: [],
      multipleSelectionFlag: false,
      multipleSelection: [],
      paginations: {
        page_index: 1, //当前位于那页
        total: 0, //总数
        page_size: 10, //一页显示多少个
        layout: "prev,pager,next,jumper", //翻页属性
      },
      treeData: [],
      treeOption: {
        nodeKey: "id",
        lazy: true,
        treeLoad: function (node, resolve) {
          const parentCode = node.level === 0 ? "44" : node.data.code;
          getPrimaryDataArea(parentCode).then((res) => {
            resolve(
              res.data.data.map((item) => {
                return {
                  ...item,
                  leaf: !(item.childList || item.childList.length > 0),
                };
              })
            );
          });
        },
        addBtn: false,
        menu: false,
        size: "small",
        props: {
          labelText: "标题",
          label: "name",
          value: "code",
          children: "childList",
        },
      },
    };
  },
  created() {
    this.getCompanyCoopBasicBlockListFun();
  },
  beforeDestroy() {
    if (this.destroyType === "add") console.log(this.townName, "11");
    bus.$emit("blockSendInfo", {
      townName: this.townName,
      districtName: this.districtName,

      districtCode: this.districtCode,
      townCode: this.townCode,
    }); //时间总线
  },
  methods: {
    search() {
      // console.log(this.value1, "222");
      let developmentMode =
        this.initDevMode == "全部" ? null : this.initDevMode;
      // console.log(developmentMode,typeof(developmentMode),"开发方式");

      let cooperationMode =
        this.initCoopMode == "全部" ? null : this.initCoopMode;
      // console.log(cooperationMode,typeof(cooperationMode) ,"合作模式");
      if (this.value1) {
        var startdate = this.value1[0];
        var enddate = this.value1[1];
      } else {
        var startdate = null;
        var enddate = null;
      }
      this.getCompanyCoopBasicBlockListFun(
        startdate,
        enddate,
        developmentMode,
        cooperationMode
      );
    },
    reset() {
      (this.value1 = ""), (this.initDevMode = "全部");
      this.initCoopMode = "全部";
      this.getCompanyCoopBasicBlockListFun(); //重置
    },
    nodeClick(data) {
      console.log(data, "node");
    },
    addBtn() {
      this.destroyType = "add";
      this.$router.push({
        path: "add",
      });
    },
    mulDelete() {
      let checkArr = this.multipleSelection;
      let params = [];
      checkArr.forEach((item) => {
        params.push(item.id);
      });
      let param = params.toString();

      this.$confirm("确认删除吗？", "提示", {}).then(() => {
        removeCompanyCoopBasic(param).then((res) => {
          if (res.data.success) {
            this.$message({
              message: "删除成功",
              type: "success",
            });
            this.getCompanyCoopBasicBlockListFun();
          } else {
            this.$message({
              type: "error",
              message: res.data.msg,
            });
          }
        });
      });
    },
    getCompanyCoopBasicBlockListFun(
      startdate,
      enddate,
      developmentMode,
      cooperationMode
    ) {
      let params = {};
      params.code = this.townCode;
      params.cooperationType = 0; // 	合作类型【0土地1物业2产业3资金4住房】
      params.current = this.paginations.page_index;
      params.size = this.paginations.page_size;
      // -----------以下为限制搜索条件
      params.startDate = startdate;
      params.endDate = enddate;
      params.developmentMode = developmentMode;
      params.cooperationMode = cooperationMode;
      getCompanyCoopBasicBlockList(params).then((res) => {
        if (res.data.success) {
          console.log(res.data.data);
          this.tableData = res.data.data.records;
          // console.log(this.tableData)
          this.paginations.total = res.data.data.total;
        } else {
          this.$message({
            type: "error",
            message: res.data.msg,
          });
        }
      });
    },
    handleSelectionChange(val) {
      // console.log(val);
      this.multipleSelection = val;
      this.multipleSelectionFlag = true;
      if (this.multipleSelection.length == 0) {
        // 如不进行判断则勾选完毕后批量删除按钮还是会在
        this.multipleSelectionFlag = false;
      }
    },
    handleCurrentChange(val) {
      this.paginations.page_index = val;

      //调用查询接口
      this.getCompanyCoopBasicBlockListFun();
    },
    getColor(content) {
      if (content == "未开展" || content == "") {
        return "danger";
      } else if (content == "进行中") {
        return "warning";
      } else if (content == "已完成") {
        return "success";
      }
    },
  },
};
</script>

<style lang="scss">
#block-table {
  background-color: #f5f5f6;
  height: 100%;
  overflow: scroll;
  .box {
    height: 800px;
  }

  .el-scrollbar {
    height: 100%;
  }

  .box .el-scrollbar__wrap {
    overflow: scroll;
  }

  .right-content {
    .top-information {
      .limit-title {
        color: #435b76;
        font-size: 14px;
      }
    }
    .el-button {
      padding: 8px 8px;
    }
    .el-input__inner {
      height: 32px;
    }
    .footerpage {
      display: flex;
      justify-content: flex-end;
      align-items: center;
    }
  }
}
</style>
