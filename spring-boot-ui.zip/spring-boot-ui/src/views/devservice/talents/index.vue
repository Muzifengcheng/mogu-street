<template>
  <div id="talents-pool-index">
    <el-row>
      <el-col :span="6">
        <div class="box">
          <el-scrollbar>
            <basic-container>
              <avue-tree
                :option="treeOption"
                :data="treeData"
                @node-click="nodeClick"
              />
            </basic-container>
          </el-scrollbar>
        </div>
      </el-col>
      <el-col :span="18">
      <el-scrollbar>
        <basic-container class="right-content">
        <div class="top-information pt20">
          <div class="limit-chose">
            <span class="ml20">
              时间：
              <el-date-picker
                v-model="value1"
                type="month"
                placeholder="选择月"
              >
              </el-date-picker>
            </span>
          </div>
        </div>
        <el-row class="identity  mt20">
          <el-col class="stockholder" :span="12">股东人才</el-col>
          <el-col class="no-stockholder" :span="12">非股东人才</el-col>
        </el-row>
        <el-table
          :data="tableData"
          style="width: 100%; margin: 0 auto"
          :header-cell-style="{
            background: '#F4F7FA',
            fontWeight: '700',
            color: '#435B76',
          }"
        >
          <el-table-column type="index" label="序号" align="center" width="50">
          </el-table-column>
          <el-table-column align="left" label="行政区">
            <template v-slot="scope">
              <router-link class="c-39baf4" :to="{ path: 'talentsdistrict' }">{{
                scope.row.districtName
              }}</router-link>
            </template>
          </el-table-column>
          <el-table-column align="left" prop="postdoctorAmount" label="博士后">
          </el-table-column>
          <el-table-column
            align="left"
            prop="doctorAmount"
            label="博士"
          >
          </el-table-column>
          <el-table-column align="left" prop="masterAmount" label="硕士">
          </el-table-column>
          <el-table-column align="left" prop="postdoctorAmount" label="博士后">
          </el-table-column>
          <el-table-column align="left" prop="doctorAmount" label="博士">
          </el-table-column>
          <el-table-column align="left" prop="masterAmount" label="硕士">
          </el-table-column>
          <el-table-column label="状态">
            <template v-slot="scope">
              <el-tag :type="scope.row.type" effect="dark">{{
                scope.row.state
              }}</el-tag>
            </template>
          </el-table-column>
        </el-table>
        <div class="footerpage mt20 mr20">
          <span
            >共<span>{{ paginations.total }}</span
            >条记录
          </span>
          <el-pagination
            :total="paginations.total"
            :current-page.sync="paginations.page_index"
            :page-size="paginations.page_size"
            @current-change="handleCurrentChange"
            :layout="paginations.layout"
          ></el-pagination>
        </div>
      
      </basic-container>
            </el-scrollbar>

      </el-col>
    </el-row>
  </div>
</template>

<script>
// import {getLazyTree} from "@/api/base/region";

import { getPrimaryDataArea} from "@/api/devservice/common";
import {  getTalentPool } from "@/api/devservice/talents";
export default {
  data() {
    return {
      value1: "",
      tableData: [
        {
          projName: "福田区",
          useLandArea: "北京大道",
          expectedPropertyAllocation: "斗鱼",
          devMethods: "2",
          cooperateMode: "南京大学",
          publishTime: "本科",
          cooperateState: "是",
          reviewState: "2020-8-25",
          state: "已审核",
          type: "success",
        },

      ],
      paginations: {
        page_index: 1, //当前位于那页
        total: 0, //总数
        page_size: 2, //一页显示多少个
        layout: "prev,pager,next,jumper", //翻页属性
      },
      treeData: [],
      treeOption: {
        nodeKey: "id",
        lazy: true,
        treeLoad: function (node, resolve) {
          // console.log(node, "gg");
          const parentCode = node.level === 0 ? "44" : node.data.code;
          getPrimaryDataArea(parentCode).then((res) => {
            resolve(
              res.data.data.map((item) => {
                return {
                  ...item,
                  leaf: !(item.childList || item.childList.length > 0),
                };
              })
            );
          });
        },
        addBtn: false,
        menu: false,
        size: "small",
        props: {
          labelText: "标题",
          label: "name",
          value: "code",
          children: "childList",
        },
      },
    };
  },
  created() {
    this.getTalentPoolFun();
  },
  methods: {
    getTalentPoolFun() {
      let params = {};
      params.code='4403'
      params.current = this.paginations.page_index;
      params.size = this.paginations.page_size;
      getTalentPool(params).then((res) => {
        if (res.data.success) {
          this.tableData = res.data.data.records;
          this.paginations.total = res.data.data.total;
        } else {
          this.$message({
            type: "error",
            message: res.data.msg,
          });
        }
      });
    },

    handleCurrentChange(val) {
      this.paginations.page_index = val;
      //调用查询接口
      this.getTalentPoolFun()
    },
  },
};
</script>

<style lang="scss">
#talents-pool-index {
  height: 100%;
  // overflow: auto;
  background-color: #f5f5f6;
  .box {
    height: 800px;
  }

  .el-scrollbar {
    height: 100%;
  }

  .box .el-scrollbar__wrap {
    overflow: scroll;
  }
  .right-content{
    // height: 100%;
    // overflow: auto;
      .identity {
    .stockholder,
    .no-stockholder {
      text-align: center;
      background-color: #def1f9;
      height: 29px;
      line-height: 29px;
      margin-bottom: 0px;
    }
  }
  .footerpage {
    display: flex;
    justify-content: flex-end;
    align-items: center;
  }
  }

}
</style>