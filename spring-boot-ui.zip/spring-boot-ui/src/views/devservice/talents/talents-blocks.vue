<template>
  <div id="talents-blocks">
    <el-row>
      <el-col :span="6">
        <div class="box">
          <el-scrollbar>
            <basic-container>
              <avue-tree
                :option="treeOption"
                :data="treeData"
                @node-click="nodeClick"
              />
            </basic-container>
          </el-scrollbar>
        </div>
      </el-col>
      <el-col :span="18">
        <el-scrollbar>
          <basic-container class="right-content">
            <div class="top-information pt20">
              <div class="limit-chose">
                <span class="ml20">
                  时间：
                  <el-date-picker
                    v-model="value1"
                    type="month"
                    placeholder="选择月"
                  >
                  </el-date-picker>
                </span>
              </div>
            </div>
            <el-table
              :data="tableData"
              class="mt20"
              style="width: 98%; margin: 0 auto"
              :header-cell-style="{
                background: '#F4F7FA',
                fontWeight: '700',
                color: '#435B76',
              }"
            >
              <el-table-column
                type="index"
                label="序号"
                align="center"
                width="50"
              >
              </el-table-column>
              <el-table-column align="left" prop="projName" label="姓名">
              </el-table-column>
              <el-table-column align="left" label="所属街道">
                <template v-slot="scope">
                  <router-link class="c-39baf4" :to="{ path: 'detail/2' }">{{
                    scope.row.useLandArea
                  }}</router-link>
                </template>
              </el-table-column>
              <el-table-column
                align="left"
                prop="expectedPropertyAllocation"
                label="所属企业"
              >
              </el-table-column>
              <el-table-column align="left" prop="devMethods" label="工作年限">
              </el-table-column>
              <el-table-column
                align="left"
                prop="cooperateMode"
                label="毕业院校"
              >
              </el-table-column>
              <el-table-column align="left" prop="publishTime" label="最高学历">
              </el-table-column>
              <el-table-column
                align="left"
                prop="cooperateState"
                label="是否全日制"
              >
              </el-table-column>
              <el-table-column align="left" prop="reviewState" label="入职时间">
              </el-table-column>
              <el-table-column label="状态">
                <template v-slot="scope">
                  <el-tag :type="scope.row.type" effect="dark">{{
                    scope.row.state
                  }}</el-tag>
                </template>
              </el-table-column>
            </el-table>
            <div class="footerpage mt20 mr20">
              <span
                >共<span>{{ paginations.total }}</span
                >条记录
              </span>
              <el-pagination
                :total="paginations.total"
                :current-page.sync="paginations.page_index"
                :page-size="paginations.page_size"
                @current-change="handleCurrentChange"
                :layout="paginations.layout"
              ></el-pagination>
            </div>
          </basic-container>
        </el-scrollbar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { getLazyTree } from "@/api/base/region";

export default {
  data() {
    return {
      value1: "",
      tableData: [
        {
          projName: "卢本伟",
          useLandArea: "北京大道",
          expectedPropertyAllocation: "斗鱼",
          devMethods: "2",
          cooperateMode: "南京大学",
          publishTime: "本科",
          cooperateState: "是",
          reviewState: "2020-8-25",
          state: "已审核",
          type: "success",
        },
        {
          projName: "司马光",
          useLandArea: "福田路",
          expectedPropertyAllocation: "北京出版社",
          devMethods: "5",
          cooperateMode: "北京大学",
          publishTime: "博士",
          cooperateState: "是",
          reviewState: "2018-07-01",
          state: "未审核",
          type: "danger",
        },
      ],

      paginations: {
        page_index: 1, //当前位于那页
        total: 0, //总数
        page_size: 2, //一页显示多少个
        layout: "prev,pager,next,jumper", //翻页属性
      },
      treeData: [],
      treeOption: {
        nodeKey: "id",
        lazy: true,
        treeLoad: function (node, resolve) {
          const parentCode = node.level === 0 ? "00" : node.data.id;
          getLazyTree(parentCode).then((res) => {
            resolve(
              res.data.data.map((item) => {
                return {
                  ...item,
                  leaf: !item.hasChildren,
                };
              })
            );
          });
        },
        addBtn: false,
        menu: false,
        size: "small",
        props: {
          labelText: "标题",
          label: "title",
          value: "value",
          children: "children",
        },
      },
    };
  },
  created() {},
  methods: {},
};
</script>

<style lang="scss">
#talents-blocks {
  height: 100%;
  overflow: scroll;
  background-color: #f5f5f6;
  .box {
    height: 800px;
  }

  .el-scrollbar {
    height: 100%;
  }

  .box .el-scrollbar__wrap {
    overflow: scroll;
  }
  .right-content {
    .footerpage {
      display: flex;
      justify-content: flex-end;
      align-items: center;
    }
  }
}
</style>