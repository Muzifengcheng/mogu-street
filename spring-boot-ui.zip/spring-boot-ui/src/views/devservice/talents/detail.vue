<template>
  <div id="talents-detail">
        <h3>人才详情</h3>
    <el-card class="base  pb20">
      <div class="border-left-4-2667C1 title1">
        <label class="ml20 ft18 lh40 fw700">基本情况</label>
      </div>
      <el-form :model="baseForm" ref="baseForm" class="ml40 mr40" label-position="left">
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="姓名:">
             卢本伟
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="性别:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="年龄:"> </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="毕业院校:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="最高学历:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="民族:"> </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="毕业时长:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="是否全日制:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="是否股东:"> </el-form-item>
          </el-col>
        </el-row>
         <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="政治面貌:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="所属企业:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="企业性质:"> </el-form-item>
          </el-col>
        </el-row>
         <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="工作年限:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="入职时间:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="所属企业职务:"> </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </el-card>
    <el-card class="collective mt20">
      <div class="ytct-flex-jcsb title2">
        <div class="border-left-4-2667C1">
          <label class="ml20 ft18 lh40 fw700">挂职情况</label>
        </div>
        <div>
          <el-button type="primary" icon="el-icon-upload2"> 上传 </el-button>
          <el-button type="primary" class="mr40" plain icon="el-icon-document"
            >下载模板</el-button
          >
        </div>
      </div>
      <!-- 表格 -->
      <el-table :data="tableData" class="mt20" style="width: 96%; margin:0 auto;" border>
        <el-table-column prop="companyName" label="挂职企业"> </el-table-column>
        <el-table-column prop="noAgricultureTarget" label="挂职岗位">
        </el-table-column>
        <el-table-column prop="benefitShareLand" label="挂职时长">
        </el-table-column>
      </el-table>
    </el-card>
    <!-- 其它 -->
    <el-card class="cooporation mt20 ">
      <div class="border-left-4-2667C1 title3">
        <label class="ml20 ft18 lh40 fw700">其它</label>
      </div>
      <el-form :model="cooperateForm" ref="cooperateForm" class="ml40 mr40" label-position="left">

        <el-col :span="24">
          <el-form-item label="备注：">
            </el-form-item>
        </el-col>
        <!-- 附件 -->
        <el-col :span="6">
          <el-form-item label="附件：">
            <el-upload
              class="upload-demo"
              action="https://jsonplaceholder.typicode.com/posts/"
              :on-preview="handlePreview"
              :on-remove="handleRemove"
              :before-remove="beforeRemove"
              multiple
              :limit="3"
              :on-exceed="handleExceed"
              :file-list="cooperateForm.fileList"
              :show-file-list="true"
            >
              <el-button size="small" type="primary" icon="el-icon-upload2"
                >点击上传</el-button
              >
            </el-upload>
          </el-form-item>
        </el-col>
      </el-form>
    </el-card>
  </div>
</template>

<script>
export default {
  data() {
    return {
      baseForm: {
        projname: "",
        projstatus: [
          {
            id: 1,
            value: "选项1",
            label: "黄金糕",
          },
          {
            id: 2,
            value: "选项2",
            label: "双皮奶",
          },
          {
            value: "选项3",
            label: "蚵仔煎",
          },
          {
            value: "选项4",
            label: "龙须面",
          },
          {
            value: "选项5",
            label: "北京烤鸭",
          },
        ],
        localtion: "",
        developmethods: [
          {
            id: 1,
            value: "选项1",
            label: "黄金糕",
          },
          {
            id: 2,
            value: "选项2",
            label: "双皮奶",
          },
          {
            value: "选项3",
            label: "蚵仔煎",
          },
          {
            value: "选项4",
            label: "龙须面",
          },
          {
            value: "选项5",
            label: "北京烤鸭",
          },
        ],
        district: [
          {
            id: 1,
            value: "选项1",
            label: "黄金糕",
          },
          {
            id: 2,
            value: "选项2",
            label: "双皮奶",
          },
          {
            value: "选项3",
            label: "蚵仔煎",
          },
          {
            value: "选项4",
            label: "龙须面",
          },
          {
            value: "选项5",
            label: "北京烤鸭",
          },
        ],
        block: [
          {
            id: 1,
            value: "选项1",
            label: "黄金糕",
          },
          {
            id: 2,
            value: "选项2",
            label: "双皮奶",
          },
          {
            value: "选项3",
            label: "蚵仔煎",
          },
          {
            value: "选项4",
            label: "龙须面",
          },
          {
            value: "选项5",
            label: "北京烤鸭",
          },
        ],
        devdirection: [
          {
            id: 1,
            value: "选项1",
            label: "黄金糕",
          },
          {
            id: 2,
            value: "选项2",
            label: "双皮奶",
          },
          {
            value: "选项3",
            label: "蚵仔煎",
          },
          {
            value: "选项4",
            label: "龙须面",
          },
          {
            value: "选项5",
            label: "北京烤鸭",
          },
        ],
        projUseLandArea: "",
        buildingArea: "",
      },
      initValue: "黄金糕",
      tableData: [
        {
          companyName: "深圳市深圳市公共建设有限公司",
          noAgricultureTarget: "java开发",
          benefitShareLand: "1000",
        },
      ],

      cooperateForm: {
        fileList: [
          {
            name: "food.jpeg",
            url:
              "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
          },
          {
            name: "food2.jpeg",
            url:
              "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
          },
        ],
      },
    };
  },
  created() {},
  methods: {},
}
</script>

<style lang="scss">
#talents-detail{
  background-color: #f5f5f6;
  overflow-y: scroll;
  height: 100%;
  .el-card__body{
    padding:16px 0px !important;
  }
}

</style>