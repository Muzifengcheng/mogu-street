<template>
  <div id="fund-cooperation-blocks">
    <el-row>
      <el-col :span="6">
        <div class="box">
          <el-scrollbar>
            <basic-container>
              <avue-tree
                :option="treeOption"
                :data="treeData"
                @node-click="nodeClick"
              />
            </basic-container>
          </el-scrollbar>
        </div>
      </el-col>
      <el-col :span="18">
        <el-scrollbar>
          <basic-container class="right-content">
            <div class="top-information ytct-flex-jcsb pt20">
              <div class="limit-chose ytct-flex-jcfs-aic">
                <span class="ml20">
                  <span class="limit-title"> 时间： </span>
                  <el-date-picker
                    style="height: 32px"
                    v-model="value1"
                    type="monthrange"
                    range-separator="至"
                    start-placeholder="开始月份"
                    end-placeholder="结束月份"
                  >
                  </el-date-picker>
                </span>
              </div>
              <div class="search_reset mr20">
                <el-button type="primary" icon="el-icon-search">查询</el-button>
                <el-button plain>重置</el-button>
              </div>
            </div>
            <div class="btns mt20">
              <div class="ml20">
                <el-button
                  type="primary"
                  icon="el-icon-document-add"
                  @click="addBtn"
                  >新增</el-button
                >
                <el-button
                  type="primary"
                  icon="el-icon-delete"
                  @click="mulDelete"
                  :disabled="!multipleSelectionFlag"
                  >批量删除</el-button
                >
                <el-button type="primary" icon="el-icon-download"
                  >批量导入</el-button
                >
                <el-button type="primary" icon="el-icon-upload2"
                  >批量导出</el-button
                >
              </div>
            </div>

            <el-table
              :data="tableData"
              class="mt20"
              style="width: 98%; margin: 0 auto"
              @selection-change="handleSelectionChange"
              :header-cell-style="{
                background: '#F4F7FA',
                fontWeight: '700',
                color: '#435B76',
              }"
            >
              <el-table-column type="selection" width="55"> </el-table-column>
              <el-table-column type="index" label="序号" width="50">
              </el-table-column>
              <el-table-column align="center" label="项目名称">
                <template v-slot="scope">
                  <router-link
                    class="c-39baf4"
                    :to="{
                      path:'projdetail',
                      query: {
                        id: scope.row.id,
                        districtName: districtName,
                        townName: townName,
                      },
                    }"
                    >{{ scope.row.projectName }}</router-link
                  >
                </template>
              </el-table-column>
              <el-table-column
                align="center"
                prop="investFund"
                label="资金投入"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="revenueTotal"
                label="总收益"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="averageAnnualInterestRate"
                label="平均年利率"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="bonusMoney"
                label="补贴金额"
              >
              </el-table-column>
              <el-table-column align="center" label="合作状态">
                <template v-slot="scope1">
                  <el-tag
                    :type="getColor(scope1.row.cooperationStatusDesc)"
                    effect="dark"
                    >{{ scope1.row.cooperationStatusDesc }}</el-tag
                  >
                </template>
              </el-table-column>
              <el-table-column align="center" label="审核状态">
                <template v-slot="scope2">
                  <el-tag type="success" effect="dark">{{
                    scope2.row.reviewState
                  }}</el-tag>
                </template>
              </el-table-column>
              <el-table-column align="center" label="操作">
                <template v-slot="scope3">
                  <router-link
                    class="c-39baf4"
                    :to="{
                      path: 'addoredit',
                      query: {
                        pageTitle: '编辑',
                        id: scope3.row.id,
                        districtName: districtName,
                        townName: townName,
                      },
                    }"
                  >
                    编辑
                  </router-link>
                </template>
              </el-table-column>
            </el-table>
            <div class="footerpage mt20 mr20">
              <span
                >共<span>{{ paginations.total }}</span
                >条记录
              </span>
              <el-pagination
                :total="paginations.total"
                :current-page.sync="paginations.page_index"
                :page-size="paginations.page_size"
                @current-change="handleCurrentChange"
                :layout="paginations.layout"
              ></el-pagination>
            </div> </basic-container
        ></el-scrollbar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { getPrimaryDataArea } from "@/api/devservice/common";
import {
  getCompanyCoopBasicBlockList,
  removeCompanyCoopBasic,
} from "@/api/devservice/fund-cooperation";
export default {
  data() {
    return {
      destroyType: "",
      districtCode: this.$route.query.districtCode,
      townCode: this.$route.query.townCode,
      townName: this.$route.query.townName,
      districtName: this.$route.query.districtName,
      value1: "",

      multipleSelectionFlag: false,
      multipleSelection: [],
      tableData: [],
      paginations: {
        page_index: 1, //当前位于那页
        total: 0, //总数
        page_size: 10, //一页显示多少个
        layout: "prev,pager,next,jumper", //翻页属性
      },
      treeData: [],
      treeOption: {
        nodeKey: "id",
        lazy: true,
        treeLoad: function (node, resolve) {
          const parentCode = node.level === 0 ? "44" : node.data.code;
          getPrimaryDataArea(parentCode).then((res) => {
            resolve(
              res.data.data.map((item) => {
                return {
                  ...item,
                  leaf: !(item.childList || item.childList.length > 0),
                };
              })
            );
          });
        },
        addBtn: false,
        menu: false,
        size: "small",
        props: {
          labelText: "标题",
          label: "name",
          value: "code",
          children: "childList",
        },
      },
    };
  },
  created() {
    this.getCompanyCoopBasicBlockListFun();
  },
  methods: {
    nodeClick(data) {
      console.log(data, "node");
    },
    addBtn() {
      this.$router.push({
        path: "addoredit",
        query: {
          pageTitle: "新增",
          townName: this.townName,
          districtName: this.districtName,

          districtCode: this.districtCode,
          townCode: this.townCode,
        },
      });
    },
    mulDelete() {
      let checkArr = this.multipleSelection;
      let params = [];
      checkArr.forEach((item) => {
        params.push(item.id);
      });
      let param = params.toString();

      this.$confirm("确认删除吗？", "提示", {}).then(() => {
        removeCompanyCoopBasic(param).then((res) => {
          if (res.data.success) {
            this.$message({
              message: "删除成功",
              type: "success",
            });
            this.getCompanyCoopBasicBlockListFun();
          } else {
            this.$message({
              type: "error",
              message: res.data.msg,
            });
          }
        });
      });
    },
    getCompanyCoopBasicBlockListFun() {
      let params = {};
      params.code = this.townCode;
      params.cooperationType = 3; // 	合作类型【0土地1物业2产业3资金4住房】
      params.current = this.paginations.page_index;
      params.size = this.paginations.page_size;
      getCompanyCoopBasicBlockList(params).then((res) => {
        if (res.data.success) {
          this.tableData = res.data.data.records;
          this.paginations.total = res.data.data.total;
        } else {
          this.$message({
            type: "error",
            message: res.data.msg,
          });
        }
      });
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
      this.multipleSelectionFlag = true;
      if (this.multipleSelection.length == 0) {
        // 如不进行判断则勾选完毕后批量删除按钮还是会在
        this.multipleSelectionFlag = false;
      }
    },
    handleCurrentChange(val) {
      this.paginations.page_index = val;
      //调用查询接口
      this.getCompanyCoopBasicBlockListFun();
    },
    getColor(content) {
      if (content == "未开展" || content == "") {
        return "danger";
      } else if (content == "进行中") {
        return "warning";
      } else if (content == "已完成") {
        return "success";
      }
    },
  },
};
</script>

<style lang="scss">
#fund-cooperation-blocks {
  background-color: #f5f5f6;
  height: 100%;
  overflow: scroll;

  .box {
    height: 800px;
  }

  .el-scrollbar {
    height: 100%;
  }

  .box .el-scrollbar__wrap {
    overflow: scroll;
  }
  .right-content {
    .top-information {
      .limit-title {
        color: #435b76;
        font-size: 14px;
      }
    }
    .el-button {
      padding: 8px 8px;
    }
    .footerpage {
      display: flex;
      justify-content: flex-end;
      align-items: center;
    }
  }
}
</style>