<template>
  <div id="take-temporary-post-application-provide">
    <div class="limit-chose mt20">
      <span class="ml20">
        时间：
        <el-date-picker v-model="value1" type="month" placeholder="选择月">
        </el-date-picker>
      </span>
      <span class="ml20">
        岗位：
        <el-select v-model="initValue1">
          <el-option
            v-for="item in position"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
      </span>
      <span class="ml20">
        行业：
        <el-select v-model="initValue2">
          <el-option
            v-for="item in business"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
      </span>
      <span class="ml20">
        企业：
        <el-select v-model="initValue3">
          <el-option
            v-for="item in enterprise"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
      </span>
    </div>

    <el-table
      :data="tableData"
      class="mt20"
      style="width: 98%; margin: 0 auto"
      :header-cell-style="{
        background: '#F4F7FA',
        fontWeight: '700',
        color: 'black',
      }"
    >
      <el-table-column type="index" label="序号" width="50"> </el-table-column>
      <el-table-column align="center" label="职位">
        <template v-slot="scope">
          <router-link
            class="c-39baf4"
            :to="{ name: 'taketemporarypostapplicationprovidedetail' }"
           
            >{{ scope.row.projName }}</router-link
          >
        </template>
      </el-table-column>
      <el-table-column align="center" prop="useLandArea" label="行业类别">
      </el-table-column>
      <el-table-column
        align="center"
        prop="expectedPropertyAllocation"
        label="职位类别"
      >
      </el-table-column>
      <el-table-column align="center" prop="devMethods" label="所属企业">
      </el-table-column>
      <el-table-column align="center" prop="cooperateMode" label="挂职时长">
      </el-table-column>
      <el-table-column align="center" prop="cooperateMode" label="联系人">
      </el-table-column>
      <el-table-column align="center" prop="reviewState" label="联系电话">
      </el-table-column>
      <el-table-column align="center" prop="reviewState" label="发布时间">
      </el-table-column>
      <el-table-column align="center" label="状态">
        <template v-slot="scope2">
          <el-tag type="success" effect="dark">{{
            scope2.row.reviewState
          }}</el-tag>
        </template>
      </el-table-column>
    </el-table>
    <div class="footerpage mt20 mr20">
      <span
        >共<span>{{ paginations.total }}</span
        >条记录
      </span>
      <el-pagination
        :total="paginations.total"
        :current-page.sync="paginations.page_index"
        :page-size="paginations.page_size"
        @current-change="handleCurrentChange"
        :layout="paginations.layout"
      ></el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      value1: "",
      position: [
        {
          value: "选项1",
          label: "web开发",
        },
        {
          value: "选项2",
          label: "小程序开发",
        },
        {
          value: "选项3",
          label: "法律顾问",
        },
      ],
      business: [
        {
          value: "选项1",
          label: "计算机互联网",
        },
        {
          value: "选项2",
          label: "工商行业",
        },
      ],
      enterprise: [
        {
          value: "选项1",
          label: "腾讯科技",
        },
        {
          value: "选项2",
          label: "法律法务",
        },
      ],
      initValue1: "web开发",
      initValue2: "计算机互联网",
      initValue3: "腾讯科技",

      tableData: [
        {
          projName: "web开发",
          useLandArea: "10000",
          expectedPropertyAllocation: "10000",
          devMethods: "城市更新",
          cooperateMode: "协议合作",
          publishTime: "2020-08-24",
          cooperateState: "已完成",
          reviewState: "待审核",
        },
        {
          projName: "小程序开发",
          useLandArea: "10000",
          expectedPropertyAllocation: "10000",
          devMethods: "城市更新",
          cooperateMode: "协议合作",
          publishTime: "2020-08-24",
          cooperateState: "已完成",
          reviewState: "待审核",
        },
      ],
      paginations: {
        page_index: 1, //当前位于那页
        total: 5, //总数
        page_size: 10, //一页显示多少个
        layout: "prev,pager,next,jumper", //翻页属性
      },
    };
  },
  created() {},
  methods: {},
};
</script>

<style lang="scss">
#take-temporary-post-application-provide {
  background-color: #f5f5f6;
  height: 100%;
  overflow: scroll;
  .footerpage {
    display: flex;
    justify-content: flex-end;
    align-items: center;
  }
}
</style>