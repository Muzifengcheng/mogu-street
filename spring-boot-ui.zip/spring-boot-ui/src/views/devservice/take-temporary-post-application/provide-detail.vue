<template>
  <div id="take-temporary-post-application-provide-detail">
    <h3>岗位详情</h3>
    <el-card class="base pb20">
      <div class="border-left-4-2667C1 title1">
        <label class="ml20 ft18 lh40 fw700">基本信息</label>
      </div>
      <el-form
        :model="baseForm"
        ref="baseForm"
        class="ml40 mr40"
        label-position="left"
      >
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="岗位名称:">
              web开发
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="行业类别:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="职位类别:"> </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="公司名称:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="所属直管企业:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="公司层级:"> </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="负责人:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="联系人:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="联系方式:"> </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="挂职时长:"> </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </el-card>
    <el-card class="collective mt20">
      <div class="border-left-4-2667C1">
        <label class="ml20 ft18 lh40 fw700">挂职情况</label>
      </div>
      <!-- 表格 -->
      <el-table
        :data="tableData"
        class="mt20"
        style="width: 96%; margin: 0 auto"
        border
      >
        <el-table-column prop="companyName" label="姓名"> </el-table-column>
        <el-table-column prop="noAgricultureTarget" label="人才编码">
        </el-table-column>
        <el-table-column prop="noAgricultureTarget" label="所属企业">
        </el-table-column>
        <el-table-column prop="noAgricultureTarget" label="企业所在行政区">
        </el-table-column>
        <el-table-column prop="noAgricultureTarget" label="企业所在街道">
        </el-table-column>
        <el-table-column prop="noAgricultureTarget" label="挂职时间（开始结束）">
        </el-table-column>
      </el-table>
      <div class="border-left-4-2667C1 mt10">
        <label class="ml20 ft18 lh40 fw700">申请情况</label>
      </div>
      <!-- 表格 -->
      <el-table
        :data="tableData"
        class="mt20"
        style="width: 96%; margin: 0 auto"
        border
      >
        <el-table-column prop="companyName" label="姓名"> </el-table-column>
        <el-table-column prop="noAgricultureTarget" label="人才编码">
        </el-table-column>
        <el-table-column prop="noAgricultureTarget" label="所属企业">
        </el-table-column>
        <el-table-column prop="noAgricultureTarget" label="企业所在行政区">
        </el-table-column>
        <el-table-column prop="noAgricultureTarget" label="企业所在街道">
        </el-table-column>
        <el-table-column prop="noAgricultureTarget" label="挂职时间（开始结束）">
        </el-table-column>
      </el-table>

    </el-card>
    <!-- 合作情况 -->
    <el-card class="cooporation mt20">
      <div class="border-left-4-2667C1 title3">
        <label class="ml20 ft18 lh40 fw700">备注</label>
      </div>
      <el-form
        :model="cooperateForm"
        ref="cooperateForm"
        class="ml40 mr40"
        label-position="left"
      >
        <el-col>
          <el-form-item label="备注："> </el-form-item>
        </el-col>
        <!-- 附件 -->
        <el-col :span="6">
          <el-form-item label="附件：">
            <el-upload
              class="upload-demo"
              action="https://jsonplaceholder.typicode.com/posts/"
              :on-preview="handlePreview"
              :on-remove="handleRemove"
              :before-remove="beforeRemove"
              multiple
              :limit="3"
              :on-exceed="handleExceed"
              :file-list="cooperateForm.fileList"
              :show-file-list="true"
            >
              <el-button size="small" type="primary" icon="el-icon-upload2"
                >点击上传</el-button
              >
              <span slot="tip" class="el-upload__tip ml20"
                >只能上传jpg/png/ppt/doc/pdf/xls文件，且不超过30M</span
              >
            </el-upload>
          </el-form-item>
        </el-col>
      </el-form>
    </el-card>
  </div>
</template>

<script>
export default {
  data() {
    return {
      baseForm: {},
      tableData: [
        {
          companyName: "深圳市深圳市公共建设有限公司",
          noAgricultureTarget: "1000万",
        },
      ],
      cooperateForm: {
        fileList: [
          {
            name: "food.jpeg",
            url:
              "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
          },
          {
            name: "food2.jpeg",
            url:
              "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
          },
        ],
      },
    };
  },
  created() {},
  methods: {},
};
</script>

<style lang="scss">
#take-temporary-post-application-provide-detail {
  background-color: #f5f5f6;
  overflow-y: scroll;
  height: 100%;
  .el-card__body {
    padding: 16px 0px !important;
  }
}
</style>