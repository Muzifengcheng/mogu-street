<template>
  <div id="take-temporary-post-application-index">
    <el-row>
      <el-col :span="9">
        <div class="box">
          <el-scrollbar>
            <basic-container>
              <avue-tree
                :option="treeOption"
                :data="treeData"
                @node-click="nodeClick"
              />
            </basic-container>
          </el-scrollbar>
        </div>
      </el-col>
      <el-col :span="15">
        <div class="limit-chose mt20">
          <span class="ml20">
            时间：
            <el-date-picker v-model="value1" type="month" placeholder="选择月">
            </el-date-picker>
          </span>
          <span class="ml20">
            企业：
            <el-select v-model="initValue1">
              <el-option
                v-for="item in projstatus"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </span>
          <span class="ml20">
            学历：
            <el-select v-model="initValue2">
              <el-option
                v-for="item in educationLevel"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </span>
        </div>

        <el-table
          :data="tableData"
          class="mt20"
          style="width: 98%; margin: 0 auto"
          :header-cell-style="{
            background: '#F4F7FA',
            fontWeight: '700',
            color: 'black',
          }"
        >
          <el-table-column type="index" label="序号" width="50">
          </el-table-column>
          <el-table-column align="center" label="姓名">
            <template v-slot="scope">
              <router-link
                class="c-39baf4"
                :to="{ path: 'detail/2' }"
                >{{ scope.row.projName }}</router-link
              >
            </template>
          </el-table-column>
          <el-table-column align="center" prop="useLandArea" label="所属企业">
          </el-table-column>
          <el-table-column
            align="center"
            prop="expectedPropertyAllocation"
            label="申请职位"
          >
          </el-table-column>
          <el-table-column align="center" prop="devMethods" label="工作年限">
          </el-table-column>
          <el-table-column align="center" prop="cooperateMode" label="毕业院校">
          </el-table-column>
          <el-table-column align="center" prop="cooperateMode" label="最高学历">
          </el-table-column>
          <el-table-column align="center" prop="reviewState" label="是否全日制">
          </el-table-column>
          <el-table-column align="center" prop="reviewState" label="入职时间">
          </el-table-column>

          <el-table-column align="center" label="审核状态">
            <template v-slot="scope2">
              <el-tag type="success" effect="dark">{{
                scope2.row.reviewState
              }}</el-tag>
            </template>
          </el-table-column>
        </el-table>
        <div class="footerpage mt20 mr20">
          <span
            >共<span>{{ paginations.total }}</span
            >条记录
          </span>
          <el-pagination
            :total="paginations.total"
            :current-page.sync="paginations.page_index"
            :page-size="paginations.page_size"
            @current-change="handleCurrentChange"
            :layout="paginations.layout"
          ></el-pagination>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data() {
    return {
      value1: "",
      projstatus: [
        {
          value: "选项1",
          label: "深圳迎宾馆有限公司",
        },
        {
          value: "选项2",
          label: "深圳市交易集团有限公司",
        },
        {
          value: "选项3",
          label: "百度科技有限公司",
        },
      ],
      educationLevel: [
        {
          value: "选项1",
          label: "本科",
        },
        {
          value: "选项2",
          label: "硕士",
        },
      ],
      initValue1: "深圳迎宾馆有限公司",
      initValue2: "本科",

      tableData: [
        {
          projName: "卢本伟",
          useLandArea: "10000",
          expectedPropertyAllocation: "10000",
          devMethods: "城市更新",
          cooperateMode: "协议合作",
          publishTime: "2020-08-24",
          cooperateState: "已完成",
          reviewState: "待审核",
        },
        {
          projName: "大司马",
          useLandArea: "10000",
          expectedPropertyAllocation: "10000",
          devMethods: "城市更新",
          cooperateMode: "协议合作",
          publishTime: "2020-08-24",
          cooperateState: "已完成",
          reviewState: "待审核",
        },
      ],
      paginations: {
        page_index: 1, //当前位于那页
        total: 5, //总数
        page_size: 10, //一页显示多少个
        layout: "prev,pager,next,jumper", //翻页属性
      },
      treeData: [],
      treeOption: {
        nodeKey: "id",
        lazy: true,
        treeLoad: function (node, resolve) {
          const parentId = node.level === 0 ? 0 : node.data.id;
          getDeptLazyTree(parentId).then((res) => {
            resolve(
              res.data.data.map((item) => {
                return {
                  ...item,
                  leaf: !item.hasChildren,
                };
              })
            );
          });
        },
        addBtn: false,
        menu: false,
        size: "small",
        props: {
          labelText: "标题",
          label: "title",
          value: "value",
          children: "children",
        },
      },
    };
  },
  created() {},
  methods: {},
};
</script>

<style lang="scss">
#take-temporary-post-application-index {
  background-color: #f5f5f6;
  height: 100%;
  overflow: scroll;
  .box {
    height: 800px;
  }

  .el-scrollbar {
    height: 100%;
  }

  .box .el-scrollbar__wrap {
    overflow: scroll;
  }
  .footerpage {
    display: flex;
    justify-content: flex-end;
    align-items: center;
  }
}
</style>
