<template>
  <div id="housing-security-cooperation-projdetail">
    <div class="ytct-flex-jcsb-aic">
      <span class="ft24 fw700 c-435b76">{{ pageTitle }}</span>
      <span>
        <el-button
          class="ml10"
          type="success"
          :loading="isSubmitFlag"
          @click="submitForm"
          >提交</el-button
        >
      </span>
    </div>
    <el-card class="edit-content pb20">
      <div class="border-left-4-2667C1 title1">
        <label class="ml20 ft18 lh40 fw700">基本情况</label>
      </div>
      <el-form
        :model="baseForm"
        ref="baseForm"
        class="ml40 mr40"
        label-position="top"
      >
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="项目名称:" prop="projectName">
              <el-input
                v-model="baseForm.projectName"
                maxlength="120"
                placeholder="请输入项目名称"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="项目状态:">
              <el-select v-model="initState">
                <el-option
                  v-for="item in baseForm.projectStatus"
                  :key="item.dictKey"
                  :label="item.dictValue"
                  :value="item.dictKey"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="开发方式:">
              <el-select v-model="initDevMode">
                <el-option
                  v-for="item in baseForm.developmentMode"
                  :key="item.dictKey"
                  :label="item.dictValue"
                  :value="item.dictKey"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="坐落位置:" prop="locatedPosition">
              <el-input
                v-model="baseForm.locatedPosition"
                placeholder="请输入坐落位置"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="行政区:">
              <el-input v-model="districtName" disabled></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="所属街道:">
              <el-input v-model="townName" disabled> </el-input
            ></el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="开发方向:">
              <el-select v-model="initDevDirection">
                <el-option
                  v-for="item in baseForm.developmentDirection"
                  :key="item.dictKey"
                  :label="item.dictValue"
                  :value="item.dictKey"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="项目用地面积(m²):" prop="projectLandArea">
              <el-input v-model.number="baseForm.projectLandArea"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="现状建筑面积(m²):" prop="currentBuildingArea">
              <el-input
                v-model.number="baseForm.currentBuildingArea"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="合法用地面积(m²):" prop="legalLandArea">
              <el-input v-model.number="baseForm.legalLandArea"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-col :span="12">
          <el-form-item label="贡献用地面积m²:">
            <el-input v-model.number="baseForm.contributionLandArea"></el-input>
          </el-form-item>
        </el-col>
      </el-form>

      <!-- 涉及集体要素 -->
      <div class="ytct-flex-jcsb title2">
        <div class="border-left-4-2667C1">
          <label class="ml20 ft18 lh40 fw700">涉及集体要素</label>
        </div>
        <div>
          <el-button type="primary" icon="el-icon-plus" @click="openDialog">
            新增
          </el-button>
          <el-button type="primary" icon="el-icon-upload2"> 上传 </el-button>
          <el-button type="primary" class="mr40" plain icon="el-icon-document"
            >下载模板</el-button
          >
        </div>
      </div>
      <!-- 表格 -->
      <el-table
        :data="tableData"
        class="mt20"
        style="width: 96%; margin: 0 auto"
        border
      >
        <el-table-column prop="enterpriseName" label="企业名称">
        </el-table-column>
        <el-table-column prop="nonAgriculturaIndicators" label="非农指标">
        </el-table-column>
        <el-table-column prop="benefitSharingLand" label="利益共享用地">
        </el-table-column>
        <el-table-column prop="requisitionReturnLand" label="征地返还用地">
        </el-table-column>
        <el-table-column prop="landName" label="土地"> </el-table-column>
        <el-table-column prop="landCode" label="土地编码"> </el-table-column>
        <el-table-column prop="propertyName" label="物业"> </el-table-column>
        <el-table-column prop="propertyCode" label="物业编码">
        </el-table-column>
        <el-table-column label="操作">
          <template v-slot="scope">
            <el-tooltip
              :enterable="false"
              effect="dark"
              content="编辑"
              placement="top-start"
            >
              <el-button
                type="primary"
                icon="el-icon-edit"
                @click="showEditDialog(scope.$index)"
                size="mini"
              ></el-button>
            </el-tooltip>

            <el-tooltip
              :enterable="false"
              effect="dark"
              content="删除"
              placement="top-start"
            >
              <el-button
                type="danger"
                icon="el-icon-delete"
                size="mini"
                @click="removeOneData(scope.$index)"
              ></el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>

      <!-- 合作情况 -->

      <div class="border-left-4-2667C1 title3">
        <label class="ml20 ft18 lh40 fw700">合作情况</label>
      </div>
      <el-form
        :model="cooperateForm"
        ref="cooperateForm"
        class="ml40 mr40"
        label-position="top"
      >
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item
              label="涉及国有企业："
              prop="involvingStateOwnedEnterprises"
            >
              <el-input
                v-model="cooperateForm.involvingStateOwnedEnterprises"
                maxlength="120"
                placeholder="请输入涉及国有企业"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item
              label="涉及集体企业"
              prop="involvingCollectiveEnterprises"
            >
              <el-input
                v-model="cooperateForm.involvingCollectiveEnterprises"
                placeholder="请输入涉及集体企业"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="合作模式:">
              <el-select v-model="initCoopMode">
                <el-option
                  v-for="item in cooperateForm.cooperationMode"
                  :key="item.dictKey"
                  :label="item.dictValue"
                  :value="item.dictKey"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>

        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item
              label="分摊违建建安成本："
              prop="apportionedIllegalBuildingCost"
              ><el-input
                v-model="cooperateForm.apportionedIllegalBuildingCost"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="分摊资金来源：" prop="apportionedFundSource"
              ><el-input
                v-model="cooperateForm.apportionedFundSource"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item
              label="预期物业分配（m²）："
              prop="expectedPropertyDistribution"
              ><el-input
                v-model.number="cooperateForm.expectedPropertyDistribution"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item
              label="国有企业（m²）："
              prop="stateOwnedEnterprisesLand"
              ><el-input
                v-model.number="cooperateForm.stateOwnedEnterprisesLand"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item
              label="集体企业（m²）："
              prop="collectiveEnterprisesLand"
              ><el-input
                v-model.number="cooperateForm.collectiveEnterprisesLand"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-col>
          <el-form-item label="项目进展" prop="projectProgress">
            <el-input
              type="textarea"
              v-model="cooperateForm.projectProgress"
              resize="none"
              :rows="3"
              maxlength="500"
              show-word-limit
              placeholder="请输入项目进展情况"
            ></el-input
          ></el-form-item>
        </el-col>
        <el-col>
          <el-form-item label="备注" prop="remark">
            <el-input
              type="textarea"
              v-model="cooperateForm.remark"
              resize="none"
              :rows="3"
              maxlength="500"
              show-word-limit
              placeholder="请输入备注"
            ></el-input
          ></el-form-item>
        </el-col>
        <el-col>
          <el-form-item label="输入链接：" prop="link"
            ><el-input v-model="cooperateForm.link"></el-input>
          </el-form-item>
        </el-col>
        <!-- 附件 -->
        <el-col :span="6">
          <el-form-item label="附件：">
            <el-upload
              class="upload-demo"
              action="https://jsonplaceholder.typicode.com/posts/"
              :on-preview="handlePreview"
              :on-remove="handleRemove"
              :before-remove="beforeRemove"
              multiple
              :limit="3"
              :on-exceed="handleExceed"
              :file-list="fileList"
              :show-file-list="true"
            >
              <el-button size="small" type="primary" icon="el-icon-upload2"
                >点击上传</el-button
              >
              <span slot="tip" class="el-upload__tip ml20"
                >只能上传jpg/png/ppt/doc/pdf/xls文件，且不超过30M</span
              >
            </el-upload>
          </el-form-item>
        </el-col>
      </el-form>
    </el-card>
    <!-- 新增、编辑弹窗 -->
    <el-dialog
      :title="dialogTitle"
      :visible.sync="addDialogVisible"
      width="50%"
      :show-close="false"
      :modal-append-to-body="false"
      :close-on-press-escape="false"
      :close-on-click-modal="false"
      @close="addDialogClosed"
    >
      <el-form
        :model="addDialogForm"
        :rules="addDialogRules"
        ref="addDialogFormRef"
        label-position="top"
      >
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="企业名称" prop="enterpriseName">
              <el-input v-model="addDialogForm.enterpriseName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="非农指标" prop="nonAgriculturaIndicators">
              <el-input
                v-model.number="addDialogForm.nonAgriculturaIndicators"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="利益共享用地（m²）" prop="benefitSharingLand">
              <el-input
                v-model.number="addDialogForm.benefitSharingLand"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item
              label="征地返还用地（m²）"
              prop="requisitionReturnLand"
            >
              <el-input
                v-model.number="addDialogForm.requisitionReturnLand"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="土地（m²）" prop="landName">
              <el-input v-model.number="addDialogForm.landName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="土地编码" prop="landCode">
              <el-input v-model.number="addDialogForm.landCode"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item label="物业" prop="propertyName">
              <el-input v-model="addDialogForm.propertyName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="物业编码" prop="propertyCode">
              <el-input v-model.number="addDialogForm.propertyCode"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer">
        <el-button @click="submitCancel">取 消</el-button>
        <el-button type="primary" @click="submitAddOrEdit">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { getDictionary } from "@/api/system/dict.js";
import {
  addCompanyCoopBasic,
  getCompanyCoopBasicInfoDetail,
} from "@/api/devservice/housing-security-cooperation";
export default {
  inject: ["reload", "index"],
  data() {
    return {
      id: this.$route.query.id,
      pageTitle: this.$route.query.pageTitle,
      districtCode: this.$route.query.districtCode,
      townCode: this.$route.query.townCode,
      districtName: this.$route.query.districtName,
      townName: this.$route.query.townName,

      addDialogVisible: false,
      baseForm: {
        projectName: "",
        projectStatus: [],
        developmentMode: [],

        locatedPosition: "",
        districtName: "",
        townName: "",
        developmentDirection: [],

        projectLandArea: "",
        currentBuildingArea: "",
        legalLandArea: "",
        contributionLandArea: "",
      },
      tableData: [],

      initState: "未开展",
      initDevMode: "城市更新",
      initDevDirection: "大方向",

      initCoopMode:"协议合作",

      addDialogForm: {
        enterpriseName: "",
        nonAgriculturaIndicators: "",
        benefitSharingLand: "",
        landName: "",
        landCode: "",
        propertyName: "",
        propertyCode: "",
      },

      cooperateForm: {
        involvingStateOwnedEnterprises: "",
        involvingCollectiveEnterprises: "",
        cooperationMode:[],

        apportionedIllegalBuildingCost: "",
        apportionedFundSource: "",
        expectedPropertyDistribution: "",
        stateOwnedEnterprisesLand: "",
        collectiveEnterprisesLand: "",

        projectProgress: "",
        remark: "",
      },
      fileList: [
        {
          name: "food.jpeg",
          url:
            "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
        },
        {
          name: "food2.jpeg",
          url:
            "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
        },
      ],
      addDialogRules: {
        enterpriseName: [
          { required: true, message: "请输入企业名称", trigger: "blur" },
        ],
        nonAgriculturaIndicators: [
          { required: true, message: "输入不能为空", trigger: "blur" },
          { type: "number", message: "必须为数字值", trigger: "blur" },
        ],
        benefitSharingLand: [
          { required: true, message: "输入不能为空", trigger: "blur" },
          { type: "number", message: "必须为数字值", trigger: "blur" },
        ],
        requisitionReturnLand: [
          { required: true, message: "输入不能为空", trigger: "blur" },
          { type: "number", message: "必须为数字值", trigger: "blur" },
        ],
        landName: [
          { required: true, message: "输入不能为空", trigger: "blur" },
          { type: "number", message: "必须为数字值", trigger: "blur" },
        ],
        landCode: [
          { required: true, message: "输入不能为空", trigger: "blur" },
          { type: "number", message: "必须为数字值", trigger: "blur" },
        ],
        propertyName: [
          { required: true, message: "请输入物业名称", trigger: "blur" },
        ],
        propertyCode: [
          { required: true, message: "输入不能为空", trigger: "blur" },
          { type: "number", message: "必须为数字值", trigger: "blur" },
        ],
      },
      dialogTitle: "新增",
      choseIndex: 0,
      isSubmitFlag: false,
    };
  },

  created() {
    this.enterWhichPage(); //是编辑页还是新增页
  },
  methods: {
    enterWhichPage() {
      if (this.$route.query.pageTitle == "新增") {
        this.getDictionaryFun(); //获取下拉框字典
      } else if (this.$route.query.pageTitle == "编辑") {
        this.getCompanyCoopBasicInfoDetailFun();
      }
    },
    getDictionaryFun() {
      let arr = ["project_status", "project_dev_mode", "project_dev_direction","housing-coop-mode"];
      for (let i = 0; i < arr.length; i++) {
        let params = {};
        params = {};
        params.code = arr[i];
        getDictionary(params).then((res) => {
          if (res.data.success) {
            if (i == 0) {
              this.baseForm.projectStatus = res.data.data;

              console.log(this.baseForm.projectStatus);
            } else if (i == 1) {
              this.baseForm.developmentMode = res.data.data;
            } else if (i == 2) {
              this.baseForm.developmentDirection = res.data.data;
            }else if(i==3){
              this.cooperateForm.cooperationMode=res.data.data;
            }
          } else {
            this.$message({
              type: "error",
              message: res.data.msg,
            });
          }
        });
      }
    },
    getCompanyCoopBasicInfoDetailFun() {
      let params = { id: this.$route.query.id };
      getCompanyCoopBasicInfoDetail(params).then((res) => {
        if (res.data.success) {
          this.baseForm = res.data.data;
          this.tableData = res.data.data.companyCoopServiceItemsList;
          this.cooperateForm = res.data.data.companyCoopServiceInfo;
          this.getDictionaryFun(); //获取下拉框字典
        } else {
          this.$message({
            type: "error",
            message: res.data.msg,
          });
        }
      });
    },
    //点击上传文件
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePreview(file) {
      console.log(file);
      window.open(file.url);
    },
    handleExceed(files, fileList) {
      this.$message.warning(
        `当前限制选择 3 个文件，本次选择了 ${files.length} 个文件，共选择了 ${
          files.length + fileList.length
        } 个文件`
      );
    },
    handleBeforeUpload(file) {
      const isLt30M = file.size < 1024 * 1024 * 30;
      if (!isLt30M) {
        this.$message.error("上传的视频大小不能超过 30MB!");
        return;
      }
      return isLt30M;
    },
    beforeRemove(file, fileList) {
      console.log(this.file, fileList, "99");
      return this.$confirm(`确定移除 ${file.name}？`);
    },
    submitCancel() {
      this.addDialogVisible = false;
    },
    // 提交集体要素的弹窗表单
    submitAddOrEdit() {
      this.$refs.addDialogFormRef.validate((valid) => {
        if (!valid) return;
        if (this.dialogTitle == "新增") {
          this.$message({
            type: "success",
            message: "已新增一条记录!",
          });
          this.tableData.push({ ...this.addDialogForm });
        } else if (this.dialogTitle == "编辑") {
          this.$message({
            type: "success",
            message: "修改成功!",
          });
          //替换选中的一行记录
          this.tableData.splice(this.choseIndex, 1, { ...this.addDialogForm });
        }

        this.addDialogVisible = false;
      });
    },
    //打开新增弹框
    openDialog() {
      this.dialogTitle = "新增";
      this.addDialogForm = {};
      this.addDialogVisible = true;
    },
    // 关闭新增弹窗时候进行表单重置
    addDialogClosed() {
      //进行表单的重置
      this.$refs.addDialogFormRef.resetFields();
    },
    //打开编辑弹窗
    showEditDialog(index) {
      this.dialogTitle = "编辑";
      this.addDialogVisible = true;
      this.choseIndex = index;
      this.addDialogForm = { ...this.tableData[index] };
    },
    removeOneData(index) {
      this.tableData.splice(index, 1);
    },
    //提交所有表单
    submitForm() {
      //多穿一个id,就是编辑
      let params = {
        companyCoopServiceInfo: {
          involvingStateOwnedEnterprises: this.cooperateForm
            .involvingStateOwnedEnterprises,
          involvingCollectiveEnterprises: this.cooperateForm
            .involvingCollectiveEnterprises,
             cooperationMode:this.initCoopMode =="协议合作"? "0" : this.initCoopMode,

          apportionedIllegalBuildingCost: this.cooperateForm
            .apportionedIllegalBuildingCost,
          apportionedFundSource: this.cooperateForm.apportionedFundSource,
          expectedPropertyDistribution: this.cooperateForm
            .expectedPropertyDistribution,

          stateOwnedEnterprisesLand: this.cooperateForm
            .stateOwnedEnterprisesLand,
          collectiveEnterprisesLand: this.cooperateForm
            .collectiveEnterprisesLand,

          projectProgress: this.cooperateForm.projectProgress,
          remark: this.cooperateForm.remark,
          link: this.cooperateForm.link,
        },
        companyCoopServiceItemsList: this.tableData,
      };
      if (this.pageTitle == "新增") {
        params.cooperationType = 4; //合作类型【0土地1物业2产业3资金4住房】修改不用传
      } else if (this.pageTitle == "编辑") {
        params.id = this.$route.query.id;
      }
      params.projectName = this.baseForm.projectName;
      params.projectStatus = this.initState == "未开展" ? "0" : this.initState;
      params.locatedPosition = this.baseForm.locatedPosition;

      params.developmentMode =
        this.initDevMode == "城市更新" ? "0" : this.initDevMode;
      params.districtCode = this.districtCode;
      params.townCode = this.townCode;

      params.developmentDirection =
        this.initDevDirection == "大方向" ? "0" : this.initDevDirection;
      params.projectLandArea = this.baseForm.projectLandArea;
      params.currentBuildingArea = this.baseForm.currentBuildingArea;
      params.legalLandArea = this.baseForm.legalLandArea;
      params.contributionLandArea = this.baseForm.contributionLandArea;
      console.log(params, "住房保障合作");
      addCompanyCoopBasic(params).then((res) => {
        if (res.data.success) {
          this.$message({
            type: "success",
            message: "提交数据成功!",
          });
          this.index.closeTag(this.$route.fullPath);
        } else {
          this.$message({
            type: "error",
            message: res.data.msg,
          });
        }
      });
    },
  },
};
</script>

<style lang="scss">
#housing-security-cooperation-projdetail {
  background-color: #f5f5f6;
  overflow-y: scroll;
  height: 100%;
  .el-select {
    width: 100%;
  }
  .el-button {
    padding: 8px 8px;
  }

  .edit-content {
    .title2,
    .title3 {
      position: relative;
      width: 100%;
      &::before {
        content: "";
        position: absolute;
        width: 96%;
        height: 1px;
        top: -10px;
        left: 40px;
        background-color: #d8d8d8;
      }
    }
  }
}
</style>