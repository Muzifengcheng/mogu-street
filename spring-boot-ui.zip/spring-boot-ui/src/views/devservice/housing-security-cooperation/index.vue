<template>
  <div id="housing-security-cooperation-index">
    <el-row>
      <el-col :span="6">
        <div class="box">
          <el-scrollbar>
            <basic-container>
              <avue-tree
                :option="treeOption"
                :data="treeData"
                @node-click="nodeClick"
              />
            </basic-container>
          </el-scrollbar>
        </div>
      </el-col>

      <el-col :span="18">
        <el-table
          :data="tableData"
          class="mt20"
          style="width: 98%; margin: 0 auto"
          :header-cell-style="{
            background: '#F4F7FA',
            fontWeight: '700',
            color: '#435B76',
          }"
        >
          <el-table-column type="index" label="序号" align="left" width="50">
          </el-table-column>
          <el-table-column align="center" label="行政区（新区）">
            <template v-slot="scope">  
              <router-link
                class="c-39baf4"
                :to="{ path: 'districts',query:{districtCode:scope.row.districtCode}}"
                >{{ scope.row.districtName }}</router-link
              >
            </template>
          </el-table-column>

          <el-table-column align="center" prop="projectAmount" label="项目总数">
          </el-table-column>
          <el-table-column align="center" prop="projectLandAreaTotal" label="用地面积m²">
          </el-table-column>
          <el-table-column
            align="center"
            prop="expectedPropertyDistributionTotal"
            label="集体预期分得建筑面积m²"
          >
          </el-table-column>
          <el-table-column align="center" prop="forCooperationAmount" label="待合作">
          </el-table-column>
          <el-table-column align="center" prop="advancingAmount" label="推进中">
          </el-table-column>
          <el-table-column align="center" prop="finishedAmount" label="已完成">
          </el-table-column>
        </el-table>
        <div class="footerpage mt20 mr20">
          <span
            >共<span>{{ paginations.total }}</span
            >条记录
          </span>
          <el-pagination
            :total="paginations.total"
            :current-page.sync="paginations.page_index"
            :page-size="paginations.page_size"
            @current-change="handleCurrentChange"
            :layout="paginations.layout"
          ></el-pagination>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { getPrimaryDataArea,getCompanyCoopBasic } from "@/api/devservice/common";
export default {
  data() {
    return {
      tableData: [
      ],
      paginations: {
        page_index: 1, //当前位于那页
        total: 0, //总数
        page_size: 10, //一页显示多少个
        layout: "prev,pager,next,jumper", //翻页属性
      },
      treeData: [],
      treeOption: {
        nodeKey: "id",
        lazy: true,
        treeLoad: function (node, resolve) {
          const parentCode = node.level === 0 ? "44" : node.data.code;
          getPrimaryDataArea(parentCode).then((res) => {
            resolve(
              res.data.data.map((item) => {
                return {
                  ...item,
                  leaf: !(item.childList || item.childList.length > 0),
                };
              })
            );
          });
        },
        addBtn: false,
        menu: false,
        size: "small",
        props: {
          labelText: "标题",
          label: "name",
          value: "code",
          children: "childList",
        },
      },
    };
  },
  created() {
    this.getCompanyCoopBasicFun();
  },
  methods: {
      getCompanyCoopBasicFun() {
      let params = {};
      params.code = "4403";
      params.cooperationType = 4; // 	合作类型【0土地1物业2产业3资金4住房】
      params.current = this.paginations.page_index;
      params.size = this.paginations.page_size;
        getCompanyCoopBasic(params).then((res) => {
        if (res.data.success) {
          this.tableData = res.data.data.records;
          this.paginations.total = res.data.data.total;
        } else {
          this.$message({
            type: "error",
            message: res.data.msg,
          });
        }
      });
    },
    handleCurrentChange(val) {
      this.paginations.page_index = val;
      //调用查询接口
       this.getCompanyCoopBasicFun();
    },
    nodeClick(){
 
    }
  },
};
</script>

<style lang="scss">
#housing-security-cooperation-index {
  height: 100%;
  overflow: scroll;
  background-color: #f5f5f6;
  .box {
    height: 800px;
  }

  .el-scrollbar {
    height: 100%;
  }

  .box .el-scrollbar__wrap {
    overflow: scroll;
  }
  .footerpage {
    display: flex;
    justify-content: flex-end;
    align-items: center;
  }
}
</style>