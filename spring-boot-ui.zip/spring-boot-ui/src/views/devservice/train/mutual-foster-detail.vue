<template>
  <div id="mutual-foster-detail">
    <h3>互培详情</h3>
    <el-card class="base pb20">
      <div class="border-left-4-2667C1 title1">
        <label class="ml20 ft18 lh40 fw700">基本情况</label>
      </div>
      <el-form
        :model="baseForm"
        ref="baseForm"
        class="ml40 mr40"
        label-position="left"
      >
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="公司名称:"> 深圳市地铁交易集团 </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="负责人:"> </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="联系人:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="联系方式:"> </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </el-card>
    <el-card class="collective mt20">
      <div class="border-left-4-2667C1">
        <label class="ml20 ft18 lh40 fw700">提供岗位</label>
      </div>

      <el-col>
        <span class="ml40 mr40">岗位：<el-inpput></el-inpput></span>
      </el-col>
    </el-card>
    <!-- 挂职情况 -->
    <el-card class="cooporation mt20">
      <div class="border-left-4-2667C1 title3">
        <label class="ml20 ft18 lh40 fw700">其它</label>
      </div>
      <el-form
        :model="cooperateForm"
        ref="cooperateForm"
        class="ml40 mr40"
        label-position="left"
      >
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="姓名:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="人才编码:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="所属公司："> </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="公司所在行政区:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="公司所在街道:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="挂职时间（开始/结束）："> </el-form-item>
          </el-col>
        </el-row>
        <el-col :span="24"><el-form-item label="挂职岗位：">
        </el-form-item></el-col>
      </el-form>
    </el-card>
  </div>
</template>

<script>
export default {
  data() {
    return {
      baseForm: {
        projname: "",
        projstatus: [
          {
            id: 1,
            value: "选项1",
            label: "黄金糕",
          },
          {
            id: 2,
            value: "选项2",
            label: "双皮奶",
          },
          {
            value: "选项3",
            label: "蚵仔煎",
          },
          {
            value: "选项4",
            label: "龙须面",
          },
          {
            value: "选项5",
            label: "北京烤鸭",
          },
        ],
        localtion: "",
        developmethods: [
          {
            id: 1,
            value: "选项1",
            label: "黄金糕",
          },
          {
            id: 2,
            value: "选项2",
            label: "双皮奶",
          },
          {
            value: "选项3",
            label: "蚵仔煎",
          },
          {
            value: "选项4",
            label: "龙须面",
          },
          {
            value: "选项5",
            label: "北京烤鸭",
          },
        ],
        district: [
          {
            id: 1,
            value: "选项1",
            label: "黄金糕",
          },
          {
            id: 2,
            value: "选项2",
            label: "双皮奶",
          },
          {
            value: "选项3",
            label: "蚵仔煎",
          },
          {
            value: "选项4",
            label: "龙须面",
          },
          {
            value: "选项5",
            label: "北京烤鸭",
          },
        ],
        block: [
          {
            id: 1,
            value: "选项1",
            label: "黄金糕",
          },
          {
            id: 2,
            value: "选项2",
            label: "双皮奶",
          },
          {
            value: "选项3",
            label: "蚵仔煎",
          },
          {
            value: "选项4",
            label: "龙须面",
          },
          {
            value: "选项5",
            label: "北京烤鸭",
          },
        ],
        devdirection: [
          {
            id: 1,
            value: "选项1",
            label: "黄金糕",
          },
          {
            id: 2,
            value: "选项2",
            label: "双皮奶",
          },
          {
            value: "选项3",
            label: "蚵仔煎",
          },
          {
            value: "选项4",
            label: "龙须面",
          },
          {
            value: "选项5",
            label: "北京烤鸭",
          },
        ],
        projUseLandArea: "",
        buildingArea: "",
      },
      initValue: "黄金糕",
      cooperateForm: {},
    };
  },
  created() {},
  methods: {},
};
</script>

<style lang="scss">
#mutual-foster-detail {
  background-color: #f5f5f6;
  overflow-y: scroll;
  height: 100%;
  .el-card__body {
    padding: 16px 0px !important;
  }
}
</style>