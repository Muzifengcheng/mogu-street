<template>
  <div id="history-training-index">
    <el-row>
      <el-col :span="9">
        <div class="box">
          <el-scrollbar>
            <basic-container>
              <avue-tree
                :option="treeOption"
                :data="treeData"
                @node-click="nodeClick"
              />
            </basic-container>
          </el-scrollbar>
        </div>
      </el-col>
      <el-col :span="15">
        <div class="top-information pt20">
          <div class="limit-chose">
            <span class="ml20">
              时间：
              <el-date-picker
                v-model="value1"
                type="month"
                placeholder="选择月"
              >
              </el-date-picker>
            </span>
            <span class="ml20">
              培训机构：
              <el-select v-model="initValue">
                <el-option
                  v-for="item in categories"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </span>
          </div>
        </div>
        <div class="three_chose mt20">
          <span
            :class="{ ml20: true, active: currentIndex == index }"
            v-for="(item, index) in itemList"
            :key="index"
            @click="itemClick(index)"
            >{{ item }}</span
          >
        </div>
        <!-- 历史培训 -->
        <el-table
          v-if="currentIndex == 0"
          :data="historyTableData"
          style="width: 98%; margin: 0 auto"
          :header-cell-style="{
            background: '#F4F7FA',
            fontWeight: '700',
            color: 'black',
          }"
        >
          <el-table-column type="index" label="序号" align="center" width="50">
          </el-table-column>
          <el-table-column align="left" label="牵头行政区">
            <template v-slot="scope1">
              <router-link class="c-39baf4" :to="{ path: 'traindetail/4' }">{{
                scope1.row.projName
              }}</router-link>
            </template>
          </el-table-column>
          <el-table-column align="left" prop="useLandArea" label="课程名称">
          </el-table-column>
          <el-table-column
            align="left"
            prop="expectedPropertyAllocation"
            label="讲师"
          >
          </el-table-column>
          <el-table-column align="left" prop="devMethods" label="培训机构">
          </el-table-column>
          <el-table-column align="left" prop="cooperateMode" label="培训会场">
          </el-table-column>
          <el-table-column align="left" prop="publishTime" label="培训时间">
          </el-table-column>
          <el-table-column align="left" prop="cooperateState" label="培训人数">
          </el-table-column>
          <el-table-column align="left" prop="state" label="培训状态">
          </el-table-column>
        </el-table>
        <!-- 培训预通知 -->
        <el-table
          v-if="currentIndex == 1"
          :data="trainTableData"
          style="width: 98%; margin: 0 auto"
          :header-cell-style="{
            background: '#f5f5f6',
            fontWeight: '700',
            color: 'black',
          }"
        >
          <el-table-column type="index" label="序号" align="center" width="50">
          </el-table-column>
          <el-table-column align="left" prop="projName" label="牵头行政区">
            <template v-slot="scope2">
              <router-link class="c-39baf4" :to="{ path: 'traindetail/3' }">{{
                scope2.row.projName
              }}</router-link>
            </template>
          </el-table-column>
          <el-table-column align="left" prop="useLandArea" label="课程名称">
          </el-table-column>
          <el-table-column
            align="left"
            prop="expectedPropertyAllocation"
            label="讲师"
          >
          </el-table-column>
          <el-table-column align="left" prop="devMethods" label="培训机构">
          </el-table-column>
          <el-table-column align="left" prop="cooperateMode" label="培训会场">
          </el-table-column>
          <el-table-column align="left" prop="publishTime" label="培训时间">
          </el-table-column>
          <el-table-column align="left" prop="cooperateState" label="培训人数">
          </el-table-column>
          <el-table-column align="left" prop="state" label="是否可参加">
          </el-table-column>
          <el-table-column label="下载报名表">
            <template v-slot="scope">
              <el-tag :type="scope.row.type" effect="dark">{{
                scope.row.download
              }}</el-tag>
            </template>
          </el-table-column>
        </el-table>
        <!-- 机构库 -->
        <el-table
          v-if="currentIndex == 2"
          :data="institutionTableData"
          style="width: 98%; margin: 0 auto"
          :header-cell-style="{
            background: '#f5f5f6',
            fontWeight: '700',
            color: 'black',
          }"
        >
          <el-table-column type="index" label="序号" align="center" width="50">
          </el-table-column>
          <el-table-column align="left" label="机构名称">
            <template v-slot="scope3">
              <router-link class="c-39baf4" :to="{ path: 'institutiondetail/2' }">{{
                scope3.row.projName
              }}</router-link>
            </template>
          </el-table-column>
          <el-table-column align="left" prop="useLandArea" label="推荐行政区">
          </el-table-column>
          <el-table-column
            align="left"
            prop="expectedPropertyAllocation"
            label="擅长领域"
          >
          </el-table-column>
          <el-table-column align="left" prop="devMethods" label="最新培训时间">
          </el-table-column>
          <el-table-column
            align="left"
            prop="cooperateMode"
            label="已完成培训次数"
          >
          </el-table-column>
          <el-table-column align="left" prop="publishTime" label="联系人">
          </el-table-column>
          <el-table-column align="left" prop="cooperateState" label="联系方式">
          </el-table-column>
        </el-table>
        <div class="footerpage mt20 mr20">
          <span
            >共<span>{{ paginations.total }}</span
            >条记录
          </span>
          <el-pagination
            :total="paginations.total"
            :current-page.sync="paginations.page_index"
            :page-size="paginations.page_size"
            @current-change="handleCurrentChange"
            :layout="paginations.layout"
          ></el-pagination>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data() {
    return {
      value1: "",
      categories: [
        {
          value: "选项1",
          label: "经济管理",
        },
        {
          value: "选项2",
          label: "文化管理",
        },
        {
          value: "选项3",
          label: "政治管理",
        },
        {
          value: "选项4",
          label: "军事管理",
        },
        {
          value: "选项5",
          label: "科技管理",
        },
      ],
      initValue: "经济管理",
      itemList: ["历史培训", "培训预通知", "机构库"],
      currentIndex: 0,
      historyTableData: [
        {
          projName: "福田区",
          useLandArea: "北京大道",
          expectedPropertyAllocation: "斗鱼",
          devMethods: "2",
          cooperateMode: "南京大学",
          publishTime: "本科",
          cooperateState: "是",
          reviewState: "2020-8-25",
          state: "已审核",
          type: "success",
        },
      ],
      trainTableData: [
        {
          projName: "宝安区",
          useLandArea: "如何花好每一份钱",
          expectedPropertyAllocation: "斗鱼",
          devMethods: "2",
          cooperateMode: "南京大学",
          publishTime: "本科",
          cooperateState: "是",
          reviewState: "2020-8-25",
          state: "是",
          download: "下载",
          type: "success",
        },
      ],
      institutionTableData: [
        {
          projName: "龙岗区",
          useLandArea: "北京大道",
          expectedPropertyAllocation: "斗鱼",
          devMethods: "2",
          cooperateMode: "南京大学",
          publishTime: "本科",
          cooperateState: "是",
          reviewState: "2020-8-25",
          state: "已审核",
          type: "success",
        },
      ],
      paginations: {
        page_index: 1, //当前位于那页
        total: 5, //总数
        page_size: 10, //一页显示多少个
        layout: "prev,pager,next,jumper", //翻页属性
      },
      treeData: [],
      treeOption: {
        nodeKey: "id",
        lazy: true,
        treeLoad: function (node, resolve) {
          const parentCode = node.level === 0 ? "00" : node.data.id;
          getLazyTree(parentCode).then((res) => {
            resolve(
              res.data.data.map((item) => {
                return {
                  ...item,
                  leaf: !item.hasChildren,
                };
              })
            );
          });
        },
        addBtn: false,
        menu: false,
        size: "small",
        props: {
          labelText: "标题",
          label: "title",
          value: "value",
          children: "children",
        },
      },
    };
  },
  created() {},
  methods: {
    itemClick(index) {
      this.currentIndex = index;
    },
    handleCurrentChange(val) {
      this.paginations.page_index = val;
      //调用查询接口
    },
  },
};
</script>

<style lang="scss">
#history-training-index {
  height: 100%;
  overflow: scroll;
  background-color: #f5f5f6;
  .box {
    height: 800px;
  }

  .el-scrollbar {
    height: 100%;
  }

  .box .el-scrollbar__wrap {
    overflow: scroll;
  }
  .three_chose {
    > span {
      display: inline-block;
      padding: 0 10px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      &.active {
        color: #86ce2a;
        background-color: #ffffff;
      }
    }
  }
  .footerpage {
    display: flex;
    justify-content: flex-end;
    align-items: center;
  }
}
</style>