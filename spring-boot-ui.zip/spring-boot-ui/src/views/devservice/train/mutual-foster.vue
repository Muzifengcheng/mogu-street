<template>
  <div id="talents-mutual-foster">
    <div class="top-information pt20">
      <div class="limit-chose">
        <span class="ml20">
          时间：
          <el-date-picker v-model="value1" type="month" placeholder="选择月">
          </el-date-picker>
        </span>
        <span class="ml20">
          培训机构：
          <el-select v-model="initValue">
            <el-option
              v-for="item in categories"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </span>
      </div>
    </div>
    <el-table
      :data="mutualFosterTableData"
      style="width: 98%; margin: 0 auto"
      :header-cell-style="{
        background: '#f5f5f6',
        fontWeight: '700',
        color: 'black',
      }"
    >
      <el-table-column type="index" label="序号" align="center" width="50">
      </el-table-column>
      <el-table-column align="left" prop="projName" label="相关企业">
      </el-table-column>
      <el-table-column align="left" prop="useLandArea" label="历史挂职人数">
      </el-table-column>
      <el-table-column
        align="left"
        prop="expectedPropertyAllocation"
        label="挂职人数"
      >
      </el-table-column>
      <el-table-column align="left" prop="devMethods" label="岗位数量">
      </el-table-column>
      <el-table-column align="left" prop="cooperateMode" label="空缺数量">
      </el-table-column>
      <el-table-column align="left" prop="publishTime" label="负责人">
      </el-table-column>

    </el-table>
    <!-- 分页器 -->
    <div class="footerpage mt20 mr20">
      <span
        >共<span>{{ paginations.total }}</span
        >条记录
      </span>
      <el-pagination
        :total="paginations.total"
        :current-page.sync="paginations.page_index"
        :page-size="paginations.page_size"
        @current-change="handleCurrentChange"
        :layout="paginations.layout"
      ></el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      value1: "",
      categories: [
        {
          value: "选项1",
          label: "深圳迎宾馆有限公司",
        },
        {
          value: "选项2",
          label: "腾讯科技",
        },
        {
          value: "选项3",
          label: "汉东集团",
        },
      ],
      initValue: "深圳迎宾馆有限公司",
      mutualFosterTableData: [
        {
          projName: "福田区",
          useLandArea: "北京大道",
          expectedPropertyAllocation: "斗鱼",
          devMethods: "2",
          cooperateMode: "南京大学",
          publishTime: "本科",
          cooperateState: "是",
          reviewState: "2020-8-25",
          state: "已审核",
          type: "success",
        },
      ],
      paginations: {
        page_index: 1, //当前位于那页
        total: 0, //总数
        page_size: 10, //一页显示多少个
        layout: "prev,pager,next,jumper", //翻页属性
      },
    };
  },
  created() {},
  methods: {
    handleCurrentChange(val) {
      this.paginations.page_index = val;
      //调用查询接口
    },
  },
};
</script>

<style lang="scss">
#talents-mutual-foster {
  height: 100%;
  overflow: scroll;
  background-color: #f5f5f6;

  .footerpage {
    display: flex;
    justify-content: flex-end;
    align-items: center;
  }
}
</style>