<template>
  <div id="talents-institution-detail">
    <el-card class="base pb20">
      <div class="border-left-4-2667C1 title1">
        <label class="ml20 ft18 lh40 fw700">机构详情</label>
      </div>
      <el-form
        :model="trainDetailForm"
        ref="baseForm"
        class="ml40 mr40"
        label-position="left"
      >
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="机构名称:"> 外交部 </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="推荐行政区:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="地址:"> </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="擅长领域:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="末次培训时间:"> </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="负责人:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="联系人:"> </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="联系方式:"> </el-form-item>
          </el-col>
        </el-row>
        <h3>历史课程</h3>
        <el-table :data="tableData" style="width: 100%" border>
          <el-table-column label="课程名称" align="center" prop="courseName"> </el-table-column>
          <el-table-column label="讲师" align="center"> </el-table-column>
          <el-table-column label="培训时间" align="center"> </el-table-column>
          <el-table-column label="培训会场" align="center"> </el-table-column>
          <el-table-column label="培训人数" align="center"> </el-table-column>
          <el-table-column label="培训状态" align="center"> </el-table-column>
        </el-table>

        <el-col>
          <el-form-item label="成功附件:">
            <el-upload
              class="upload-demo"
              action="https://jsonplaceholder.typicode.com/posts/"
              :on-preview="handlePreview"
              :on-remove="handleRemove"
              :before-upload="handleBeforeUpload"
              :before-remove="beforeRemove"
              multiple
              :limit="3"
              :on-exceed="handleExceed"
              :file-list="fileList"
              :show-file-list="ture"
            >
              <el-button size="small" type="primary" icon="el-icon-upload2"
                >点击上传</el-button
              >
            </el-upload>
          </el-form-item>
        </el-col>
      </el-form>
    </el-card>
  </div>
</template>

<script>
export default {
  data() {
    return {
      trainDetailForm: {},
      tableData: [

      ],
      fileList: [
        {
          name: "food.jpeg",
          url:
            "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
        },
        {
          name: "food2.jpeg",
          url:
            "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
        },
      ],
    };
  },
  created() {},
  methods: {
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePreview(file) {
      console.log(file);
      window.open(file.url);
    },
    handleExceed(files, fileList) {
      console.log(files, "hhh");
      console.log(fileList, "ggg");
      this.$message.warning(
        `当前限制选择 3 个文件，本次选择了 ${files.length} 个文件，共选择了 ${
          files.length + fileList.length
        } 个文件`
      );
    },
    handleBeforeUpload(file) {
      const isLt30M = file.size < 1024 * 1024 * 30;
      if (!isLt30M) {
        this.$message.error("上传的视频大小不能超过 30MB!");
        return;
      }
      return isLt30M;
    },
    beforeRemove(file, fileList) {
      console.log(this.file, "99");
      return this.$confirm(`确定移除 ${file.name}？`);
    },
  },
};
</script>

<style lang="scss">
#talents-institution-detail {
  background-color: #f5f5f6;
  overflow-y: scroll;
  height: 100%;
  .el-card__body {
    padding: 16px 0px !important;
  }
}
</style>