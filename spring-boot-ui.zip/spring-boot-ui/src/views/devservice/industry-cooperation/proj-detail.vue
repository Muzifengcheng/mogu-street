<template>
  <div id="industry-cooperation-projdetail">
    <h3>合作详情</h3>
    <el-card class="base pb20">
      <div class="border-left-4-2667C1 title1">
        <label class="ml20 ft18 lh40 fw700">基本情况</label>
      </div>
      <el-form
        :model="baseForm"
        ref="baseForm"
        class="ml40 mr40"
        label-position="left"
      >
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="项目名称:">
              {{ baseForm.projectName }}
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="行政区:">{{ districtName }} </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="所属街道:">{{ blockName }}</el-form-item>
          </el-col>
        </el-row>
        <el-col :span="24">
          <el-form-item label="坐落位置:">{{
            baseForm.locatedPosition
          }}</el-form-item>
        </el-col>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="项目用地面积:"
              >{{ baseForm.projectLandArea }}
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="现状建筑面积:">{{
              baseForm.currentBuildingArea
            }}</el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </el-card>
    <el-card class="collective mt20">
      <div class="ytct-flex-jcsb title2">
        <div class="border-left-4-2667C1">
          <label class="ml20 ft18 lh40 fw700">涉及集体要素</label>
        </div>
        <div>
          <el-button type="primary" icon="el-icon-upload2"> 上传 </el-button>
          <el-button type="primary" class="mr40" plain icon="el-icon-document"
            >下载模板</el-button
          >
        </div>
      </div>
      <!-- 表格 -->
      <el-table
        :data="tableData"
        class="mt20"
        style="width: 96%; margin: 0 auto"
        border
      >
        <el-table-column prop="enterpriseName" label="企业名称">
        </el-table-column>
        <el-table-column prop="landName" label="土地"> </el-table-column>
        <el-table-column prop="landCode" label="土地编码"> </el-table-column>
        <el-table-column prop="propertyName" label="物业"> </el-table-column>
        <el-table-column prop="propertyCode" label="物业编码">
        </el-table-column>
      </el-table>
    </el-card>
    <!-- 合作情况 -->
    <el-card class="cooporation mt20">
      <div class="border-left-4-2667C1 title3">
        <label class="ml20 ft18 lh40 fw700">合作情况</label>
      </div>
      <el-form
        :model="cooperateForm"
        ref="cooperateForm"
        class="ml40 mr40"
        label-position="left"
      >
        <el-col>
          <el-form-item label="涉及国有企业：">
            {{ cooperateForm.involvingStateOwnedEnterprises }}
          </el-form-item>
        </el-col>
        <el-col>
          <el-form-item label="涉及集体企业：">
            {{ cooperateForm.involvingCollectiveEnterprises }}
          </el-form-item>
        </el-col>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="合作模式：">{{cooperateForm.cooperationMode}} </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="项目状态：">{{cooperateForm.projectStatus}} </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="国高数量：">{{cooperateForm.highNumber}} </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="预期现金分配（元）：">{{cooperateForm.expectedCashDistribution}} </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="国有企业（元）：">{{cooperateForm.stateOwnedEnterprisesFund}} </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="集体企业（元）："> {{cooperateForm.collectiveEnterprisesFund}}</el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="是否规上：">{{cooperateForm.isOn}} </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="跟投额：">{{cooperateForm.followingInvestmentAmount}} </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="投资额：">{{cooperateForm.investmentAmount}} </el-form-item>
          </el-col>
        </el-row>
        <el-col>
          <el-form-item label="项目进展：">{{cooperateForm.projectProgress}} </el-form-item>
        </el-col>
        <el-col>
          <el-form-item label="备注：">{{cooperateForm.remark}} </el-form-item>
        </el-col>
        <el-col>
          <el-form-item label="输入链接：">{{cooperateForm.link}} </el-form-item>
        </el-col>
        <!-- 附件 -->
        <el-col :span="6">
          <el-form-item label="附件：">
            <el-upload
              class="upload-demo"
              action="https://jsonplaceholder.typicode.com/posts/"
              :on-preview="handlePreview"
              :on-remove="handleRemove"
              :before-remove="beforeRemove"
              multiple
              :limit="3"
              :on-exceed="handleExceed"
              :file-list="fileList"
              :show-file-list="true"
            >
              <el-button size="small" type="primary" icon="el-icon-upload2"
                >点击上传</el-button
              >
            </el-upload>
          </el-form-item>
        </el-col>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import { getCompanyCoopBasicInfoDetail } from "@/api/devservice/industry-cooperation";
export default {
  data() {
    return {
      districtName: this.$route.query.districtName,
      blockName: this.$route.query.townName,
      baseForm: {},
      tableData: [
        {
          companyName: "深圳市深圳市公共建设有限公司",
          noAgricultureTarget: "java开发",
          benefitShareLand: "1000",
        },
      ],
      cooperateForm: {},
      fileList: [
        {
          name: "food.jpeg",
          url:
            "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
        },
        {
          name: "food2.jpeg",
          url:
            "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
        },
      ],
    };
  },
  created() {
    this.getCompanyCoopBasicInfoDetailFun();
  },
  methods: {
    getCompanyCoopBasicInfoDetailFun() {
      let params = { id: this.$route.query.id };
      getCompanyCoopBasicInfoDetail(params).then((res) => {
        if (res.data.success) {
          this.baseForm = res.data.data;
          this.tableData = res.data.data.companyCoopServiceItemsList;
          this.cooperateForm = res.data.data.companyCoopServiceInfo;
        } else {
          this.$message({
            type: "error",
            message: res.data.msg,
          });
        }
      });
    },
  },
};
</script>

<style lang="scss">
#industry-cooperation-projdetail {
  background-color: #f5f5f6;
  overflow-y: scroll;
  height: 100%;
  .el-card__body {
    padding: 16px 0px !important;
  }
  .collective{
    .el-button{
      padding: 8px 8px;

    }
  }
}
</style>