<template>
  <div id="success-case-add-or-edit">
    <div class="ytct-flex-jcsb-aic">
      <span class="ft24 fw700 c-435b76">{{ pageTitle }}</span>
      <span>
        <el-button
          class="ml10"
          type="success"
          :loading="isSubmitFlag"
          @click="submitForm"
          >提交</el-button
        >
      </span>
    </div>
    <el-card class="edit-content pb20">
      <div class="border-left-4-2667C1 title1">
        <label class="ml20 ft18 lh40 fw700">基本情况</label>
      </div>
      <el-form
        :model="baseForm"
        ref="baseForm"
        class="ml40 mr40"
        label-position="top"
      >
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="项目名称：" prop="projectName">
              <el-input
                v-model="baseForm.projectName"
                maxlength="120"
                placeholder="请输入项目名称"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="合作状态：">
              <el-select v-model="initCoopStatus">
                <!-- 要给值 -->
                <el-option
                  v-for="item in baseForm.cooperationStatus"
                  :key="item.dictKey"
                  :label="item.dictValue"
                  :value="item.dictKey"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="坐落位置：" prop="locatedPosition">
              <el-input
                v-model="baseForm.locatedPosition"
                placeholder="请输入坐落位置"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="项目类型：">
              <el-select v-model="initProjType" multiple>
                <el-option
                  v-for="item in baseForm.projectTypes"
                  :key="item.dictKey"
                  :label="item.dictValue"
                  :value="item.dictKey"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="行政区：">
              <!-- <el-input v-model="districtName" disabled></el-input> -->
              <el-select
                v-model="initDistrictName"
                placeholder="请选择区域"
                @change="chooseDistrict"
              >
                <!-- 要给值 -->
                <el-option
                  v-for="item in baseForm.districtName"
                  :key="item.code"
                  :label="item.name"
                  :value="item.code"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="所属街道：">
              <el-select
                v-model="initTownName"
                placeholder="请选择街道"
                @change="chooseTown"
              >
                <!-- 要给值 -->
                <el-option
                  v-for="item in baseForm.townName"
                  :key="item.code"
                  :label="item.name"
                  :value="item.code"
                >
                </el-option> </el-select
            ></el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="合作模式：">
              <el-select v-model="initCooperateMode">
                <el-option
                  v-for="item in baseForm.cooperationMode"
                  :key="item.dictKey"
                  :label="item.dictValue"
                  :value="item.dictKey"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="项目用地面积(m²)：" prop="landArea">
              <el-input v-model.number="baseForm.landArea"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="现状建筑面积(m²)：" prop="buildingArea">
              <el-input v-model.number="baseForm.buildingArea"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>

      <!-- 合作情况 -->
      <div class="border-left-4-2667C1 title3">
        <label class="ml20 ft18 lh40 fw700">合作情况</label>
      </div>
      <el-form
        :model="baseForm"
        ref="baseForm"
        class="ml40 mr40"
        label-position="top"
      >
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item
              label="涉及国有企业："
              prop="involvingStateOwnedEnterprises"
            >
              <el-input
                v-model="baseForm.involvingStateOwnedEnterprises"
                maxlength="120"
                placeholder="请输入涉及国有企业"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item
              label="涉及集体企业："
              prop="involvingCollectiveEnterprises"
            >
              <el-input
                v-model="baseForm.involvingCollectiveEnterprises"
                placeholder="请输入涉及集体企业"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="合作时间：">
              <el-date-picker
                v-model="baseForm.cooperationTime"
                type="daterange"
                value-format="yyyy-MM-dd"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
              >
              </el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="涉及资金（万元）：" prop="involvingFund"
              ><el-input v-model.number="baseForm.involvingFund"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="净利润（万元）：" prop="netProfit"
              ><el-input v-model.number="baseForm.netProfit"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="利润率（元）：" prop="profitRate"
              ><el-input v-model.number="baseForm.profitRate"></el-input>
            </el-form-item>
          </el-col>
        </el-row>

        <el-col>
          <el-form-item label="项目进展：" prop="projectProgress">
            <el-input
              type="textarea"
              v-model="baseForm.projectProgress"
              resize="none"
              :rows="3"
              maxlength="500"
              show-word-limit
              placeholder="请输入项目进展情况"
            ></el-input
          ></el-form-item>
        </el-col>
        <el-col>
          <el-form-item label="项目概况：" prop="projectOverview">
            <el-input
              type="textarea"
              v-model="baseForm.projectOverview"
              resize="none"
              :rows="3"
              maxlength="500"
              show-word-limit
              placeholder="请输入项目概况"
            ></el-input
          ></el-form-item>
        </el-col>
        <el-col>
          <el-form-item label="详情介绍链接：" prop="introduceLink"
            ><el-input v-model="baseForm.introduceLink"></el-input>
          </el-form-item>
        </el-col>
        <!-- 附件 -->
        <el-col :span="8">
          <el-form-item label="附件：">
            <el-upload
              class="upload-demo"
              action="https://jsonplaceholder.typicode.com/posts/"
              :on-preview="handlePreview"
              :on-remove="handleRemove"
              :before-remove="beforeRemove"
              multiple
              :limit="3"
              :on-exceed="handleExceed"
              :file-list="fileList"
              :show-file-list="true"
            >
              <el-button size="small" type="primary" icon="el-icon-upload2"
                >点击上传</el-button
              >
              <span slot="tip" class="el-upload__tip ml20"
                >只能上传jpg/png/ppt/doc/pdf/xls文件，且不超过30M</span
              >
            </el-upload>
          </el-form-item>
        </el-col>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import { getPrimaryDataArea } from "@/api/devservice/common";
import { getDictionary } from "@/api/system/dict.js";
import {
  addCompanyCoopSuccessCase,
  getCompanyCoopSuccessCaseDetail,
} from "@/api/devservice/success-case";
export default {
  inject: ["reload", "index"],
  data() {
    return {
      id: this.$route.query.id,
      pageTitle: this.$route.query.pageTitle,
      districtCode: "",
      townCode: "",
      districtName: this.$route.query.districtName,
      townName: this.$route.query.townName,

      baseForm: {
        projectName: "",
        cooperationStatus: "",
        projectTypes: "",
        locatedPosition: "",
        districtName: "",
        townName: "",

        cooperationMode: "",

        landArea: "",
        buildingArea: "",

        involvingStateOwnedEnterprises: "",
        involvingCollectiveEnterprises: "",
        cooperationTime: "",
        cooperationMode: "",

        involvingFund: "",
        netProfit: "",
        profitRate: "",

        followingInvestmentAmount: "",
        investmentAmount: "",

        projectProgress: "",
        projectOverview: "",
        introduceLink: "",
      },
      initCoopStatus: "未开展",
      initProjType: ["土地开发合作"],

      initDistrictName: "", //福田区
      initTownName: "", //南沙街道
      initCooperateMode: "协议合作",

      fileList: [
        {
          name: "food.jpeg",
          url:
            "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
        },
        {
          name: "food2.jpeg",
          url:
            "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
        },
      ],

      isSubmitFlag: false,
    };
  },

  created() {
    this.getPrimaryDataAreaFun(); //获得所有区的数据
    this.enterWhichPage(); //是编辑页还是新增页
  },
  methods: {
    enterWhichPage() {
      if (this.$route.query.pageTitle == "新增") {
        this.getDictionaryFun(); //获取下拉框字典
      } else if (this.$route.query.pageTitle == "编辑") {
        this.getCompanyCoopSuccessCaseDetailFun();
      }
    },
    chooseDistrict(value) {
      console.log(value, "value值：");
      this.districtCode = value;
      //  this.initDistrictName=""
      this.baseForm.districtName.map((e) => {
        if (value == e.code) {
          this.baseForm.townName = e.childList;

          // this.initTownName = e.childList.length > 0 ? e.childList[0].name : "";
          if (e.childList.length) {
            (this.initTownName = e.childList[0].name),
              (this.townCode = e.childList[0].code);
          } else {
            this.initTownName = "";
          }
        }
      });
    },
    chooseTown(value) {
      this.townCode = value;
    },
    //获取所有区的信息
    getPrimaryDataAreaFun() {
      getPrimaryDataArea("4403").then((res) => {
        if (res.data.success) {
          console.log(res.data, "区");
          this.baseForm.districtName = res.data.data;
          /*  this.baseForm.districtName=data.map(item=>item.name)
          console.log( this.baseForm.districtName,"222") */
        }
      });
    },
    getDictionaryFun() {
      let arr = ["coop_status", "success_project_type", "success_coop_mode"];
      for (let i = 0; i < arr.length; i++) {
        let params = {};
        params = {};
        params.code = arr[i];
        getDictionary(params).then((res) => {
          if (res.data.success) {
            if (i == 0) {
              console.log();
              this.baseForm.cooperationStatus = res.data.data;
            } else if (i == 1) {
              this.baseForm.projectTypes = res.data.data; //cooperationMode
            } else if (i == 2) {
              this.baseForm.cooperationMode = res.data.data;
            }
          } else {
            this.$message({
              type: "error",
              message: res.data.msg,
            });
          }
        });
      }
    },
    getCompanyCoopSuccessCaseDetailFun() {
      let params = { id: this.$route.query.id };
      getCompanyCoopSuccessCaseDetail(params).then((res) => {
        if (res.data.success) {
          this.baseForm = res.data.data;
          // this.tableData = res.data.data.companyCoopServiceItemsList;
          // this.baseForm = res.data.data.companyCoopServiceInfo;
          this.getDictionaryFun(); //获取下拉框字典
          this.baseForm.cooperationTime[0] = this.baseForm.cooperationStartDate;
          this.baseForm.cooperationTime[1] = this.baseForm.cooperationEndDate;
        } else {
          this.$message({
            type: "error",
            message: res.data.msg,
          });
        }
      });
    },
    //点击上传文件
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePreview(file) {
      console.log(file);
      window.open(file.url);
    },
    handleExceed(files, fileList) {
      this.$message.warning(
        `当前限制选择 3 个文件，本次选择了 ${files.length} 个文件，共选择了 ${
          files.length + fileList.length
        } 个文件`
      );
    },
    handleBeforeUpload(file) {
      const isLt30M = file.size < 1024 * 1024 * 30;
      if (!isLt30M) {
        this.$message.error("上传的视频大小不能超过 30MB!");
        return;
      }
      return isLt30M;
    },
    beforeRemove(file, fileList) {
      console.log(this.file, fileList, "99");
      return this.$confirm(`确定移除 ${file.name}？`);
    },

    //提交所有表单
    submitForm() {
      if (this.initProjType[0] == "土地开发合作") {
        var newStr = this.initProjType.toString().replace("土地开发合作", "0");
      } else {
        var newStr = this.initProjType.toString();
      }
      this.isSubmitFlag = true;
      let param = {
        projectName: this.baseForm.projectName,
        cooperationStatus:
          this.initCoopStatus == "未开展" ? "0" : this.initCoopStatus,
        locatedPosition: this.baseForm.locatedPosition,

        projectTypes: newStr,

        districtCode: this.districtCode,
        townCode: this.townCode,
        cooperationMode:
          this.initCooperateMode == "协议合作" ? "0" : this.initCooperateMode,

        landArea: this.baseForm.landArea,
        buildingArea: this.baseForm.buildingArea,
        //合作情况
        involvingStateOwnedEnterprises: this.baseForm
          .involvingStateOwnedEnterprises,
        involvingCollectiveEnterprises: this.baseForm
          .involvingCollectiveEnterprises,
        cooperationStartDate:
          this.baseForm.cooperationTime[0] ||
          this.baseForm.cooperationStartDate,
        cooperationEndDate:
          this.baseForm.cooperationTime[1] || this.baseForm.cooperationEndDate,
        involvingFund: this.baseForm.involvingFund,
        netProfit: this.baseForm.netProfit,
        profitRate: this.baseForm.profitRate,
        projectProgress: this.baseForm.projectProgress,
        projectOverview: this.baseForm.projectOverview,
        introduceLink: this.baseForm.introduceLink,
      };

      if (this.pageTitle == "新增") {
        //  params.cooperationType = 2; //合作类型【0土地1物业2产业3资金4住房】修改不用传
      } else if (this.pageTitle == "编辑") {
        param.id = this.$route.query.id;
      }
      //多穿一个id,就是编辑
      console.log(param, "成功案例");

      addCompanyCoopSuccessCase(param).then((res) => {
        if (res.data.success) {
          this.$message({
            type: "success",
            message: "提交数据成功!",
          });
          // console.log('addCompanyCoopBasic',this.$route.fullPath)
          this.index.closeTag(this.$route.fullPath);
        } else {
          this.$message({
            type: "error",
            message: res.data.msg,
          });
        }
        this.isSubmitFlag = false;
      });
    },
  },
};
</script>

<style lang="scss">
#success-case-add-or-edit {
  background-color: #f5f5f6;
  overflow-y: scroll;
  height: 100%;
  .el-select {
    width: 100%;
  }

  .el-button {
    padding: 8px 8px;
  }

  .edit-content {
    .title2,
    .title3 {
      position: relative;
      width: 100%;
      &::before {
        content: "";
        position: absolute;
        width: 96%;
        height: 1px;
        top: -10px;
        left: 40px;
        background-color: #d8d8d8;
      }
    }
  }
}
</style>