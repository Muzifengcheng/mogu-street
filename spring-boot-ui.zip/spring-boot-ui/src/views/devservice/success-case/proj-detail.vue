<template>
  <div id="success-case-projdetail">
    <h3>合作详情</h3>
    <el-card class="base">
      <div class="border-left-4-2667C1 title1">
        <label class="ml20 ft18 lh40 fw700">基本情况</label>
      </div>
      <el-form
        :model="baseForm"
        ref="baseForm"
        class="ml40 mr40"
        label-position="left"
      >
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="项目名称:">
              {{ baseForm.projectName }}
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="合作状态:">
              {{baseForm.cooperationStatusDesc}}
            </el-form-item>
          </el-col>
        <el-col :span="6">
          <el-form-item label="坐落位置:">{{
            baseForm.locatedPosition
          }}</el-form-item>
        </el-col>
        </el-row>
        <el-row :gutter="10">  
          <el-col :span="6">
            <el-form-item label="项目类型:">{{ baseForm.projectTypesDesc}}</el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="行政区:">{{baseForm.districtName}} </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="所属街道:">{{baseForm.townName }}</el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="合作模式:"
              >{{ baseForm.cooperationModeDesc }}
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="项目用地面积:"
              >{{ baseForm.landArea }}
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="现状建筑面积:">{{
              baseForm.buildingArea
            }}</el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </el-card>

    <!-- 合作情况 -->
    <el-card class="cooporation mt20">
      <div class="border-left-4-2667C1 title3">
        <label class="ml20 ft18 lh40 fw700">合作情况</label>
      </div>
      <el-form
        :model="baseForm"
        ref="cooperateForm"
        class="ml40 mr40"
        label-position="left"
      >
        <el-col>
          <el-form-item label="涉及国有企业：">
            {{ baseForm.involvingStateOwnedEnterprises }}
          </el-form-item>
        </el-col>
        <el-col>
          <el-form-item label="涉及集体企业：">
            {{ baseForm.involvingCollectiveEnterprises }}
          </el-form-item>
          <el-form-item label="合作时间：">
            {{ baseForm.cooperationStartDate }}-{{ baseForm.cooperationEndDate}}
          </el-form-item>
        </el-col>
        <el-row :gutter="10">
          <el-col :span="6">
            <el-form-item label="涉及资金（万元）："> {{baseForm.involvingFund}}</el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="净利润（万元）：">{{baseForm.netProfit}} </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="利润率（元）：">{{baseForm.profitRate}} </el-form-item>
          </el-col>
        </el-row>

        <el-col>
          <el-form-item label="项目进展：">{{baseForm.projectProgress}} </el-form-item>
        </el-col>
        <el-col>
          <el-form-item label="项目概况：">{{baseForm.projectOverview}} </el-form-item>
        </el-col>
        <el-col>
          <el-form-item label="详情介绍链接：">{{baseForm.introduceLink}} </el-form-item>
        </el-col>
        <!-- 附件 -->
        <el-col :span="6">
          <el-form-item label="附件：">
            <el-upload
              class="upload-demo"
              action="https://jsonplaceholder.typicode.com/posts/"
              :on-preview="handlePreview"
              :on-remove="handleRemove"
              :before-remove="beforeRemove"
              multiple
              :limit="3"
              :on-exceed="handleExceed"
              :file-list="fileList"
              :show-file-list="true"
            >
              <el-button size="small" type="primary" icon="el-icon-upload2"
                >点击上传</el-button
              >
            </el-upload>
          </el-form-item>
        </el-col>
      </el-form>
    </el-card>
  </div>
</template>

<script>
// import { getCompanyCoopBasicInfoDetail } from "@/api/devservice/industry-cooperation";
import {
 
  getCompanyCoopSuccessCaseDetail,
} from "@/api/devservice/success-case";
export default {
  data() {
    return {
      districtName: this.$route.query.districtName,
      blockName: this.$route.query.townName,
      baseForm: {},

      cooperateForm: {},
      fileList: [
        {
          name: "food.jpeg",
          url:
            "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
        },
        {
          name: "food2.jpeg",
          url:
            "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
        },
      ],
    };
  },
  created() {
    this.getCompanyCoopSuccessCaseDetailFun();
  },
  methods: {
    getCompanyCoopSuccessCaseDetailFun() {
      let params = { id: this.$route.query.id };
      getCompanyCoopSuccessCaseDetail(params).then((res) => {
        if (res.data.success) {
          this.baseForm = res.data.data;
        
          // this.cooperateForm = res.data.data.companyCoopServiceInfo;
        } else {
          this.$message({
            type: "error",
            message: res.data.msg,
          });
        }
      });
    },
  },
};
</script>

<style lang="scss">
#success-case-projdetail{
  background-color: #f5f5f6;
  overflow-y: scroll;
  height: 100%;
  .el-card__body {
    padding: 16px 0px !important;
  }
  .collective{
    .el-button{
      padding: 8px 8px;

    }
  }
}
</style>