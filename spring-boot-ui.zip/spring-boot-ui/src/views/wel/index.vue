<template>
  <div id="home-index" class="ff-mc-yahei c-435b76">
    <div class="ytct-flex">
      <div class="padding10 qygk">
        <div
          class="padding20 bg-ffffff b-r-8"
          style="width: 400px; height: 780px;"
        >
          <div class="ft18 lh24 fw700">全市集体企业概况</div>
          <div class="mt20 ytct-flex-jcsb c-95a1af ft14 lh20">
            <div
              :class="
                qygkTabIndex === 0
                  ? 'cursor-pointer tab-active'
                  : 'cursor-pointer'
              "
              @click="qygkTab(0)"
            >
              全市合计
            </div>
            <div
              :class="
                qygkTabIndex === 2
                  ? 'cursor-pointer tab-active'
                  : 'cursor-pointer'
              "
              @click="qygkTab(2)"
            >
              股份合作公司
            </div>
            <div
              :class="
                qygkTabIndex === 3
                  ? 'cursor-pointer tab-active'
                  : 'cursor-pointer'
              "
              @click="qygkTab(3)"
            >
              供销企业
            </div>
            <div>城镇集体企业</div>
          </div>
          <div class="mt34 ft14 c-3f4958 ytct-flex-fww ff-pingfang">
            <div class="wp50 lh24 ytct-flex-aib">
              <label style="width: 75px;">企业数量</label>
              <label class="c-ff8365 ft20  ff-din-bold fw700">{{
                showQygkForm.entNum
              }}</label>
              <label class="c-95a1af lh20">{{ showQygkForm.entNumUnit }}</label>
            </div>
            <div class="wp50 lh24 ytct-flex-aib">
              <label style="width: 75px;">总资产</label>
              <label class="c-ff8365 ft20 lh24 ff-din-bold fw700">{{
                showQygkForm.totalAssets
              }}</label>
              <label class="c-95a1af lh20">{{
                showQygkForm.totalAssetsUnit
              }}</label>
            </div>
            <div class="wp50 lh24 ytct-flex-aib mt30">
              <label style="width: 75px;">净资产</label>
              <label class="c-ff8365 ft20 lh24 ff-din-bold fw700">{{
                showQygkForm.netAssets
              }}</label>
              <label class="c-95a1af lh20">{{
                showQygkForm.netAssetsUnit
              }}</label>
            </div>
            <div class="wp50 lh24 ytct-flex-aib mt30">
              <label style="width: 75px;">营业收入</label>
              <label class="c-ff8365 ft20 lh24 ff-din-bold fw700">{{
                showQygkForm.takingAmount
              }}</label>
              <label class="c-95a1af lh20">{{
                showQygkForm.takingAmountUnit
              }}</label>
            </div>
            <div class="wp50 lh24 ytct-flex-aib mt30">
              <label style="width: 75px;">利润</label>
              <label class="c-ff8365 ft20 lh24 ff-din-bold fw700">{{
                showQygkForm.profitAmount
              }}</label>
              <label class="c-95a1af lh20">{{
                showQygkForm.profitAmountUnit
              }}</label>
            </div>
            <div class="wp50 lh24 ytct-flex-aib mt30">
              <label style="width: 75px;">净利润</label>
              <label class="c-ff8365 ft20 lh24 ff-din-bold fw700">{{
                showQygkForm.netProfit
              }}</label>
              <label class="c-95a1af lh20">{{
                showQygkForm.netProfitUnit
              }}</label>
            </div>
            <div class="wp50 lh24 ytct-flex-aib mt30">
              <label style="width: 75px;">税金</label>
              <label class="c-ff8365 ft20 lh24 ff-din-bold fw700">{{
                showQygkForm.tax
              }}</label>
              <label class="c-95a1af lh20">{{ showQygkForm.taxUnit }}</label>
            </div>
            <div class="wp50 lh24 ytct-flex-aib mt30">
              <label style="width: 75px;">职工人数</label>
              <label class="c-ff8365 ft20 lh24 ff-din-bold fw700">{{
                showQygkForm.empNum
              }}</label>
              <label class="c-95a1af lh20">{{ showQygkForm.empNumUnit }}</label>
            </div>
          </div>
          <div class="mtb40 line"></div>
          <div class="ft16 lh20 fw700">• 企业排名</div>
          <div class="mt20 mb10 ytct-flex c-95a1af ft14 lh20">
            <div
              :class="
                qypmTabIndex === 0
                  ? 'mr30 cursor-pointer tab-active'
                  : 'mr30 cursor-pointer'
              "
              @click="qygkOrderTab(0)"
            >
              总资产
            </div>
            <div
              :class="
                qypmTabIndex === 1
                  ? 'mr30 cursor-pointer tab-active'
                  : 'mr30 cursor-pointer'
              "
              @click="qygkOrderTab(1)"
            >
              营业收入
            </div>
            <div
              :class="
                qypmTabIndex === 2
                  ? 'mr30 cursor-pointer tab-active'
                  : 'mr30 cursor-pointer'
              "
              @click="qygkOrderTab(2)"
            >
              净利润
            </div>
          </div>
          <template v-for="(item, index) in showQygkOrders">
            <div class="ytct-flex-jcsb-aic ft14 ptb20 c-3f4958" :key="index">
              <div class="ytct-flex-aic">
                <img
                  class="medal-img"
                  src="@/assets/icon/home/gold-medal.png"
                  v-if="index === 0"
                />
                <img
                  class="medal-img"
                  src="@/assets/icon/home/silver-medal.png"
                  v-else-if="index === 1"
                />
                <img
                  class="medal-img"
                  src="@/assets/icon/home/bronze-medal.png"
                  v-else
                />
                <label class="mlr20 ft18 fw700">{{ index + 1 }}</label>
                <label>{{ item.entName }}</label>
              </div>
              <div>
                <label class="c-ff8365 ft18 fw700">{{ item.value }}</label>
                <label class="c-95a1af">{{ item.unit }}</label>
              </div>
            </div>
            <div class="line" v-if="index < 4" :key="index"></div>
          </template>
        </div>
      </div>
      <div class="ytct-flex-fww">
        <div class="padding10 gqtj">
          <div
            class="padding20 bg-ffffff b-r-8"
            style="width: 860px; height:360px;"
          >
            <div class="ft18 lh24 fw700">各区统计</div>
            <div class="mt20 mb10 ytct-flex c-95a1af ft14 lh20">
              <div
                :class="
                  gqtjTabIndex === 0
                    ? 'mr24 cursor-pointer tab-active'
                    : 'mr24 cursor-pointer'
                "
                @click="gqtjTab(0)"
              >
                企业数量
              </div>
              <div
                :class="
                  gqtjTabIndex === 1
                    ? 'mr24 cursor-pointer tab-active'
                    : 'mr24 cursor-pointer'
                "
                @click="gqtjTab(1)"
              >
                总资产
              </div>
              <div
                :class="
                  gqtjTabIndex === 2
                    ? 'mr24 cursor-pointer tab-active'
                    : 'mr24 cursor-pointer'
                "
                @click="gqtjTab(2)"
              >
                净资产
              </div>
              <div
                :class="
                  gqtjTabIndex === 3
                    ? 'mr24 cursor-pointer tab-active'
                    : 'mr24 cursor-pointer'
                "
                @click="gqtjTab(3)"
              >
                利润
              </div>
              <div
                :class="
                  gqtjTabIndex === 4
                    ? 'mr24 cursor-pointer tab-active'
                    : 'mr24 cursor-pointer'
                "
                @click="gqtjTab(4)"
              >
                净利润
              </div>
              <div
                :class="
                  gqtjTabIndex === 5
                    ? 'mr24 cursor-pointer tab-active'
                    : 'mr24 cursor-pointer'
                "
                @click="gqtjTab(5)"
              >
                税金
              </div>
              <div
                :class="
                  gqtjTabIndex === 6
                    ? 'mr24 cursor-pointer tab-active'
                    : 'mr24 cursor-pointer'
                "
                @click="gqtjTab(6)"
              >
                营业收入
              </div>
            </div>
            <div class="ft12 mt10">{{ gqtjUnit }}</div>
            <div id="gqtj-echart"></div>
          </div>
        </div>
        <div class="padding10 jgjs">
          <div
            class="padding20 bg-ffffff b-r-8"
            style="width: 400px; height:360px;"
          >
            <div class="ft18 lh24 fw700">机构介绍</div>
            <img class="mtb20 b-r-5" src="@/assets/icon/home/jgjs.png" />
            <div class="ft14 lh24">
              2019年3月，深圳市人民政府国有资产监督管理委员会加挂深圳市集体资产管理办公室牌子，主要职责是负责集体资产管理的政策制定工作，指导集体企业的改革发展、转型升级、业务经营…
            </div>
          </div>
        </div>
        <div class="padding10">
          <div
            class="padding20 bg-ffffff b-r-8"
            style="width: 1320px; height:360px;"
          >
            <div class="ft18 lh24 fw700">土地物业情况</div>
            <el-row class="mtb20">
              <el-col :span="12">
                <div class="ft16 lh20 fw700">
                  <label class="c-2b9aff">• </label>土地情况
                </div>
                <div class="mt18 ft16 lh20 ytct-flex-aib ml12">
                  土地总面积 :
                  <label class="c-ff8365 ft20 ff-din-bold fw700 ml5">{{
                    tdqkTotal
                  }}</label>
                  <label class="c-95a1af">{{ tdqkTotalUnit }}</label>
                </div>
                <div id="tdqk-echart"></div>
              </el-col>
              <el-col :span="12">
                <div class="ft16 lh18 fw700">
                  <label class="c-2b9aff">• </label>物业情况
                </div>
                <div class="mt18 ft16 lh20 ytct-flex-aib ml12">
                  物业总面积 :
                  <label class="c-ff8365 ft20 ff-din-bold fw700 ml5">
                    {{ wyqkTotal }}</label
                  >
                  <label class="c-95a1af">{{ wyqkTotalUnit }}</label>
                </div>
                <div id="wyqk-echart"></div>
              </el-col>
            </el-row>
          </div>
        </div>
      </div>
    </div>
    <div class="ytct-flex">
      <div class="padding10 zdxm">
        <div
          class="padding20 bg-ffffff b-r-8"
          style="width: 860px; height:360px;"
        >
          <div class="ft18 lh24 fw700">重点项目</div>
          <div class="ytct-flex mtb20" style="">
            <div class="left">
              <div id="zdxm-pie-echart"></div>
              <div class="ytct-flex-fdc-aic ft14 title">
                <div class="c-3F4958">项目总数</div>
                <div class="c-ff8365 ft18 ff-din-bold fw700">
                  {{ zdxmTotalNum
                  }}<label class="ft14 c-95a1af fw500 ">个</label>
                </div>
              </div>
            </div>
            <div class="right">
              <div>各区分布</div>
              <div id="zdxm-echart"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="padding10">
        <div
          class="padding20 bg-ffffff b-r-8"
          style="width: 860px; height:360px;"
        >
          <div class="ft18 lh24 fw700">党建情况</div>
          <div class="mt18 ft16 lh20 ytct-flex-aib ml12">
            股份合作公司党建设情况 :
            <label class="c-ff8365 ft20 ff-din-bold fw700 ml5">{{
              djqkTota
            }}</label>
            <label class="c-95a1af">{{ djqkTotalUnit }}</label>
          </div>
          <div id="djqk-echart"></div>
        </div>
      </div>
    </div>
    <div class="padding10">
      <div
        class="padding20 bg-ffffff b-r-8"
        style="width: 1780px; height:80px;"
      >
        <div class="ft18 lh24 fw700">友情链接</div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import {
  gqtjData,
  qygkData,
  qygkOrderData,
  tdqkData,
  wyqkData,
  zdxmData,
  djqkData
} from "@/store/home/home-store";

import {
  gqtjEchartDraw,
  tdqkEchartDraw,
  wyqkEchartDraw,
  djqkEchartDraw,
  zdxmPieEchartDraw,
  zdxmEchartDraw
} from "@/store/home/home-echarts";

export default {
  name: "wel",
  data() {
    return {
      qygkTabIndex: 0,
      qypmTabIndex: 0,
      gqtjTabIndex: 0,
      gqtjData,
      gqtjUnit: "",
      qygkData,
      qygkOrderData,
      tdqkData,
      wyqkData,
      zdxmData,
      djqkData,
      showQygkForm: {},
      showQygkOrders: [],
      tdqkTota: null,
      tdqkTotalUnit: "",
      wyqkTota: null,
      wyqkTotalUnit: "",
      djqkTota: 658,
      djqkTotalUnit: "家",
      zdxmTotalNum: null
    };
  },
  computed: {
    ...mapGetters(["userInfo"])
  },
  created() {},
  mounted() {
    this.qygkTab(0);
    this.qygkOrderTab(0);
    this.gqtjTab(0);
    this.tdqkEchart();
    this.wyqkEchart();
    this.djqkEchart();
    this.zdxmEchart();
  },
  methods: {
    qygkTab(index) {
      if (this.qygkData[index] == null || this.qygkData[index] == undefined)
        return;
      this.qygkTabIndex = index;
      this.showQygkForm = this.qygkData[index];
    },
    qygkOrderTab(index) {
      if (
        !(
          this.qygkOrderData[index] &&
          this.qygkOrderData[index].entDetailList &&
          this.qygkOrderData[index].entDetailList.length > 0
        )
      )
        return;
      this.qypmTabIndex = index;
      this.showQygkOrders = this.qygkOrderData[index].entDetailList;
    },
    gqtjTab(index) {
      if (
        !(
          this.gqtjData[index] &&
          this.gqtjData[index].dataList &&
          this.gqtjData[index].dataList.length > 0
        )
      )
        return;
      const stringArr = this.gqtjData[index].dataList.map(item => {
        return item.district;
      });
      const numArr = this.gqtjData[index].dataList.map(item => {
        return item.amount.toFixed(2);
      });
      this.gqtjUnit = "单位（" + gqtjData[index].dataList[0].unit + "）";
      this.gqtjTabIndex = index;
      gqtjEchartDraw(stringArr, numArr, "gqtj-echart");
    },
    tdqkEchart() {
      this.tdqkTotal = this.tdqkData
        .reduce((prev, next) => {
          return Number(prev || 0) + Number(next.area);
        })
        .toFixed(2);
      var stringArr = this.tdqkData.map(item => {
        return item.district;
      });
      var numArr = this.tdqkData.map(item => {
        return item.area.toFixed(2);
      });
      this.tdqkTotalUnit = this.tdqkData[0].areaUnit;
      tdqkEchartDraw(stringArr, numArr, "tdqk-echart");
    },
    wyqkEchart() {
      this.wyqkTotal = this.wyqkData
        .reduce((prev, next) => {
          return Number(prev || 0) + Number(next.area);
        })
        .toFixed(2);
      var stringArr = this.wyqkData.map(item => {
        return item.district;
      });
      var numArr = this.wyqkData.map(item => {
        return item.area.toFixed(2);
      });
      this.wyqkTotalUnit = this.wyqkData[0].areaUnit;
      wyqkEchartDraw(stringArr, numArr, "wyqk-echart");
    },
    djqkEchart() {
      djqkEchartDraw(
        this.djqkData.nameArray,
        this.djqkData.data,
        "djqk-echart"
      );
    },
    zdxmEchart() {
      if (!(this.zdxmData && this.zdxmData.length > 0)) return;

      const totalProcessNum = this.zdxmData.reduce((prev, next) => {
        return Number(prev || 0) + Number(next.processNum);
      });
      const totalExpectNum = this.zdxmData.reduce((prev, next) => {
        return Number(prev || 0) + Number(next.expectNum);
      });
      this.zdxmTotalNum = totalProcessNum + totalExpectNum;
      const numArray = this.zdxmData.map(item => {
        return item.processNum + item.expectNum;
      });
      const nameArray = this.zdxmData.map(item => {
        return item.district === "深汕特别合作区" ? "深汕" : item.district;
      });
      zdxmPieEchartDraw(
        [
          { name: "正在开发的项目", value: totalProcessNum },
          { name: "预期展开项目", value: totalExpectNum }
        ],
        "zdxm-pie-echart"
      );
      zdxmEchartDraw(nameArray, numArray, "zdxm-echart");
    }
  }
};
</script>

<style lang="scss">
#home-index {
  margin-bottom: 35px;
  overflow: auto;
  .tab-active {
    font-weight: 700;
    color: #2b9aff;
  }

  .line {
    height: 1px;
    background: #ebebeb;
  }

  .medal-img {
    width: 24px;
    height: 28px;
  }
  .jgjs {
    img {
      width: 400px;
      height: 220px;
    }
  }

  #gqtj-echart {
    height: 265px;
  }
  #tdqk-echart {
    height: 248px;
  }
  #wyqk-echart {
    height: 248px;
  }

  #zdxm-echart {
    height: 248px;
  }

  #zdxm-pie-echart {
    height: 248px;
  }

  #djqk-echart {
    height: 288px;
  }

  .zdxm {
    .left {
      width: 260px;
      border-right: 1px solid #ebebeb;
      position: relative;
      #zdxm-pie-echart {
        height: 100%;
      }
      .title {
        position: absolute;
        top: 34%;
        left: 39%;
      }
    }
    .right {
      padding-left: 20px;
      width: calc(100% - 280px);
      #zdxm-echart {
        height: 288px;
      }
    }
  }
}
</style>
