<template>
  <div id="industry-cooperation-blocks">
    <el-scrollbar>
      <basic-container class="tb-content">
        <div class="ytct-flex-jcsb-aic">
          <div class="limit-chose">
            <span class="limit-title">时间：</span>
            <el-date-picker
              v-model="value1"
              type="month"
              placeholder="选择月"
              value-format="yyyyMM"
            >
            </el-date-picker>
            <!-- 打印和重置按钮 -->
            <span class="search_reset ml20">
              <el-button type="primary" icon="el-icon-search" @click="search"
                >查询</el-button
              >
              <el-button plain @click="reset">重置</el-button>
            </span>
          </div>

          <span class="operate-btns">
            <el-button type="primary" icon="el-icon-printer"> 打印</el-button>
            <el-button type="primary" icon="el-icon-upload2">导出</el-button>
          </span>
        </div>
        <el-row :gutter="20">
          <el-col :span="12" class="left-tb">
            <h3>土地面积排名前十名</h3>
            <el-table
              border
              :data="tbObj.landRankList"
              class="mt10"
              :header-cell-style="{
                background: '#F4F7FA',
                fontWeight: '700',
                color: '#435B76',
              }"
            >
              <el-table-column type="index" label="序号" width="50">
              </el-table-column>
              <el-table-column align="center" label="区" prop="adminDistrict" width="120">
              </el-table-column>
              <el-table-column align="center" prop="streetOffice" label="街道" width="120">
              </el-table-column>
              <el-table-column
                align="center"
                prop="entName"
                label="股份公司"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="value"
                label="土地面积(m²)"
              >
              </el-table-column>
            </el-table>
          </el-col>
          <el-col :span="12" class="right-tb">
            <h3>物业面积排名前十名</h3>
            <el-table
              border
              :data="tbObj.propertyRankList"
              class="mt10"
              :header-cell-style="{
                background: '#F4F7FA',
                fontWeight: '700',
                color: '#435B76',
              }"
            >
              <el-table-column type="index" label="序号" width="50">
              </el-table-column>

              <el-table-column align="center" prop="adminDistrict" label="区" width="120">
              </el-table-column>
              <el-table-column
                align="center"
                prop="streetOffice"
                label="街道"
                width="120"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="entName"
                label="股份公司"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="value"
                label="物业面积"
              >
              </el-table-column>
            </el-table>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12" class="left-tb">
            <h3>资产总额排名前十名</h3>
            <el-table
              border
              :data="tbObj.totalAssetsRankList"
              class="mt10"
              :header-cell-style="{
                background: '#F4F7FA',
                fontWeight: '700',
                color: '#435B76',
              }"
            >
              <el-table-column type="index" label="序号" width="50">
              </el-table-column>
              <el-table-column align="center" label="区" prop="adminDistrict" width="120">
              </el-table-column>
              <el-table-column align="center" prop="streetOffice" label="街道" width="120">
              </el-table-column>
              <el-table-column
                align="center"
                prop="entName"
                label="股份公司"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="value"
                label="总金额（万元）"
              >
              </el-table-column>
            </el-table>
          </el-col>
        <el-col :span="12" class="left-tb">
            <h3>净利润排名前十名</h3>
            <el-table
              border
              :data="tbObj.netProfitRankList"
              class="mt10"
              :header-cell-style="{
                background: '#F4F7FA',
                fontWeight: '700',
                color: '#435B76',
              }"
            >
              <el-table-column type="index" label="序号" width="50">
              </el-table-column>
              <el-table-column align="center" label="区" prop="adminDistrict" width="120">
              </el-table-column>
              <el-table-column align="center" prop="streetOffice" label="街道" width="120">
              </el-table-column>
              <el-table-column
                align="center"
                prop="entName"
                label="股份公司"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="value"
                label="总金额（万元）"
              >
              </el-table-column>
            </el-table>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12" class="left-tb">
            <h3>净资产排名前十名</h3>
            <el-table
              border
              :data="tbObj.netAssetsRankList"
              class="mt10"
              :header-cell-style="{
                background: '#F4F7FA',
                fontWeight: '700',
                color: '#435B76',
              }"
            >
              <el-table-column type="index" label="序号" width="50">
              </el-table-column>
              <el-table-column align="center" label="区" prop="adminDistrict" width="120">
              </el-table-column>
              <el-table-column align="center" prop="streetOffice" label="街道" width="120">
              </el-table-column>
              <el-table-column
                align="center"
                prop="entName"
                label="股份公司"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="value"
                label="总金额（万元）"
              >
              </el-table-column>
            </el-table>
          </el-col>

          <el-col :span="12" class="right-tb">
            <h3>已交税金总额排名前十名</h3>
            <el-table
              border
              :data="tbObj.taxRankList"
              class="mt10"
              :header-cell-style="{
                background: '#F4F7FA',
                fontWeight: '700',
                color: '#435B76',
              }"
            >
              <el-table-column type="index" label="序号" width="50">
              </el-table-column>

              <el-table-column align="center" prop="adminDistrict" label="区" width="120">
              </el-table-column>
              <el-table-column
                align="center"
                prop="streetOffice"
                label="街道"
                width="120"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="entName"
                label="股份公司"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="value"
                label="总金额（万元）"
              >
              </el-table-column>
            </el-table>
          </el-col>










        </el-row>
        <el-row :gutter="20">
          <el-col :span="12" class="left-tb">
            <h3>营业收入排名前十名</h3>
            <el-table
              border
              :data="tbObj.takingAmountRankList"
              class="mt10"
              :header-cell-style="{
                background: '#F4F7FA',
                fontWeight: '700',
                color: '#435B76',
              }"
            >
              <el-table-column type="index" label="序号" width="50">
              </el-table-column>
              <el-table-column align="center" label="区" prop="adminDistrict" width="120">
              </el-table-column>
              <el-table-column align="center" prop="streetOffice" label="街道" width="120">
              </el-table-column>
              <el-table-column
                align="center"
                prop="entName"
                label="股份公司"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="value"
                label="总金额（万元）"
              >
              </el-table-column>
            </el-table>
          </el-col>
          <el-col :span="12" class="right-tb">
            <h3>利润总额排名前十名</h3>
            <el-table
              border
              :data="tbObj.profitAmountRankList"
              class="mt10"
              :header-cell-style="{
                background: '#F4F7FA',
                fontWeight: '700',
                color: '#435B76',
              }"
            >
              <el-table-column type="index" label="序号" width="50">
              </el-table-column>

              <el-table-column align="center" prop="adminDistrict" label="区" width="120">
              </el-table-column>
              <el-table-column
                align="center"
                prop="streetOffice"
                label="街道"
                width="120"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="entName"
                label="股份公司"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="value"
                label="总金额（万元）"
              >
              </el-table-column>
            </el-table>
          </el-col>
        </el-row>
        <el-row :gutter="20">
  


                    <el-col :span="12" class="right-tb">
            <h3>负债总额排名前十名</h3>
            <el-table
              border
              :data="tbObj.debtTotalRankList"
              class="mt10"
              :header-cell-style="{
                background: '#F4F7FA',
                fontWeight: '700',
                color: '#435B76',
              }"
            >
              <el-table-column type="index" label="序号" width="50">
              </el-table-column>

              <el-table-column align="center" prop="adminDistrict" label="区" width="120">
              </el-table-column>
              <el-table-column
                align="center"
                prop="streetOffice"
                label="街道"
                width="120"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="entName"
                label="股份公司"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="value"
                label="总金额（万元）"
              >
              </el-table-column>
            </el-table>
          </el-col>


                    <el-col :span="12" class="right-tb">
            <h3>资产负载率排名前十名</h3>
            <el-table
              border
              :data="tbObj.debtRateRankList"
              class="mt10"
              :header-cell-style="{
                background: '#F4F7FA',
                fontWeight: '700',
                color: '#435B76',
              }"
            >
              <el-table-column type="index" label="序号" width="50">
              </el-table-column>

              <el-table-column align="center" prop="adminDistrict" label="区" width="120">
              </el-table-column>
              <el-table-column
                align="center"
                prop="streetOffice"
                label="街道"
                width="120"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="entName"
                label="股份公司"
              >
              </el-table-column>
              <el-table-column
                align="value"
                prop="value"
                label="总金额（万元）"
              >
              </el-table-column>
            </el-table>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12" class="left-tb">
            <h3>股民分红排名前十名</h3>
            <el-table
              border
              :data="tbObj.shareholderDividendsRankList"
              class="mt10"
              :header-cell-style="{
                background: '#F4F7FA',
                fontWeight: '700',
                color: '#435B76',
              }"
            >
              <el-table-column type="index" label="序号" width="50">
              </el-table-column>
              <el-table-column align="center" label="区" prop="adminDistrict" width="120">
              </el-table-column>
              <el-table-column align="center" prop="streetOffice" label="街道" width="120">
              </el-table-column>
              <el-table-column
                align="center"
                prop="entName"
                label="股份公司"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="value"
                label="总金额（万元）"
              >
              </el-table-column>
            </el-table>
          </el-col>
        </el-row>
      </basic-container>
    </el-scrollbar>
  </div>
</template>

<script>
import { getTopTenList } from "@/api/statistics-report/common";
export default {
  data() {
    return {
      value1: "202009",
      tableData: [],
      tbObj: {},

      paginations: {
        page_index: 1, //当前位于那页
        total: 0, //总数
        page_size: 10, //一页显示多少个
        layout: "prev,pager,next,jumper", //翻页属性
      },
    };
  },
  created() {
    this.getTopTenListFun();
  },
  methods: {
    search() {
      this.getTopTenListFun();
    },
    reset() {
      this.value1 = "202009";
      this.getTopTenListFun();
    },
    getTopTenListFun() {
      let params = {};
      params.yearmonth = this.value1;

      getTopTenList(params).then((res) => {
        if (res.data.success) {
          console.log(res.data, "hhh");
          // this.tableData = res.data.data.records;
          this.tbObj = res.data.data; //包含多个数组的对象
          console.log(this.tbObj.landRankList,"土地")

          // this.paginations.total = res.data.data.total;
        } else {
          this.$message({
            type: "error",
            message: res.data.msg,
          });
        }
      });
    },
  },
};
</script>

<style lang="scss">
#industry-cooperation-blocks {
  background-color: #ffffff;
  height: 100%;
  overflow: scroll;
  .el-scrollbar {
    height: 100%;
  }

  .left-tb,
  .right-tb {
    h3 {
      text-align: center;
    }
  }
  .tb-content {
    .el-button {
      padding: 8px 8px;
    }
    // .footerpage {
    //   display: flex;
    //   justify-content: flex-end;
    //   align-items: center;
    // }
  }
}
</style>