<template>
  <div id="finance-rank-statis-report">
    <el-row>
      <el-col>
        <el-scrollbar>
          <basic-container class="right-content">
            <div class="limit-chose mt20">
              <span>
                时间：
                <el-date-picker
                  v-model="value1"
                  type="month"
                  placeholder="选择月"
                  value-format="yyyyMM"
                >
                </el-date-picker>
              </span>
              <span class="search_reset ml20">
                <el-button type="primary" icon="el-icon-search" @click="search"
                  >查询</el-button
                >
                <el-button plain @click="reset">重置</el-button>
              </span>
            </div>

            <h3>深圳市股份合作公司主要财务指标表</h3>
            <h4 v-if="value1">
              {{
                composeNewStr(value1, [
                  { thing: "年", sp: 4 },
                  { thing: "月", sp: 7 },
                ])
              }}
            </h4>
            <div class="mt20">
              <div class="ytct-flex-jcfe">
                <el-button type="primary" icon="el-icon-upload2"
                  >导出</el-button
                >
              </div>
            </div>

            <el-table
              :data="tableData"
              class="mt20"
              :header-cell-style="{
                background: '#F4F7FA',
                fontWeight: '700',
                color: '#435B76',
              }"
            >
              <el-table-column type="index" label="序号" width="50">
              </el-table-column>
              <el-table-column align="center" label="项目" prop="item">
              </el-table-column>
              <el-table-column align="center" prop="unit" label="单位">
                <template v-slot="scope">
                  <span>{{ scope.row.unit || "亿元" }}</span>
                </template>
              </el-table-column>
              <el-table-column
                align="center"
                prop="currentYearCumulative"
                label="本年累计（期末数）"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="samePeriodLastYear"
                label="上年同期"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="incrementDeduction"
                label="增减额"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="incrementDeductionRate"
                label="增减率(%)"
              >
              </el-table-column>
            </el-table> </basic-container
        ></el-scrollbar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { getFinanceList } from "@/api/statistics-report/common";
import { dateFormat } from "@/util/date";
export default {
  data() {
    return {
      value1: "202009",
      tableData: [],
      paginations: {
        page_index: 1, //当前位于那页
        total: 0, //总数
        page_size: 10, //一页显示多少个
        layout: "prev,pager,next,jumper", //翻页属性
      },
      // titleArr:["序号","项目","单位","本年累计（期末数）","上年同期","增减额",]
    };
  },
  created() {
    this.getFinanceListFun();
  },

  methods: {
    composeNewStr(str, things) {
      const strArr = str.split("");
      things.forEach((item) => {
        const { sp: index, thing = "" } = item;
        strArr[index] = thing + (strArr[index] || "");
      });
      return strArr.join("");
    },

    search() {
      this.getFinanceListFun();
    },
    reset() {
      this.value1 = "202009";
      this.getFinanceListFun();
    },
    getFinanceListFun() {
      let params = {};
      params.yearmonth = this.value1;
      getFinanceList(params).then((res) => {
        if (res.data.success) {
          console.log(res.data);
          this.tableData = res.data.data;

          // this.paginations.total = res.data.data.total;
        } else {
          this.$message({
            type: "error",
            message: res.data.msg,
          });
        }
      });
    },
  },
};
</script>

<style lang="scss">
#finance-rank-statis-report {
  background-color: #f5f5f6;
  height: 100%;
  overflow: scroll;

  .box {
    height: 800px;
  }

  .el-scrollbar {
    height: 100%;
  }

  .box .el-scrollbar__wrap {
    overflow: scroll;
  }
  .right-content {
    h3,h4 {
      text-align: center;
    }

    .el-button {
      padding: 8px 8px;
    }
    .footerpage {
      display: flex;
      justify-content: flex-end;
      align-items: center;
    }
  }
}
</style>