<template>
  <div id="break-rent-statis-report">
    <el-row>
      <el-col>
        <el-scrollbar>
          <basic-container class="right-content">
            <h3>深圳市股份合作公司支持抗击疫情减免租金统计表</h3>
            <div class="limit-chose mt20">
              <span>
                时间：
                <el-date-picker
                  v-model="value1"
                  type="month"
                  placeholder="选择月"
                >
                </el-date-picker>
              </span>
              <span class="search_reset ml20">
                <el-button type="primary" icon="el-icon-search">查询</el-button>
                <el-button plain>重置</el-button>
              </span>
            </div>
            <div class="mt20">
              <div>
                <el-button type="primary" icon="el-icon-upload2"
                  >导出</el-button
                >
              </div>
            </div>

            <el-table
              :data="tableData"
              class="mt20"
              style="width: 98%; margin: 0 auto"
              :header-cell-style="{
                background: '#F4F7FA',
                fontWeight: '700',
                color: '#435B76',
              }"
            >
              <el-table-column type="index" label="序号" width="50">
              </el-table-column>
              <el-table-column align="center" label="区域" prop="projectName">
              </el-table-column>
              <el-table-column
                align="center"
                prop="projectLandArea"
                label="减免租金股份合作公司数量（户）"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="currentBuildingArea"
                width="300"
                label="减免租金金额（含租金、管理费、停车费等）"
              >
              </el-table-column>
              <el-table-column
                align="center"
                prop="developmentModeDesc"
                label="惠及租户数量（户）"
              >
              </el-table-column>
            </el-table> </basic-container
        ></el-scrollbar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { getPrimaryDataArea } from "@/api/devservice/common";
import {
  getCompanyCoopBasicBlockList,
  removeCompanyCoopBasic,
} from "@/api/devservice/industry-cooperation";
export default {
  data() {
    return {
      value1: "",
      tableData: [],
      multipleSelectionFlag: false,
      multipleSelection: [],
      paginations: {
        page_index: 1, //当前位于那页
        total: 0, //总数
        page_size: 10, //一页显示多少个
        layout: "prev,pager,next,jumper", //翻页属性
      },
      treeData: [],
      treeOption: {
        nodeKey: "id",
        lazy: true,
        treeLoad: function (node, resolve) {
          const parentCode = node.level === 0 ? "44" : node.data.code;
          getPrimaryDataArea(parentCode).then((res) => {
            resolve(
              res.data.data.map((item) => {
                return {
                  ...item,
                  leaf: !(item.childList || item.childList.length > 0),
                };
              })
            );
          });
        },
        addBtn: false,
        menu: false,
        size: "small",
        props: {
          labelText: "标题",
          label: "name",
          value: "code",
          children: "childList",
        },
      },
    };
  },
  created() {
    this.getCompanyCoopBasicBlockListFun();
  },
  methods: {
    nodeClick(data) {
      console.log(data, "node");
    },

    getCompanyCoopBasicBlockListFun() {
      let params = {};
      params.code = this.townCode;
      params.cooperationType = 2; // 	合作类型【0土地1物业2产业3资金4住房】
      params.current = this.paginations.page_index;
      params.size = this.paginations.page_size;
      getCompanyCoopBasicBlockList(params).then((res) => {
        if (res.data.success) {
          console.log(res.data.data);
          this.tableData = res.data.data.records;

          this.paginations.total = res.data.data.total;
        } else {
          this.$message({
            type: "error",
            message: res.data.msg,
          });
        }
      });
    },

    handleCurrentChange(val) {
      this.paginations.page_index = val;
      //调用查询接口
      this.getCompanyCoopBasicBlockListFun();
    },
  },
};
</script>

<style lang="scss">
#break-rent-statis-report {
  background-color: #f5f5f6;
  height: 100%;
  overflow: scroll;

  .box {
    height: 800px;
  }

  .el-scrollbar {
    height: 100%;
  }

  .box .el-scrollbar__wrap {
    overflow: scroll;
  }
  .right-content {
    h3 {
      display: inline-block;
      margin: 0 auto;
    }
    .el-button {
      padding: 8px 8px;
    }
    .footerpage {
      display: flex;
      justify-content: flex-end;
      align-items: center;
    }
  }
}
</style>